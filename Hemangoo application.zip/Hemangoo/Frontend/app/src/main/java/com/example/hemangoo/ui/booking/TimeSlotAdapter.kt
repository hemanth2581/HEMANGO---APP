package com.example.hemangoo.ui.booking

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.hemangoo.R
import com.example.hemangoo.data.models.TimeSlot
import java.text.NumberFormat
import java.util.*

class TimeSlotAdapter(
    private val slots: List<TimeSlot>,
    private val onSlotClick: (TimeSlot) -> Unit
) : RecyclerView.Adapter<TimeSlotAdapter.TimeSlotViewHolder>() {

    private var selectedSlot: TimeSlot? = null

    class TimeSlotViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardView: CardView = itemView as CardView
        val timeText: TextView = itemView.findViewById(R.id.tvSlotTime)
        val availabilityText: TextView = itemView.findViewById(R.id.tvAvailability)
        val priceText: TextView = itemView.findViewById(R.id.tvSlotPrice)
        val capacityText: TextView = itemView.findViewById(R.id.tvCapacity)
        val selectionIndicator: View = itemView.findViewById(R.id.selectionIndicator)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeSlotViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_time_slot, parent, false)
        return TimeSlotViewHolder(view)
    }

    override fun onBindViewHolder(holder: TimeSlotViewHolder, position: Int) {
        val slot = slots[position]
        
        holder.timeText.text = slot.time
        holder.availabilityText.text = "${slot.availableSpots} spots left"
        holder.capacityText.text = "${slot.maxCapacity}kg"
        
        // Format price
        val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        holder.priceText.text = formatter.format(150.0) // Default price, can be made dynamic
        
        // Update availability text color and background
        if (slot.availableSpots > 0) {
            holder.availabilityText.setTextColor(holder.itemView.context.getColor(android.R.color.white))
            holder.availabilityText.setBackgroundColor(holder.itemView.context.getColor(R.color.primary_blue))
            holder.timeText.setTextColor(holder.itemView.context.getColor(R.color.text_primary))
            holder.cardView.alpha = 1.0f
        } else {
            holder.availabilityText.setTextColor(holder.itemView.context.getColor(android.R.color.white))
            holder.availabilityText.setBackgroundColor(holder.itemView.context.getColor(R.color.text_secondary))
            holder.timeText.setTextColor(holder.itemView.context.getColor(R.color.text_secondary))
            holder.cardView.alpha = 0.6f
        }
        
        // Update selection state
        val isSelected = selectedSlot?.id == slot.id
        holder.selectionIndicator.visibility = if (isSelected) View.VISIBLE else View.GONE
        
        // Update card appearance based on selection
        if (isSelected) {
            holder.cardView.setCardBackgroundColor(holder.itemView.context.getColor(R.color.selected_slot_bg))
            holder.cardView.elevation = 8f
        } else {
            holder.cardView.setCardBackgroundColor(holder.itemView.context.getColor(android.R.color.white))
            holder.cardView.elevation = 4f
        }
        
        // Set click listener
        holder.cardView.setOnClickListener {
            if (slot.availableSpots > 0) {
                selectedSlot = slot
                notifyDataSetChanged() // Refresh all items to update selection
                onSlotClick(slot)
            }
        }
        
        // Disable interaction if no spots available
        holder.cardView.isEnabled = slot.availableSpots > 0
    }

    override fun getItemCount(): Int = slots.size

    fun getSelectedSlot(): TimeSlot? = selectedSlot
}
