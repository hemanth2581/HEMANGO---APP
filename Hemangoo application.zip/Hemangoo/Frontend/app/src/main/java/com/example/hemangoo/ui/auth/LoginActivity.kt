package com.example.hemangoo.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.ui.dashboard.FarmerDashboardActivity
import com.example.hemangoo.ui.dashboard.AdminDashboardActivity
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var roleRadioGroup: RadioGroup
    private lateinit var signInBtn: Button
    private lateinit var signUpText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var localStorageManager: LocalStorageManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        
        localStorageManager = LocalStorageManager(this)
        
        // Check if user is already logged in
        if (localStorageManager.isLoggedIn()) {
            val user = localStorageManager.getCurrentUser()
            if (user != null) {
                navigateToDashboard(user.role)
                return
            }
        }
        
        // Initialize views
        initializeViews()
        
        // Setup click listeners
        setupClickListeners()
        
        // Initialize sample data
        initializeSampleData()
    }
    
    private fun initializeViews() {
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        roleRadioGroup = findViewById(R.id.roleSelector)
        signInBtn = findViewById(R.id.btnLogin)
        signUpText = findViewById(R.id.txtCreateAccount)
        progressBar = findViewById(R.id.progressBar)
        
        // Hide progress bar initially
        progressBar.visibility = View.GONE
    }
    
    private fun setupClickListeners() {
        signInBtn.setOnClickListener { 
            if (validateInputs()) {
                signIn()
            }
        }
        
        signUpText.setOnClickListener {
            startActivity(Intent(this, SignupActivity::class.java))
        }
    }
    
    private fun validateInputs(): Boolean {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        val selectedId = roleRadioGroup.checkedRadioButtonId
        
        // Clear previous errors
        emailEditText.error = null
        passwordEditText.error = null
        
        var isValid = true
        
        if (email.isEmpty()) {
            emailEditText.error = "Email is required"
            isValid = false
        } else if (!isValidEmail(email)) {
            emailEditText.error = "Please enter a valid email address"
            isValid = false
        }
        
        if (password.isEmpty()) {
            passwordEditText.error = "Password is required"
            isValid = false
        }
        
        if (selectedId == -1) {
            Toast.makeText(this, "Please select a role", Toast.LENGTH_SHORT).show()
            isValid = false
        }
        
        return isValid
    }
    
    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun signIn() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        val selectedId = roleRadioGroup.checkedRadioButtonId
        
        val selectedRadioButton = findViewById<RadioButton>(selectedId)
        val role = when (selectedRadioButton.text.toString().lowercase()) {
            "farmer" -> "farmer"
            "admin" -> "admin"
            else -> {
                Toast.makeText(this, "Invalid role selected", Toast.LENGTH_SHORT).show()
                return
            }
        }

        showProgress(true)
        
        lifecycleScope.launch {
            try {
                val result = localStorageManager.loginUser(email, password, role)
                
                result.fold(
                    onSuccess = { user ->
                        // Save user data
                        localStorageManager.saveCurrentUser(user)
                        
                        Toast.makeText(this@LoginActivity, "Login successful!", Toast.LENGTH_SHORT).show()
                        
                        // Navigate to appropriate dashboard
                        navigateToDashboard(user.role)
                    },
                    onFailure = { error ->
                        showError(error.message ?: "Login failed. Please check your credentials.")
                    }
                )
            } catch (e: Exception) {
                showError("Login error: ${e.message}")
            } finally {
                showProgress(false)
            }
        }
    }
    
    private fun navigateToDashboard(role: String) {
        val intent = when (role) {
            "farmer" -> Intent(this, FarmerDashboardActivity::class.java)
            "admin" -> Intent(this, AdminDashboardActivity::class.java)
            else -> Intent(this, FarmerDashboardActivity::class.java)
        }
        startActivity(intent)
        finish()
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        signInBtn.isEnabled = !show
        signInBtn.text = if (show) "Signing In..." else "Sign In"
    }
    
    private fun initializeSampleData() {
        lifecycleScope.launch {
            try {
                // Data is automatically initialized in LocalStorageManager constructor
            } catch (e: Exception) {
                // Sample data initialization failed, but app should still work
                println("Failed to initialize sample data: ${e.message}")
            }
        }
    }
}