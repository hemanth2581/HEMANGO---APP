package com.example.hemangoo.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.ui.dashboard.FarmerDashboardActivity
import com.example.hemangoo.ui.dashboard.AdminDashboardActivity
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch

class SignupActivity : AppCompatActivity() {
    
    private lateinit var progressBar: ProgressBar
    private lateinit var registerButton: Button
    private lateinit var fullNameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var tabLayoutRole: TabLayout
    private lateinit var signInText: TextView
    private lateinit var localStorageManager: LocalStorageManager
    
    private var selectedRole = "farmer" // Default role
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        
        localStorageManager = LocalStorageManager(this)
        
        // Initialize views
        initializeViews()
        
        // Setup click listeners
        setupClickListeners()
        
        // Initialize sample data
        initializeSampleData()
    }
    
    private fun initializeViews() {
        progressBar = findViewById(R.id.progressBar)
        registerButton = findViewById(R.id.button_register)
        fullNameEditText = findViewById(R.id.fullNameEditText)
        phoneEditText = findViewById(R.id.phoneEditText)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText)
        tabLayoutRole = findViewById(R.id.tabLayoutRole)
        signInText = findViewById(R.id.text_signin)
        
        // Hide progress bar initially
        progressBar.visibility = View.GONE
    }
    
    private fun setupClickListeners() {
        // Role selection listener
        tabLayoutRole.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                selectedRole = when (tab?.text?.toString()?.lowercase()) {
                    "farmer" -> "farmer"
                    "admin" -> "admin"
                    else -> "farmer"
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        // Handle registration
        registerButton.setOnClickListener {
            if (validateInputs()) {
                registerUser()
            }
        }

        // Navigate back to login
        signInText.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
    
    private fun validateInputs(): Boolean {
        val fullName = fullNameEditText.text.toString().trim()
        val phone = phoneEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString()
        val confirmPassword = confirmPasswordEditText.text.toString()

        // Clear previous errors
        clearErrors()

        var isValid = true

        // Validate full name
        if (fullName.isEmpty()) {
            fullNameEditText.error = "Full name is required"
            isValid = false
        } else if (fullName.length < 2) {
            fullNameEditText.error = "Full name must be at least 2 characters"
            isValid = false
        }

        // Validate phone
        if (phone.isEmpty()) {
            phoneEditText.error = "Phone number is required"
            isValid = false
        } else if (!isValidPhone(phone)) {
            phoneEditText.error = "Please enter a valid phone number"
            isValid = false
        }

        // Validate email
        if (email.isEmpty()) {
            emailEditText.error = "Email is required"
            isValid = false
        } else if (!isValidEmail(email)) {
            emailEditText.error = "Please enter a valid email address"
            isValid = false
        } else if (selectedRole == "admin" && !isValidAdminEmail(email)) {
            emailEditText.error = "Admin accounts can only be created with authorized email addresses"
            isValid = false
        }

        // Validate password
        if (password.isEmpty()) {
            passwordEditText.error = "Password is required"
            isValid = false
        } else if (password.length < 8) {
            passwordEditText.error = "Password must be at least 8 characters"
            isValid = false
        } else if (!isValidPassword(password)) {
            passwordEditText.error = "Password must contain at least one letter and one number"
            isValid = false
        }

        // Validate confirm password
        if (confirmPassword.isEmpty()) {
            confirmPasswordEditText.error = "Please confirm your password"
            isValid = false
        } else if (password != confirmPassword) {
            confirmPasswordEditText.error = "Passwords do not match"
            isValid = false
        }

        return isValid
    }
    
    private fun clearErrors() {
        fullNameEditText.error = null
        phoneEditText.error = null
        emailEditText.error = null
        passwordEditText.error = null
        confirmPasswordEditText.error = null
    }
    
    private fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
    
    private fun isValidPhone(phone: String): Boolean {
        return phone.matches(Regex("^[+]?[0-9]{10,15}$"))
    }
    
    private fun isValidPassword(password: String): Boolean {
        return password.matches(Regex("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d@$!%*#?&]{8,}$"))
    }
    
    private fun isValidAdminEmail(email: String): Boolean {
        val allowedAdminEmails = listOf(
            "admin@hemango.com",
            "admin1@hemango.com",
            "admin2@hemango.com",
            "superadmin@hemango.com",
            "admin@hemangoo.com",
            "admin1@hemangoo.com"
        )
        return allowedAdminEmails.contains(email.lowercase())
    }

    private fun registerUser() {
        val fullName = fullNameEditText.text.toString().trim()
        val phone = phoneEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString()

        showProgress(true)
        
        lifecycleScope.launch {
            try {
                val result = localStorageManager.registerUser(fullName, email, phone, password, selectedRole)
                
                result.fold(
                    onSuccess = { user ->
                        // Save user data
                        localStorageManager.saveCurrentUser(user)
                        
                        Toast.makeText(this@SignupActivity, "Registration successful!", Toast.LENGTH_SHORT).show()
                        
                        // Navigate to appropriate dashboard
                        navigateToDashboard(user.role)
                    },
                    onFailure = { error ->
                        showError(error.message ?: "Registration failed. Please try again.")
                    }
                )
            } catch (e: Exception) {
                showError("Registration error: ${e.message}")
            } finally {
                showProgress(false)
            }
        }
    }
    
    private fun navigateToDashboard(role: String) {
        val intent = when (role) {
            "farmer" -> Intent(this, FarmerDashboardActivity::class.java)
            "admin" -> Intent(this, AdminDashboardActivity::class.java)
            else -> Intent(this, FarmerDashboardActivity::class.java)
        }
        startActivity(intent)
        finish()
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        registerButton.isEnabled = !show
        registerButton.text = if (show) "Creating Account..." else "Create Account"
    }
    
    private fun initializeSampleData() {
        lifecycleScope.launch {
            try {
                // Data is automatically initialized in LocalStorageManager constructor
            } catch (e: Exception) {
                // Sample data initialization failed, but app should still work
                println("Failed to initialize sample data: ${e.message}")
            }
        }
    }
}