package com.example.hemangoo

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class ImageUploadAdapter(
    private val images: MutableList<Uri>,
    private val onImageRemoved: (Int) -> Unit
) : RecyclerView.Adapter<ImageUploadAdapter.ImageViewHolder>() {

    companion object {
        private const val MAX_IMAGES = 6
    }

    class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
        val removeButton: ImageButton = itemView.findViewById(R.id.removeButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_upload_image, parent, false)
        return ImageViewHolder(view)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val imageUri = images[position]
        
        // Load image directly
        holder.imageView.setImageURI(imageUri)
        
        // Set remove button click listener
        holder.removeButton.setOnClickListener {
            onImageRemoved(position)
        }
    }

    override fun getItemCount(): Int = images.size

    fun addImage(uri: Uri) {
        if (images.size < MAX_IMAGES) {
            images.add(uri)
            notifyItemInserted(images.size - 1)
        }
    }

    fun removeImage(position: Int) {
        if (position in 0 until images.size) {
            images.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, images.size)
        }
    }

    fun getImages(): List<Uri> = images.toList()
    
    fun canAddMoreImages(): Boolean = images.size < MAX_IMAGES
}