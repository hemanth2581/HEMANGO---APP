package com.example.hemangoo.ui.booking

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * NEW SIMPLIFIED SELECT TIME SLOT ACTIVITY
 * 
 * This activity allows farmers to select their preferred dates and times
 * for booking slots. The admin will later review and assign specific slots.
 * 
 * Workflow:
 * 1. Farmer selects preferred dates (multiple selection)
 * 2. Farmer selects preferred time slots (multiple selection) 
 * 3. System creates booking request with PENDING status
 * 4. Admin reviews and assigns specific slot or rejects
 */
class SelectSlotActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var backButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var submitButton: Button
    
    // Summary UI elements
    private lateinit var tvSummaryMangoType: TextView
    private lateinit var tvSummaryQuantity: TextView
    private lateinit var tvSummaryFactory: TextView
    private lateinit var tvSummaryQualityGrade: TextView
    
    // Date checkboxes
    private lateinit var cbDate1: CheckBox
    private lateinit var cbDate2: CheckBox
    private lateinit var cbDate3: CheckBox
    private lateinit var cbDate4: CheckBox
    private lateinit var cbDate5: CheckBox
    private lateinit var cbDate6: CheckBox
    
    // Time checkboxes
    private lateinit var cbTime1: CheckBox
    private lateinit var cbTime2: CheckBox
    private lateinit var cbTime3: CheckBox
    private lateinit var cbTime4: CheckBox
    private lateinit var cbTime5: CheckBox
    private lateinit var cbTime6: CheckBox
    
    // Data from previous activities
    private var mangoType: String = ""
    private var mangoVariety: String = ""
    private var minQuantity: Double = 0.0
    private var maxQuantity: Double = 0.0
    private var quantity: Double = 0.0
    private var unit: String = ""
    private var factoryId: Int = 0
    private var factoryName: String = ""
    private var qualityReport: QualityReport? = null
    private var currentUser: User? = null
    
    // Available dates (next 6 days)
    private val availableDates = mutableListOf<String>()
    private val availableTimes = listOf(
        "9:00 AM - 10:00 AM",
        "10:00 AM - 11:00 AM", 
        "11:00 AM - 12:00 PM",
        "2:00 PM - 3:00 PM",
        "3:00 PM - 4:00 PM",
        "4:00 PM - 5:00 PM"
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_time_slot)
        
        android.util.Log.d("SelectSlot", "New SelectSlotActivity starting...")
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            android.util.Log.e("SelectSlot", "User not logged in")
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        // Get data from previous activity
        getIntentData()
        
        // Validate received data
        if (!validateReceivedData()) {
            return // validateReceivedData will handle error and finish
        }
        
        // Initialize dates
        generateAvailableDates()
        
        // Setup UI
        initializeViews()
        setupClickListeners()
        populateBookingSummary()
        setupDateLabels()
        
        android.util.Log.d("SelectSlot", "SelectSlotActivity initialized successfully")
    }
    
    private fun getIntentData() {
        mangoType = intent.getStringExtra("mango_type") ?: ""
        mangoVariety = intent.getStringExtra("mango_variety") ?: ""
        minQuantity = intent.getDoubleExtra("min_quantity", 0.0)
        maxQuantity = intent.getDoubleExtra("max_quantity", 0.0)
        quantity = intent.getDoubleExtra("quantity", 0.0)
        unit = intent.getStringExtra("unit") ?: ""
        factoryId = intent.getIntExtra("factory_id", 0)
        factoryName = intent.getStringExtra("factory_name") ?: ""
        qualityReport = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("quality_report", QualityReport::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("quality_report") as? QualityReport
        }
        
        android.util.Log.d("SelectSlot", "Received: $mangoType $mangoVariety, $quantity $unit, Factory: $factoryName")
    }
    
    private fun validateReceivedData(): Boolean {
        if (mangoType.isEmpty() || mangoVariety.isEmpty()) {
            android.util.Log.e("SelectSlot", "Invalid mango data: Type=$mangoType, Variety=$mangoVariety")
            showError("Invalid mango selection. Please restart booking process.")
            finish()
            return false
        }
        
        if (quantity <= 0) {
            android.util.Log.e("SelectSlot", "Invalid quantity: $quantity")
            showError("Invalid quantity. Please restart booking process.")
            finish()
            return false
        }
        
        if (factoryId <= 0 || factoryName.isEmpty()) {
            android.util.Log.e("SelectSlot", "Invalid factory: ID=$factoryId, Name=$factoryName")
            showError("Invalid factory selection. Please restart booking process.")
            finish()
            return false
        }
        
        android.util.Log.d("SelectSlot", "All data validation passed successfully")
        return true
    }
    
    private fun generateAvailableDates() {
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        
        // Generate next 6 days starting from today
        for (i in 0..5) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_MONTH, i)
            availableDates.add(dateFormat.format(calendar.time))
        }
        
        android.util.Log.d("SelectSlot", "Generated dates: $availableDates")
    }
    
    private fun initializeViews() {
        try {
            // UI elements
            backButton = findViewById(R.id.btnBack)
            progressBar = findViewById(R.id.progressBar)
            submitButton = findViewById(R.id.btnSubmitRequest)
            
            // Summary UI elements
            tvSummaryMangoType = findViewById(R.id.tvSummaryMangoType)
            tvSummaryQuantity = findViewById(R.id.tvSummaryQuantity)
            tvSummaryFactory = findViewById(R.id.tvSummaryFactory)
            tvSummaryQualityGrade = findViewById(R.id.tvSummaryQualityGrade)
            
            // Date checkboxes
            cbDate1 = findViewById(R.id.cbDate1)
            cbDate2 = findViewById(R.id.cbDate2)
            cbDate3 = findViewById(R.id.cbDate3)
            cbDate4 = findViewById(R.id.cbDate4)
            cbDate5 = findViewById(R.id.cbDate5)
            cbDate6 = findViewById(R.id.cbDate6)
            
            // Time checkboxes
            cbTime1 = findViewById(R.id.cbTime1)
            cbTime2 = findViewById(R.id.cbTime2)
            cbTime3 = findViewById(R.id.cbTime3)
            cbTime4 = findViewById(R.id.cbTime4)
            cbTime5 = findViewById(R.id.cbTime5)
            cbTime6 = findViewById(R.id.cbTime6)
            
            // Hide progress bar initially
            progressBar.visibility = View.GONE
            
            android.util.Log.d("SelectSlot", "Views initialized successfully")
        } catch (e: Exception) {
            android.util.Log.e("SelectSlot", "Error initializing views: ${e.message}")
            showError("Failed to initialize screen: ${e.message}")
            finish()
        }
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }
        
        submitButton.setOnClickListener {
            submitBookingRequest()
        }
    }
    
    private fun setupDateLabels() {
        val dateFormat = SimpleDateFormat("MMM dd", Locale.getDefault())
        val calendar = Calendar.getInstance()
        
        // Set date labels
        val dateCheckboxes = listOf(cbDate1, cbDate2, cbDate3, cbDate4, cbDate5, cbDate6)
        for (i in 0..5) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_MONTH, i)
            val dateText = when (i) {
                0 -> "Today (${dateFormat.format(calendar.time)})"
                1 -> "Tomorrow (${dateFormat.format(calendar.time)})"
                else -> dateFormat.format(calendar.time)
            }
            dateCheckboxes[i].text = dateText
        }
    }
    
    private fun populateBookingSummary() {
        tvSummaryMangoType.text = "$mangoType $mangoVariety"
        tvSummaryQuantity.text = "$quantity $unit"
        tvSummaryFactory.text = factoryName
        tvSummaryQualityGrade.text = qualityReport?.ripenessLevel ?: "Not Specified"
    }
    
    private fun getSelectedDates(): List<String> {
        val selectedDates = mutableListOf<String>()
        val dateCheckboxes = listOf(cbDate1, cbDate2, cbDate3, cbDate4, cbDate5, cbDate6)
        
        dateCheckboxes.forEachIndexed { index, checkbox ->
            if (checkbox.isChecked) {
                selectedDates.add(availableDates[index])
            }
        }
        
        return selectedDates
    }
    
    private fun getSelectedTimes(): List<String> {
        val selectedTimes = mutableListOf<String>()
        val timeCheckboxes = listOf(cbTime1, cbTime2, cbTime3, cbTime4, cbTime5, cbTime6)
        
        timeCheckboxes.forEachIndexed { index, checkbox ->
            if (checkbox.isChecked) {
                selectedTimes.add(availableTimes[index])
            }
        }
        
        return selectedTimes
    }
    
    private fun validateSelections(): Boolean {
        val selectedDates = getSelectedDates()
        val selectedTimes = getSelectedTimes()
        
        if (selectedDates.isEmpty()) {
            showError("Please select at least one preferred date")
            return false
        }
        
        if (selectedTimes.isEmpty()) {
            showError("Please select at least one preferred time slot")
            return false
        }
        
        return true
    }
    
    private fun submitBookingRequest() {
        if (!validateSelections()) {
            return
        }
        
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                currentUser?.let { user ->
                    val selectedDates = getSelectedDates()
                    val selectedTimes = getSelectedTimes()
                    
                    // Create new booking request with preferred dates/times
                    val booking = Booking(
                        id = 0, // Will be set by createBooking
                        farmerId = user.id,
                        farmerName = user.fullName,
                        factoryId = factoryId,
                        factoryName = factoryName,
                        mangoType = mangoType,
                        mangoVariety = mangoVariety,
                        minQuantity = minQuantity,
                        maxQuantity = maxQuantity,
                        quantity = quantity,
                        unit = unit,
                        qualityReport = qualityReport ?: QualityReport(
                            ripenessLevel = "Not Specified",
                            colour = "Not Specified",
                            size = "Not Specified",
                            bruisingLevel = "Not Specified",
                            pestPresence = false,
                            harvestDate = getCurrentDate(),
                            notes = null
                        ),
                        preferredDates = selectedDates,
                        preferredTimes = selectedTimes,
                        assignedDate = null, // Will be assigned by admin
                        assignedTime = null, // Will be assigned by admin
                        status = BookingStatus.PENDING,
                        reviewedBy = null,
                        adminNotes = null,
                        rejectionReason = null,
                        createdAt = getCurrentDateTime(),
                        updatedAt = getCurrentDateTime(),
                        images = emptyList()
                    )
                    
                    android.util.Log.d("SelectSlot", "Creating booking request with ${selectedDates.size} dates and ${selectedTimes.size} times")
                    
                    // Save booking request
                    val result = localStorageManager.saveBooking(booking)
                    
                    if (result.isSuccess) {
                        val savedBooking = result.getOrNull()
                        
                        // Add activity log
                        val activity = ActivityItem(
                            id = System.currentTimeMillis().toInt(),
                            message = "New booking request #${savedBooking?.id ?: "Unknown"} submitted by ${user.fullName}",
                            timestamp = getCurrentDateTime(),
                            type = "booking_request_created"
                        )
                        localStorageManager.addActivity(activity)
                        
                        runOnUiThread {
                            showProgress(false)
                            showSuccessDialog(savedBooking?.id ?: 0, selectedDates, selectedTimes)
                        }
                    } else {
                        runOnUiThread {
                            showProgress(false)
                            showError("Failed to submit booking request: ${result.exceptionOrNull()?.message}")
                        }
                    }
                } ?: run {
                    runOnUiThread {
                        showProgress(false)
                        showError("User not found. Please login again.")
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("SelectSlot", "Error submitting booking request", e)
                runOnUiThread {
                    showProgress(false)
                    showError("Error submitting request: ${e.message}")
                }
            }
        }
    }
    
    private fun showSuccessDialog(bookingId: Int, dates: List<String>, times: List<String>) {
        val datesText = dates.joinToString(", ")
        val timesText = times.joinToString(", ")
        
        android.app.AlertDialog.Builder(this)
            .setTitle("✅ Booking Request Submitted!")
            .setMessage(
                "Your booking request has been submitted successfully.\n\n" +
                "📋 Request ID: $bookingId\n" +
                "🏭 Factory: $factoryName\n" +
                "🥭 Mango: $mangoType $mangoVariety\n" +
                "📦 Quantity: $quantity $unit\n\n" +
                "📅 Preferred Dates:\n$datesText\n\n" +
                "⏰ Preferred Times:\n$timesText\n\n" +
                "The admin will review your request and assign a specific time slot. You will be notified once the decision is made."
            )
            .setPositiveButton("OK") { _, _ ->
                // Navigate back to dashboard
                val intent = Intent(this, com.example.hemangoo.ui.dashboard.FarmerDashboardActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setCancelable(false)
            .show()
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        submitButton.isEnabled = !show
        submitButton.text = if (show) "Submitting..." else "Submit Booking Request"
    }
    
    private fun getCurrentDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }
    
    private fun getCurrentDateTime(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date())
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
