package com.example.hemangoo

import android.content.Context
import com.example.hemangoo.data.models.*
import com.example.hemangoo.database.LocalDatabaseManager
import kotlinx.coroutines.runBlocking

/**
 * ENHANCED LOCAL STORAGE MANAGER
 * 
 * This is a wrapper around the LocalDatabaseManager that provides
 * backward compatibility with the existing API while adding enhanced features.
 * 
 * Features:
 * - Complete offline database functionality
 * - Thread-safe operations
 * - Data validation and integrity
 * - Performance optimization with caching
 * - Backup and restore capabilities
 * - Error handling and logging
 */
class LocalStorageManager(private val context: Context) {
    
    private val database = LocalDatabaseManager(context)
    
    companion object {
        private const val TAG = "LocalStorageManager"
    }
    
    init {
        // Database is automatically initialized in LocalDatabaseManager
    }
    
    // ==================== FACTORY MANAGEMENT ====================
    
    fun getAllFactories(): List<Factory> = runBlocking {
        database.getAllFactories()
    }
    
    fun saveFactories(factories: List<Factory>) = runBlocking {
        database.saveFactories(factories)
    }
    
    fun getFactoryById(id: Int): Factory? = runBlocking {
        database.getFactoryById(id)
    }
    
    // ==================== MANGO VARIETIES MANAGEMENT ====================
    
    fun getAllMangoVarieties(): List<MangoVariety> = runBlocking {
        database.getAllMangoVarieties()
    }
    
    fun saveMangoVarieties(varieties: List<MangoVariety>) = runBlocking {
        database.saveMangoVarieties(varieties)
    }
    
    fun getMangoVarietiesByType(type: String): List<MangoVariety> = runBlocking {
        database.getMangoVarietiesByType(type)
    }
    
    // ==================== TIME SLOTS MANAGEMENT ====================
    
    fun getAvailableSlots(factoryId: Int, date: String): List<TimeSlot> = runBlocking {
        database.getAvailableSlots(factoryId, date)
    }
    
    fun getAvailableSlotsFromBackend(factoryId: Int, date: String): List<TimeSlot> = runBlocking {
        database.getAvailableSlots(factoryId, date)
    }
    
    suspend fun bookSlot(factoryId: Int, slotId: Int): Result<TimeSlot> {
        return database.bookSlot(factoryId, slotId)
    }
    
    // ==================== BOOKING MANAGEMENT ====================
    
    fun getAllBookings(): List<Booking> = runBlocking {
        database.getAllBookings()
    }
    
    fun saveBookings(bookings: List<Booking>) = runBlocking {
        database.saveBookings(bookings)
    }
    
    suspend fun saveBooking(booking: Booking): Result<Booking> {
        return database.createBooking(booking)
    }
    
    fun updateBooking(booking: Booking) = runBlocking {
        database.updateBooking(booking)
    }
    
    fun getBookingById(id: Int): Booking? = runBlocking {
        database.getBookingById(id)
    }
    
    fun deleteBooking(id: Int) = runBlocking {
        // Note: deleteBooking not implemented in LocalDatabaseManager yet
        // For now, we'll just log it
        android.util.Log.d(TAG, "Delete booking request for ID: $id")
    }
    
    fun getBookingsByFarmer(farmerId: Int): List<Booking> = runBlocking {
        database.getBookingsByFarmer(farmerId)
    }
    
    fun getBookingsByStatus(status: BookingStatus): List<Booking> = runBlocking {
        database.getBookingsByStatus(status)
    }
    
    fun getPendingBookings(): List<Booking> = runBlocking {
        database.getPendingBookings()
    }
    
    // ==================== MARKET DATA MANAGEMENT ====================
    
    fun getMarketData(): List<MarketData> = runBlocking {
        database.getAllMarketData()
    }
    
    fun saveMarketData(marketData: List<MarketData>) = runBlocking {
        database.saveMarketData(marketData)
    }
    
    fun updateMarketData(newMarketData: MarketData): Result<Boolean> = runBlocking {
        try {
            val existingMarketData = database.getAllMarketData().toMutableList()
            
            // Remove any existing data for the same date
            existingMarketData.removeAll { it.date == newMarketData.date }
            
            // Add the new data
            existingMarketData.add(newMarketData)
            
            // Sort by date (newest first)
            existingMarketData.sortByDescending { it.date }
            
            // Keep only recent data (last 30 days)
            val trimmedData = existingMarketData.take(30)
            
            // Save back to database
            database.saveMarketData(trimmedData)
            
            Result.success(true)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "Failed to update market data", e)
            Result.failure(e)
        }
    }
    
    // ==================== ACTIVITIES MANAGEMENT ====================
    
    fun getAllActivities(): List<ActivityItem> = runBlocking {
        database.getAllActivities()
    }
    
    fun saveActivities(activities: List<ActivityItem>) = runBlocking {
        database.saveActivities(activities)
    }
    
    fun addActivity(activity: ActivityItem) = runBlocking {
        database.addActivity(activity)
    }
    
    // ==================== USER MANAGEMENT ====================
    
    fun getAllUsers(): List<User> = runBlocking {
        database.getAllUsers()
    }
    
    fun saveUsers(users: List<User>) = runBlocking {
        database.saveUsers(users)
    }
    
    fun getCurrentUser(): User? = runBlocking {
        // Get current user from a simple preference
        val prefs = context.getSharedPreferences("hemango_prefs", Context.MODE_PRIVATE)
        val userJson = prefs.getString("current_user", null)
        if (userJson != null) {
            val gson = com.google.gson.Gson()
            val type = object : com.google.gson.reflect.TypeToken<User>() {}.type
            gson.fromJson(userJson, type)
        } else {
            null
        }
    }
    
    fun saveCurrentUser(user: User) = runBlocking {
        val prefs = context.getSharedPreferences("hemango_prefs", Context.MODE_PRIVATE)
        val gson = com.google.gson.Gson()
        val userJson = gson.toJson(user)
        prefs.edit().putString("current_user", userJson).apply()
    }
    
    fun logout() = runBlocking {
        val prefs = context.getSharedPreferences("hemango_prefs", Context.MODE_PRIVATE)
        prefs.edit().remove("current_user").apply()
    }
    
    fun isLoggedIn(): Boolean = runBlocking {
        getCurrentUser() != null
    }
    
    // ==================== AUTHENTICATION ====================
    
    fun loginUser(email: String, password: String, role: String): Result<User> = runBlocking {
        database.loginUser(email, password, role)
    }
    
    fun registerUser(fullName: String, email: String, phone: String, password: String, role: String): Result<User> = runBlocking {
        database.registerUser(fullName, email, phone, password, role)
    }
    
    // ==================== UTILITY METHODS ====================
    
    fun clearAllData() = runBlocking {
        database.clearAllData()
    }
    
    fun getDatabaseStats(): Map<String, Any> = runBlocking {
        database.getDatabaseStats()
    }
    
    fun createBackup(): Result<String> = runBlocking {
        database.createBackup()
    }
    
    fun restoreBackup(filename: String): Result<Boolean> = runBlocking {
        database.restoreBackup(filename)
    }
    
    fun clearCache() = runBlocking {
        database.clearCache()
    }
    
    // ==================== LEGACY METHODS (for backward compatibility) ====================
    
    /**
     * Legacy method - now uses enhanced database
     */
    fun createBooking(booking: Booking): Result<Booking> = runBlocking {
        database.createBooking(booking)
    }
    
    /**
     * Legacy method - now uses enhanced database
     */
    fun updateBookingStatus(bookingId: Int, status: BookingStatus): Result<Booking> = runBlocking {
        val booking = database.getBookingById(bookingId)
        if (booking != null) {
            val updatedBooking = booking.copy(status = status)
            database.updateBooking(updatedBooking)
        } else {
            Result.failure(Exception("Booking not found"))
        }
    }
    
    /**
     * Legacy method - now uses enhanced database
     */
    fun hashPassword(password: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(password.toByteArray())
        return hash.joinToString("") { "%02x".format(it) }
    }
}