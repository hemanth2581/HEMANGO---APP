package com.example.hemangoo.ui.admin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import com.example.hemangoo.data.api.ApiClient
import kotlinx.coroutines.launch

class RequestDetailsActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var apiClient: ApiClient
    private lateinit var farmerNameText: TextView
    private lateinit var factoryNameText: TextView
    private lateinit var mangoVarietyText: TextView
    private lateinit var quantityText: TextView
    private lateinit var bookingDateText: TextView
    private lateinit var slotTimeText: TextView
    private lateinit var statusText: TextView
    private lateinit var qualityDetailsText: TextView
    private lateinit var approveButton: Button
    private lateinit var rejectButton: Button
    private lateinit var backButton: Button
    private lateinit var progressBar: ProgressBar
    
    private var bookingId: Int = 0
    private var currentUser: User? = null
    private var booking: Booking? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_details)
        
        localStorageManager = LocalStorageManager(this)
        apiClient = ApiClient(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        bookingId = intent.getIntExtra("booking_id", 0)
        
        android.util.Log.d("RequestDetails", "Received booking ID from intent: $bookingId")
        
        if (bookingId <= 0) {
            android.util.Log.e("RequestDetails", "Invalid booking ID received: $bookingId")
            Toast.makeText(this, "Invalid booking ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        initializeViews()
        setupClickListeners()
        loadBookingDetails()
    }
    
    private fun initializeViews() {
        try {
            // Initialize all views with proper error handling
            farmerNameText = findViewById(R.id.tvFruitName)
            factoryNameText = findViewById(R.id.tvFactoryName)
            mangoVarietyText = findViewById(R.id.tvFruitName) // Will show variety info here
            quantityText = findViewById(R.id.tvFruitWeight)
            bookingDateText = findViewById(R.id.tvDate)
            slotTimeText = findViewById(R.id.tvTime)
            statusText = findViewById(R.id.chipStatus)
            qualityDetailsText = findViewById(R.id.qualityDetailsText)
            approveButton = findViewById(R.id.btnRebookSlot)
            rejectButton = findViewById(R.id.btnRejectSlot)
            backButton = findViewById(R.id.btnBack)
            progressBar = findViewById(R.id.progressBar)
            
            // Set initial states
            progressBar.visibility = View.GONE
            
            android.util.Log.d("RequestDetails", "All views initialized successfully")
            
        } catch (e: Exception) {
            android.util.Log.e("RequestDetails", "Error initializing views", e)
            Toast.makeText(this, "Error initializing screen: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }
        
        approveButton.setOnClickListener {
            booking?.let { approveBooking(it) }
        }
        
        rejectButton.setOnClickListener {
            booking?.let { rejectBooking(it) }
        }
    }
    
    private fun loadBookingDetails() {
        android.util.Log.d("RequestDetails", "Loading booking details for ID: $bookingId")
        
        if (bookingId <= 0) {
            Toast.makeText(this, "Invalid booking ID", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                // Load booking directly from local storage
                android.util.Log.d("RequestDetails", "Fetching booking from local storage...")
                booking = localStorageManager.getBookingById(bookingId)
                
                runOnUiThread {
                    if (booking != null) {
                        android.util.Log.d("RequestDetails", "Booking found: ${booking!!.id} - ${booking!!.farmerName}")
                        populateBookingDetails()
                    } else {
                        android.util.Log.e("RequestDetails", "Booking not found with ID: $bookingId")
                        // Try to get all bookings for debugging
                        val allBookings = localStorageManager.getAllBookings()
                        android.util.Log.d("RequestDetails", "Total bookings available: ${allBookings.size}")
                        allBookings.forEach { b ->
                            android.util.Log.d("RequestDetails", "Available booking: ID=${b.id}, Farmer=${b.farmerName}")
                        }
                        
                        Toast.makeText(this@RequestDetailsActivity, "Booking not found (ID: $bookingId)", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                    showProgress(false)
                }
            } catch (e: Exception) {
                android.util.Log.e("RequestDetails", "Error loading booking details", e)
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@RequestDetailsActivity, "Error loading booking details: ${e.message}", Toast.LENGTH_LONG).show()
                    
                    // Show a basic error state instead of finishing
                    showErrorState("Failed to load booking details: ${e.message}")
                }
            }
        }
    }
    
    private fun populateBookingDetails() {
        try {
            booking?.let { booking ->
                // Set booking ID
                findViewById<TextView>(R.id.tvBookingID)?.text = "Booking #${booking.id}"
                
                // Set basic info with null safety
                farmerNameText?.text = booking.farmerName
                factoryNameText?.text = booking.factoryName
                mangoVarietyText?.text = "${booking.mangoType} ${booking.mangoVariety}"
                quantityText?.text = "${booking.quantity} ${booking.unit}"
                
                // Show assigned date/time if available, otherwise show "Pending Assignment"
                if (booking.assignedDate != null && booking.assignedTime != null) {
                    bookingDateText?.text = booking.assignedDate
                    slotTimeText?.text = booking.assignedTime
                } else {
                    bookingDateText?.text = "Pending Assignment"
                    slotTimeText?.text = "Pending Assignment"
                }
                
                statusText?.text = booking.status.name
                
                // Set status color and background
                when (booking.status) {
                    BookingStatus.PENDING -> {
                        statusText?.setBackgroundResource(R.drawable.bg_chip_pending)
                        statusText?.setTextColor(getColor(android.R.color.white))
                        // Show action buttons for pending bookings
                        approveButton?.visibility = View.VISIBLE
                        rejectButton?.visibility = View.VISIBLE
                    }
                    BookingStatus.CONFIRMED -> {
                        statusText?.setBackgroundColor(getColor(android.R.color.holo_green_dark))
                        statusText?.setTextColor(getColor(android.R.color.white))
                        // Hide action buttons for confirmed bookings
                        approveButton?.visibility = View.GONE
                        rejectButton?.visibility = View.GONE
                    }
                    BookingStatus.REJECTED -> {
                        statusText?.setBackgroundColor(getColor(android.R.color.holo_red_dark))
                        statusText?.setTextColor(getColor(android.R.color.white))
                        // Hide action buttons for rejected bookings
                        approveButton?.visibility = View.GONE
                        rejectButton?.visibility = View.GONE
                    }
                }
                
                // Enhanced quality and preference details
                val details = buildString {
                    appendLine("=== BOOKING DETAILS ===")
                    appendLine("Mango Variety: ${booking.mangoVariety} (${booking.mangoType})")
                    
                    // Try to get variety pricing info
                    try {
                        val varieties = localStorageManager.getAllMangoVarieties()
                        val variety = varieties.find { it.name == booking.mangoVariety && it.type == booking.mangoType }
                        variety?.let {
                            appendLine("Base Price: ₹${it.basePricePerKg}/kg")
                            if (booking.minQuantity > 0 && booking.maxQuantity > 0) {
                                appendLine("Quantity Range: ${booking.minQuantity} - ${booking.maxQuantity} ${booking.unit}")
                                appendLine("Expected Quantity: ${booking.quantity} ${booking.unit}")
                                val estimatedValue = booking.quantity * it.basePricePerKg
                                appendLine("Estimated Value: ₹$estimatedValue")
                            } else {
                                appendLine("Quantity: ${booking.quantity} ${booking.unit}")
                            }
                        } ?: run {
                            appendLine("Quantity: ${booking.quantity} ${booking.unit}")
                        }
                    } catch (e: Exception) {
                        appendLine("Quantity: ${booking.quantity} ${booking.unit}")
                    }
                    
                    appendLine("")
                    appendLine("=== FARMER PREFERENCES ===")
                    if (booking.preferredDates.isNotEmpty()) {
                        appendLine("Preferred Dates:")
                        booking.preferredDates.forEach { date ->
                            appendLine("  • $date")
                        }
                        appendLine("")
                    }
                    
                    if (booking.preferredTimes.isNotEmpty()) {
                        appendLine("Preferred Time Slots:")
                        booking.preferredTimes.forEach { time ->
                            appendLine("  • $time")
                        }
                        appendLine("")
                    }
                    
                    appendLine("=== QUALITY REPORT ===")
                    appendLine("Ripeness: ${booking.qualityReport.ripenessLevel}")
                    appendLine("Colour: ${booking.qualityReport.colour}")
                    appendLine("Size: ${booking.qualityReport.size}")
                    appendLine("Bruising: ${booking.qualityReport.bruisingLevel}")
                    appendLine("Pest Presence: ${if (booking.qualityReport.pestPresence) "Yes" else "No"}")
                    appendLine("Harvest Date: ${booking.qualityReport.harvestDate}")
                    
                    booking.qualityReport.notes?.let { notes ->
                        appendLine("Notes: $notes")
                    }
                    
                    if (booking.assignedDate != null && booking.assignedTime != null) {
                        appendLine("")
                        appendLine("=== ADMIN ASSIGNMENT ===")
                        appendLine("Assigned Date: ${booking.assignedDate}")
                        appendLine("Assigned Time: ${booking.assignedTime}")
                    }
                    
                    booking.adminNotes?.let { adminNotes ->
                        appendLine("Admin Notes: $adminNotes")
                    }
                    
                    booking.rejectionReason?.let { reason ->
                        appendLine("Rejection Reason: $reason")
                    }
                }
                qualityDetailsText?.text = details
            }
        } catch (e: Exception) {
            showError("Error populating booking details: ${e.message}")
        }
    }
    
    private fun approveBooking(booking: Booking) {
        // Show dialog for admin to assign specific slot
        showSlotAssignmentDialog(booking)
    }
    
    private fun showSlotAssignmentDialog(booking: Booking) {
        // Create a simple selection dialog for dates and times
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Assign Time Slot")
        
        // Create layout for date and time selection
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 40, 50, 40)
        
        // Date spinner
        val dateLabel = TextView(this)
        dateLabel.text = "Select Date:"
        dateLabel.textSize = 16f
        dateLabel.setPadding(0, 0, 0, 10)
        layout.addView(dateLabel)
        
        val dateSpinner = Spinner(this)
        val availableDates = if (booking.preferredDates.isNotEmpty()) {
            booking.preferredDates
        } else {
            // Generate next 7 days as fallback
            val dates = mutableListOf<String>()
            val calendar = java.util.Calendar.getInstance()
            for (i in 0..6) {
                calendar.time = java.util.Date()
                calendar.add(java.util.Calendar.DAY_OF_MONTH, i)
                dates.add(java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(calendar.time))
            }
            dates
        }
        val dateAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, availableDates)
        dateSpinner.adapter = dateAdapter
        layout.addView(dateSpinner)
        
        // Time spinner
        val timeLabel = TextView(this)
        timeLabel.text = "Select Time Slot:"
        timeLabel.textSize = 16f
        timeLabel.setPadding(0, 20, 0, 10)
        layout.addView(timeLabel)
        
        val timeSpinner = Spinner(this)
        val availableTimes = if (booking.preferredTimes.isNotEmpty()) {
            booking.preferredTimes
        } else {
            listOf(
                "9:00 AM - 10:00 AM",
                "10:00 AM - 11:00 AM",
                "11:00 AM - 12:00 PM",
                "2:00 PM - 3:00 PM",
                "3:00 PM - 4:00 PM",
                "4:00 PM - 5:00 PM"
            )
        }
        val timeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, availableTimes)
        timeSpinner.adapter = timeAdapter
        layout.addView(timeSpinner)
        
        // Admin notes
        val notesLabel = TextView(this)
        notesLabel.text = "Admin Notes (optional):"
        notesLabel.textSize = 16f
        notesLabel.setPadding(0, 20, 0, 10)
        layout.addView(notesLabel)
        
        val notesEditText = EditText(this)
        notesEditText.hint = "Enter any notes for the farmer"
        notesEditText.maxLines = 3
        layout.addView(notesEditText)
        
        builder.setView(layout)
        
        builder.setPositiveButton("Approve & Assign") { _, _ ->
            val selectedDate = availableDates[dateSpinner.selectedItemPosition]
            val selectedTime = availableTimes[timeSpinner.selectedItemPosition]
            val adminNotes = notesEditText.text.toString().trim()
            
            confirmBookingWithSlot(booking, selectedDate, selectedTime, adminNotes)
        }
        
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }
    
    private fun confirmBookingWithSlot(booking: Booking, assignedDate: String, assignedTime: String, adminNotes: String) {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                // Update booking with assigned slot
                val updatedBooking = booking.copy(
                    status = BookingStatus.CONFIRMED,
                    assignedDate = assignedDate,
                    assignedTime = assignedTime,
                    reviewedBy = currentUser?.fullName ?: "Admin",
                    adminNotes = adminNotes.ifEmpty { null },
                    updatedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                )
                
                localStorageManager.updateBooking(updatedBooking)
                
                // Add activity log
                val activity = ActivityItem(
                    id = System.currentTimeMillis().toInt(),
                    message = "Booking #${booking.id} approved for ${booking.farmerName} - Assigned: $assignedDate at $assignedTime",
                    timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                    type = "booking_approved"
                )
                localStorageManager.addActivity(activity)
                
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@RequestDetailsActivity, "Booking approved and slot assigned!", Toast.LENGTH_SHORT).show()
                    
                    // Refresh the display
                    loadBookingDetails()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    showError("Error approving booking: ${e.message}")
                }
            }
        }
    }
    
    private fun rejectBooking(booking: Booking) {
        // Show dialog for rejection reason
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Reject Booking Request")
        
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 40, 50, 40)
        
        val reasonLabel = TextView(this)
        reasonLabel.text = "Reason for rejection:"
        reasonLabel.textSize = 16f
        reasonLabel.setPadding(0, 0, 0, 10)
        layout.addView(reasonLabel)
        
        val reasonEditText = EditText(this)
        reasonEditText.hint = "Enter reason for rejecting this booking"
        reasonEditText.maxLines = 4
        reasonEditText.minLines = 2
        layout.addView(reasonEditText)
        
        builder.setView(layout)
        
        builder.setPositiveButton("Reject") { _, _ ->
            val rejectionReason = reasonEditText.text.toString().trim()
            if (rejectionReason.isNotEmpty()) {
                performBookingRejection(booking, rejectionReason)
            } else {
                Toast.makeText(this, "Please provide a reason for rejection", Toast.LENGTH_SHORT).show()
            }
        }
        
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }
    
    private fun performBookingRejection(booking: Booking, rejectionReason: String) {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                // Update booking status with rejection reason
                val updatedBooking = booking.copy(
                    status = BookingStatus.REJECTED,
                    rejectionReason = rejectionReason,
                    reviewedBy = currentUser?.fullName ?: "Admin",
                    updatedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                )
                
                localStorageManager.updateBooking(updatedBooking)
                
                // Add activity log
                val activity = ActivityItem(
                    id = System.currentTimeMillis().toInt(),
                    message = "Booking #${booking.id} rejected for ${booking.farmerName} - Reason: $rejectionReason",
                    timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                    type = "booking_rejected"
                )
                localStorageManager.addActivity(activity)
                
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@RequestDetailsActivity, "Booking rejected successfully", Toast.LENGTH_SHORT).show()
                    
                    // Refresh the display
                    loadBookingDetails()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    showError("Error rejecting booking: ${e.message}")
                }
            }
        }
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        approveButton?.isEnabled = !show
        rejectButton?.isEnabled = !show
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    private fun showErrorState(errorMessage: String) {
        try {
            // Show a basic error message in the details area
            qualityDetailsText?.text = "❌ ERROR\n\n$errorMessage\n\nPlease try again or contact support."
            
            // Hide action buttons in error state
            approveButton?.visibility = View.GONE
            rejectButton?.visibility = View.GONE
            
            // Show basic info
            farmerNameText?.text = "Error loading booking"
            factoryNameText?.text = "N/A"
            quantityText?.text = "N/A"
            bookingDateText?.text = "N/A"
            slotTimeText?.text = "N/A"
            statusText?.text = "ERROR"
            
        } catch (e: Exception) {
            android.util.Log.e("RequestDetails", "Error showing error state", e)
        }
    }
}
