package com.example.hemangoo.ui.booking

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.hemangoo.R

class TestActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Create simple layout programmatically
        val layout = android.widget.LinearLayout(this)
        layout.orientation = android.widget.LinearLayout.VERTICAL
        layout.setPadding(32, 32, 32, 32)
        
        val title = TextView(this)
        title.text = "Test Activity - Navigation Works!"
        title.textSize = 24f
        title.setPadding(0, 0, 0, 32)
        layout.addView(title)
        
        val message = TextView(this)
        message.text = "If you can see this screen, then navigation from FarmerDashboard is working correctly."
        message.setPadding(0, 0, 0, 32)
        layout.addView(message)
        
        val backButton = Button(this)
        backButton.text = "Back to Dashboard"
        backButton.setOnClickListener {
            finish()
        }
        layout.addView(backButton)
        
        setContentView(layout)
        
        Toast.makeText(this, "TestActivity loaded successfully!", Toast.LENGTH_LONG).show()
    }
}