package com.example.hemangoo.ui.booking

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class SubmitQualityActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var farmerNameText: TextView
    private lateinit var farmerLocationText: TextView
    private lateinit var mangoVarietyText: TextView
    private lateinit var quantityText: TextView
    private lateinit var harvestDatePicker: DatePicker
    private lateinit var ripenessRadioGroup: RadioGroup
    private lateinit var colourRadioGroup: RadioGroup
    private lateinit var sizeRadioGroup: RadioGroup
    private lateinit var bruisingRadioGroup: RadioGroup
    private lateinit var pestRadioGroup: RadioGroup
    private lateinit var notesEditText: EditText
    private lateinit var nextButton: Button
    private lateinit var progressBar: ProgressBar
    
    private var mangoType: String = ""
    private var mangoVariety: String = ""
    private var quantity: Double = 0.0
    private var unit: String = ""
    private var factoryId: Int = 0
    private var factoryName: String = ""
    private var currentUser: User? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_submitmangoquality)
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        // Get data from previous activity
        mangoType = intent.getStringExtra("mango_type") ?: ""
        mangoVariety = intent.getStringExtra("mango_variety") ?: ""
        quantity = intent.getDoubleExtra("quantity", 0.0)
        unit = intent.getStringExtra("unit") ?: ""
        factoryId = intent.getIntExtra("factory_id", 0)
        factoryName = intent.getStringExtra("factory_name") ?: ""
        
        initializeViews()
        setupSpinners()
        setupClickListeners()
        populateFarmerInfo()
    }
    
    private fun initializeViews() {
        farmerNameText = findViewById(R.id.farmerNameText)
        farmerLocationText = findViewById(R.id.farmerLocationText)
        mangoVarietyText = findViewById(R.id.mangoVarietyText)
        quantityText = findViewById(R.id.quantityText)
        harvestDatePicker = findViewById(R.id.harvestDatePicker)
        ripenessRadioGroup = findViewById(R.id.rgRipeness)
        colourRadioGroup = findViewById(R.id.rgColor)
        sizeRadioGroup = findViewById(R.id.rgSize)
        bruisingRadioGroup = findViewById(R.id.rgBruising)
        pestRadioGroup = findViewById(R.id.rgPest)
        notesEditText = findViewById(R.id.etComments)
        nextButton = findViewById(R.id.btnSubmit)
        progressBar = findViewById(R.id.progressBar)
        
        progressBar.visibility = View.GONE
    }
    
    private fun setupSpinners() {
        // RadioGroups are already set up in the layout, no need to configure them
        // The radio buttons are already defined in the XML
    }
    
    private fun setupClickListeners() {
        nextButton.setOnClickListener {
            if (validateInputs()) {
                proceedToSlotSelection()
            }
        }
    }
    
    private fun populateFarmerInfo() {
        currentUser?.let { user ->
            try {
                farmerNameText?.text = user.fullName
                farmerLocationText?.text = "Location: ${user.phone}" // Using phone as location for demo
                mangoVarietyText?.text = mangoVariety
                quantityText?.text = "$quantity $unit"
            } catch (e: Exception) {
                showError("Error populating farmer info: ${e.message}")
            }
        }
    }
    
    private fun validateInputs(): Boolean {
        // All required fields are already populated by spinners and switches
        // Additional validation can be added here if needed
        return true
    }
    
    private fun proceedToSlotSelection() {
        val harvestDate = getHarvestDate()
        val qualityReport = QualityReport(
            ripenessLevel = getSelectedRadioButtonText(ripenessRadioGroup),
            colour = getSelectedRadioButtonText(colourRadioGroup),
            size = getSelectedRadioButtonText(sizeRadioGroup),
            bruisingLevel = getSelectedRadioButtonText(bruisingRadioGroup),
            pestPresence = getSelectedRadioButtonText(pestRadioGroup) == "Yes",
            harvestDate = harvestDate,
            notes = notesEditText.text.toString().trim().takeIf { it.isNotEmpty() }
        )
        
        val intent = Intent(this, SelectSlotActivity::class.java)
        intent.putExtra("mango_type", mangoType)
        intent.putExtra("mango_variety", mangoVariety)
        intent.putExtra("quantity", quantity)
        intent.putExtra("unit", unit)
        intent.putExtra("factory_id", factoryId)
        intent.putExtra("factory_name", factoryName)
        intent.putExtra("harvest_date", harvestDate)
        intent.putExtra("quality_report", qualityReport)
        startActivity(intent)
    }
    
    private fun getHarvestDate(): String {
        val day = harvestDatePicker.dayOfMonth
        val month = harvestDatePicker.month + 1 // Month is 0-based
        val year = harvestDatePicker.year
        return String.format("%04d-%02d-%02d", year, month, day)
    }
    
    private fun getSelectedRadioButtonText(radioGroup: RadioGroup): String {
        val selectedId = radioGroup.checkedRadioButtonId
        if (selectedId != -1) {
            val radioButton = findViewById<RadioButton>(selectedId)
            return radioButton.text.toString()
        }
        return ""
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
