package com.example.hemangoo.data.models

import com.google.gson.annotations.SerializedName
import java.util.Date

data class Booking(
    @SerializedName("booking_id")
    val id: Int,
    @SerializedName("farmer_id")
    val farmerId: Int,
    @SerializedName("farmer_name")
    val farmerName: String,
    @SerializedName("factory_id")
    val factoryId: Int,
    @SerializedName("factory_name")
    val factoryName: String,
    @SerializedName("mango_type")
    val mangoType: String,
    @SerializedName("mango_variety")
    val mangoVariety: String,
    @SerializedName("min_quantity")
    val minQuantity: Double = 0.0,
    @SerializedName("max_quantity")
    val maxQuantity: Double = 0.0,
    @SerializedName("quantity")
    val quantity: Double,
    @SerializedName("unit")
    val unit: String,
    @SerializedName("quality_report")
    val qualityReport: QualityReport,
    @SerializedName("preferred_dates")
    val preferredDates: List<String> = emptyList(),
    @SerializedName("preferred_times")
    val preferredTimes: List<String> = emptyList(),
    @SerializedName("assigned_date")
    val assignedDate: String? = null,
    @SerializedName("assigned_time")
    val assignedTime: String? = null,
    @SerializedName("status")
    val status: BookingStatus,
    @SerializedName("reviewed_by")
    val reviewedBy: String? = null,
    @SerializedName("admin_notes")
    val adminNotes: String? = null,
    @SerializedName("rejection_reason")
    val rejectionReason: String? = null,
    @SerializedName("created_at")
    val createdAt: String,
    @SerializedName("updated_at")
    val updatedAt: String,
    @SerializedName("images")
    val images: List<String> = emptyList(),
    
    // Backward compatibility fields
    @SerializedName("booking_date")
    val bookingDate: String = assignedDate ?: "",
    @SerializedName("slot_time")
    val slotTime: String = assignedTime ?: ""
)

data class QualityReport(
    @SerializedName("ripeness_level")
    val ripenessLevel: String, // Unripe, Partially Ripe, Fully Ripe
    @SerializedName("colour")
    val colour: String, // Greenish, Yellow, Golden, Mixed
    @SerializedName("size")
    val size: String, // Small, Medium, Large
    @SerializedName("bruising_level")
    val bruisingLevel: String, // None, Light, Moderate, Heavy
    @SerializedName("pest_presence")
    val pestPresence: Boolean,
    @SerializedName("harvest_date")
    val harvestDate: String,
    @SerializedName("notes")
    val notes: String? = null
) : java.io.Serializable

enum class BookingStatus {
    PENDING,
    CONFIRMED,
    REJECTED
}

data class Factory(
    @SerializedName("id")
    val id: Int,
    @SerializedName("name")
    val name: String,
    @SerializedName("location")
    val location: String,
    @SerializedName("address")
    val address: String,
    @SerializedName("phone")
    val phone: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("capacity_per_day")
    val capacityPerDay: Int,
    @SerializedName("is_active")
    val isActive: Boolean,
    @SerializedName("available_slots")
    val availableSlots: List<TimeSlot> = emptyList()
)

data class TimeSlot(
    @SerializedName("id")
    val id: Int,
    @SerializedName("date")
    val date: String,
    @SerializedName("time")
    val time: String,
    @SerializedName("available_spots")
    val availableSpots: Int,
    @SerializedName("max_capacity")
    val maxCapacity: Int,
    @SerializedName("factory_id")
    val factoryId: Int? = null,
    @SerializedName("factory_name")
    val factoryName: String? = null,
    @SerializedName("available_capacity_kg")
    val availableCapacityKg: Double? = null,
    @SerializedName("max_capacity_kg")
    val maxCapacityKg: Double? = null,
    @SerializedName("price_per_kg")
    val pricePerKg: Double? = null
)

data class MangoVariety(
    @SerializedName("id")
    val id: Int,
    @SerializedName("name")
    val name: String,
    @SerializedName("type")
    val type: String,
    @SerializedName("season_start")
    val seasonStart: String,
    @SerializedName("season_end")
    val seasonEnd: String,
    @SerializedName("description")
    val description: String,
    @SerializedName("base_price_per_kg")
    val basePricePerKg: Double,
    @SerializedName("is_active")
    val isActive: Boolean,
    @SerializedName("image_url")
    val imageUrl: String? = null
)

data class MarketData(
    @SerializedName("date")
    val date: String,
    @SerializedName("price_per_kg")
    val pricePerKg: Double,
    @SerializedName("average_buyers")
    val averageBuyers: Int,
    @SerializedName("active_buyers")
    val activeBuyers: Int,
    @SerializedName("market_trend")
    val marketTrend: String, // Rising, Falling, Stable
    @SerializedName("total_volume")
    val totalVolume: Double
)

data class DashboardStats(
    @SerializedName("total_bookings")
    val totalBookings: Int,
    @SerializedName("pending_bookings")
    val pendingBookings: Int,
    @SerializedName("confirmed_bookings")
    val confirmedBookings: Int,
    @SerializedName("rejected_bookings")
    val rejectedBookings: Int,
    @SerializedName("todays_market_price")
    val todaysMarketPrice: Double,
    @SerializedName("recent_activity")
    val recentActivity: List<ActivityItem> = emptyList()
)

data class ActivityItem(
    @SerializedName("id")
    val id: Int,
    @SerializedName("message")
    val message: String,
    @SerializedName("timestamp")
    val timestamp: String,
    @SerializedName("type")
    val type: String // booking_confirmed, booking_rejected, new_booking, etc.
)
