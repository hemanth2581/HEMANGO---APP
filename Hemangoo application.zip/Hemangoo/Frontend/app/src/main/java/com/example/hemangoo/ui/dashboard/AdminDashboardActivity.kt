package com.example.hemangoo.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.ui.auth.LoginActivity
import com.example.hemangoo.data.models.*
import com.example.hemangoo.data.api.ApiClient
import com.example.hemangoo.ui.admin.PendingRequestsActivity
import kotlinx.coroutines.launch
import android.util.Log

class AdminDashboardActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var apiClient: ApiClient
    private lateinit var welcomeText: TextView
    private lateinit var logoutButton: Button
    private lateinit var viewPendingRequestsBtn: Button
    private lateinit var viewMarketDataBtn: Button
    private lateinit var manageMangoPricesBtn: Button
    private lateinit var progressBar: ProgressBar
    
    // Stats TextViews
    private lateinit var totalBookingsText: TextView
    private lateinit var pendingRequestsText: TextView
    private lateinit var approvedTodayText: TextView
    private lateinit var rejectedTodayText: TextView
    
    // Market data TextViews
    private lateinit var marketPriceText: TextView
    private lateinit var marketTrendText: TextView
    private lateinit var activeBuyersText: TextView
    
    private var currentUser: User? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)
        
        localStorageManager = LocalStorageManager(this)
        apiClient = ApiClient(this)
        
        // Check if user is logged in
        currentUser = localStorageManager.getCurrentUser()
        if (currentUser == null) {
            redirectToLogin()
            return
        }
        
        initializeViews()
        setupClickListeners()
        loadDashboardData()
    }
    
    private fun initializeViews() {
        welcomeText = findViewById(R.id.welcomeText)
        logoutButton = findViewById(R.id.logoutBtn)
        viewPendingRequestsBtn = findViewById(R.id.viewPendingRequestsBtn)
        viewMarketDataBtn = findViewById(R.id.viewMarketDataBtn)
        manageMangoPricesBtn = findViewById(R.id.manageMangoPricesBtn)
        progressBar = findViewById(R.id.progressBar)
        
        // Stats TextViews
        totalBookingsText = findViewById(R.id.totalBookingsText)
        pendingRequestsText = findViewById(R.id.pendingRequestsText)
        approvedTodayText = findViewById(R.id.approvedTodayText)
        rejectedTodayText = findViewById(R.id.rejectedTodayText)
        
        // Market data TextViews
        marketPriceText = findViewById(R.id.marketPriceText)
        marketTrendText = findViewById(R.id.marketTrendText)
        activeBuyersText = findViewById(R.id.activeBuyersText)
        
        // Hide progress bar initially
        progressBar.visibility = View.GONE
    }
    
    private fun setupClickListeners() {
        logoutButton.setOnClickListener {
            localStorageManager.logout()
            redirectToLogin()
        }
        
        viewPendingRequestsBtn.setOnClickListener {
            viewPendingRequests()
        }
        
        viewMarketDataBtn.setOnClickListener {
            viewMarketData()
        }
        
        manageMangoPricesBtn.setOnClickListener {
            manageMangoPrices()
        }
        
        // Add test functionality to the pending requests button (long press)
        viewPendingRequestsBtn.setOnLongClickListener {
            testBookingFlow()
            true
        }
    }
    
    private fun loadDashboardData() {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                // Load all bookings to get stats
                val allBookings = localStorageManager.getAllBookings()
                val pendingBookings = localStorageManager.getPendingBookings()
                
                // Get market data
                val marketDataList = localStorageManager.getMarketData()
                val latestMarketData = marketDataList.maxByOrNull { it.date }
                
                // Get recent activities
                val activities = localStorageManager.getAllActivities()
                val recentActivities = activities.take(5)
                
                val stats = DashboardStats(
                    totalBookings = allBookings.size,
                    pendingBookings = pendingBookings.size,
                    confirmedBookings = allBookings.count { it.status == BookingStatus.CONFIRMED },
                    rejectedBookings = allBookings.count { it.status == BookingStatus.REJECTED },
                    todaysMarketPrice = latestMarketData?.pricePerKg ?: 120.0,
                    recentActivity = recentActivities
                )
                
                runOnUiThread {
                    updateDashboardUI(stats, latestMarketData)
                    showProgress(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@AdminDashboardActivity, "Error loading dashboard data: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun updateDashboardUI(stats: DashboardStats, marketData: MarketData?) {
        try {
            currentUser?.let { user ->
                welcomeText?.text = "Welcome, ${user.fullName}!"
            }
            
            // Update stats with null safety
            totalBookingsText?.text = stats.totalBookings.toString()
            pendingRequestsText?.text = stats.pendingBookings.toString()
            approvedTodayText?.text = stats.confirmedBookings.toString()
            rejectedTodayText?.text = stats.rejectedBookings.toString()
            
            // Update market data with null safety
            marketData?.let { data ->
                marketPriceText?.text = "₹${data.pricePerKg}/kg"
                marketTrendText?.text = data.marketTrend
                activeBuyersText?.text = data.activeBuyers.toString()
            } ?: run {
                // Set default values when market data is null
                marketPriceText?.text = "₹0/kg"
                marketTrendText?.text = "N/A"
                activeBuyersText?.text = "0"
            }
        } catch (e: Exception) {
            showError("Error updating dashboard UI: ${e.message}")
        }
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    private fun viewPendingRequests() {
        val intent = Intent(this, PendingRequestsActivity::class.java)
        startActivity(intent)
    }
    
    
    private fun viewMarketData() {
        // Show market data management dialog
        showMarketDataManagementDialog()
    }
    
    private fun showMarketDataManagementDialog() {
        val marketDataList = localStorageManager.getMarketData()
        val latestMarketData = marketDataList.maxByOrNull { it.date }
        
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Manage Market Data")
        
        // Create dialog layout
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 40, 50, 40)
        
        // Current values display
        val currentValuesText = TextView(this)
        val currentText = if (latestMarketData != null) {
            "Current Values:\n" +
            "Price: ₹${latestMarketData.pricePerKg}/kg\n" +
            "Trend: ${latestMarketData.marketTrend}\n" +
            "Active Buyers: ${latestMarketData.activeBuyers}\n" +
            "Total Volume: ${latestMarketData.totalVolume} kg\n" +
            "Last Updated: ${latestMarketData.date}\n"
        } else {
            "No market data available\n"
        }
        currentValuesText.text = currentText
        currentValuesText.textSize = 14f
        currentValuesText.setPadding(0, 0, 0, 20)
        layout.addView(currentValuesText)
        
        // Price per kg input
        val priceLabel = TextView(this)
        priceLabel.text = "New Price per kg (₹):"
        priceLabel.textSize = 16f
        priceLabel.setPadding(0, 10, 0, 5)
        layout.addView(priceLabel)
        
        val priceEditText = EditText(this)
        priceEditText.hint = "Enter price (e.g., 120.50)"
        priceEditText.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        if (latestMarketData != null) {
            priceEditText.setText(latestMarketData.pricePerKg.toString())
        }
        layout.addView(priceEditText)
        
        // Market trend dropdown
        val trendLabel = TextView(this)
        trendLabel.text = "Market Trend:"
        trendLabel.textSize = 16f
        trendLabel.setPadding(0, 15, 0, 5)
        layout.addView(trendLabel)
        
        val trendSpinner = Spinner(this)
        val trendOptions = arrayOf("Rising", "Falling", "Stable")
        val trendAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, trendOptions)
        trendSpinner.adapter = trendAdapter
        if (latestMarketData != null) {
            val currentTrendIndex = trendOptions.indexOf(latestMarketData.marketTrend)
            if (currentTrendIndex >= 0) {
                trendSpinner.setSelection(currentTrendIndex)
            }
        }
        layout.addView(trendSpinner)
        
        // Active buyers input
        val buyersLabel = TextView(this)
        buyersLabel.text = "Active Buyers:"
        buyersLabel.textSize = 16f
        buyersLabel.setPadding(0, 15, 0, 5)
        layout.addView(buyersLabel)
        
        val buyersEditText = EditText(this)
        buyersEditText.hint = "Enter number of active buyers"
        buyersEditText.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        if (latestMarketData != null) {
            buyersEditText.setText(latestMarketData.activeBuyers.toString())
        }
        layout.addView(buyersEditText)
        
        // Total volume input
        val volumeLabel = TextView(this)
        volumeLabel.text = "Total Volume (kg):"
        volumeLabel.textSize = 16f
        volumeLabel.setPadding(0, 15, 0, 5)
        layout.addView(volumeLabel)
        
        val volumeEditText = EditText(this)
        volumeEditText.hint = "Enter total volume in kg"
        volumeEditText.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        if (latestMarketData != null) {
            volumeEditText.setText(latestMarketData.totalVolume.toString())
        }
        layout.addView(volumeEditText)
        
        builder.setView(layout)
        
        builder.setPositiveButton("Update Market Data") { _, _ ->
            updateMarketData(
                priceEditText.text.toString(),
                trendSpinner.selectedItem.toString(),
                buyersEditText.text.toString(),
                volumeEditText.text.toString()
            )
        }
        
        builder.setNeutralButton("View Only") { _, _ ->
            showReadOnlyMarketDataDialog()
        }
        
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }
    
    private fun showReadOnlyMarketDataDialog() {
        val marketDataList = localStorageManager.getMarketData()
        val latestMarketData = marketDataList.maxByOrNull { it.date }
        
        val message = if (latestMarketData != null) {
            "Current Market Price: ₹${latestMarketData.pricePerKg}/kg\n" +
            "Market Trend: ${latestMarketData.marketTrend}\n" +
            "Active Buyers: ${latestMarketData.activeBuyers}\n" +
            "Total Volume: ${latestMarketData.totalVolume} kg\n" +
            "Date: ${latestMarketData.date}"
        } else {
            "No market data available"
        }
        
        android.app.AlertDialog.Builder(this)
            .setTitle("Market Data")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }
    
    private fun updateMarketData(priceStr: String, trend: String, buyersStr: String, volumeStr: String) {
        try {
            // Validate inputs
            val price = priceStr.toDoubleOrNull()
            if (price == null || price <= 0) {
                showError("Please enter a valid price")
                return
            }
            
            val buyers = buyersStr.toIntOrNull()
            if (buyers == null || buyers < 0) {
                showError("Please enter a valid number of active buyers")
                return
            }
            
            val volume = volumeStr.toDoubleOrNull()
            if (volume == null || volume < 0) {
                showError("Please enter a valid total volume")
                return
            }
            
            showProgress(true)
            
            lifecycleScope.launch {
                try {
                    // Create new market data entry
                    val currentDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
                    val newMarketData = MarketData(
                        date = currentDate,
                        pricePerKg = price,
                        averageBuyers = buyers, // Using same value for average and active for simplicity
                        activeBuyers = buyers,
                        marketTrend = trend,
                        totalVolume = volume
                    )
                    
                    // Update market data in local storage
                    val result = localStorageManager.updateMarketData(newMarketData)
                    
                    if (result.isSuccess) {
                        // Add activity log
                        val activity = ActivityItem(
                            id = System.currentTimeMillis().toInt(),
                            message = "Market data updated by ${currentUser?.fullName ?: "Admin"} - Price: ₹$price/kg, Trend: $trend",
                            timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                            type = "market_data_updated"
                        )
                        localStorageManager.addActivity(activity)
                        
                        runOnUiThread {
                            showProgress(false)
                            Toast.makeText(this@AdminDashboardActivity, "Market data updated successfully!", Toast.LENGTH_SHORT).show()
                            // Refresh dashboard to show new data
                            loadDashboardData()
                        }
                    } else {
                        runOnUiThread {
                            showProgress(false)
                            showError("Failed to update market data: ${result.exceptionOrNull()?.message}")
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        showProgress(false)
                        showError("Error updating market data: ${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            showError("Error processing market data: ${e.message}")
        }
    }
    
    private fun manageMangoPrices() {
        showMangoPricesManagementDialog()
    }
    
    private fun showMangoPricesManagementDialog() {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                val mangoVarieties = localStorageManager.getAllMangoVarieties()
                
                runOnUiThread {
                    showProgress(false)
                    
                    if (mangoVarieties.isEmpty()) {
                        showError("No mango varieties found. Please add varieties first.")
                        return@runOnUiThread
                    }
                    
                    showMangoPricesDialog(mangoVarieties)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    showError("Error loading mango varieties: ${e.message}")
                }
            }
        }
    }
    
    private fun showMangoPricesDialog(varieties: List<MangoVariety>) {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Manage Mango Variety Prices")
        
        // Create scrollable layout
        val scrollView = ScrollView(this)
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 40, 50, 40)
        
        // Title
        val titleText = TextView(this)
        titleText.text = "Update prices for mango varieties (₹/kg):"
        titleText.textSize = 16f
        titleText.setTypeface(null, android.graphics.Typeface.BOLD)
        titleText.setPadding(0, 0, 0, 20)
        layout.addView(titleText)
        
        // Store EditText references for later use
        val priceInputs = mutableMapOf<Int, EditText>()
        
        varieties.forEach { variety ->
            // Variety card
            val varietyCard = LinearLayout(this)
            varietyCard.orientation = LinearLayout.VERTICAL
            varietyCard.setPadding(20, 15, 20, 15)
            varietyCard.setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
            val cardParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            cardParams.setMargins(0, 0, 0, 10)
            varietyCard.layoutParams = cardParams
            
            // Variety name and type
            val nameText = TextView(this)
            nameText.text = "${variety.name} (${variety.type})"
            nameText.textSize = 16f
            nameText.setTypeface(null, android.graphics.Typeface.BOLD)
            varietyCard.addView(nameText)
            
            // Season info
            val seasonText = TextView(this)
            seasonText.text = "Season: ${variety.seasonStart} - ${variety.seasonEnd}"
            seasonText.textSize = 12f
            seasonText.setTextColor(android.graphics.Color.GRAY)
            varietyCard.addView(seasonText)
            
            // Current price and input
            val priceLayout = LinearLayout(this)
            priceLayout.orientation = LinearLayout.HORIZONTAL
            priceLayout.setPadding(0, 10, 0, 0)
            
            val priceLabel = TextView(this)
            priceLabel.text = "Price: ₹"
            priceLabel.textSize = 14f
            priceLabel.setPadding(0, 0, 10, 0)
            priceLayout.addView(priceLabel)
            
            val priceInput = EditText(this)
            priceInput.setText(variety.basePricePerKg.toString())
            priceInput.hint = "Enter price per kg"
            priceInput.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            priceInput.layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
            priceLayout.addView(priceInput)
            
            val kgLabel = TextView(this)
            kgLabel.text = "/kg"
            kgLabel.textSize = 14f
            kgLabel.setPadding(5, 0, 0, 0)
            priceLayout.addView(kgLabel)
            
            varietyCard.addView(priceLayout)
            layout.addView(varietyCard)
            
            // Store reference to price input
            priceInputs[variety.id] = priceInput
        }
        
        scrollView.addView(layout)
        builder.setView(scrollView)
        
        builder.setPositiveButton("Update Prices") { _, _ ->
            updateMangoPrices(varieties, priceInputs)
        }
        
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }
        
        builder.show()
    }
    
    private fun updateMangoPrices(varieties: List<MangoVariety>, priceInputs: Map<Int, EditText>) {
        try {
            showProgress(true)
            
            lifecycleScope.launch {
                try {
                    val updatedVarieties = varieties.map { variety ->
                        val priceInput = priceInputs[variety.id]
                        val newPriceStr = priceInput?.text?.toString()?.trim() ?: ""
                        
                        val newPrice = newPriceStr.toDoubleOrNull()
                        if (newPrice == null || newPrice < 0) {
                            throw Exception("Invalid price for ${variety.name}: '$newPriceStr'")
                        }
                        
                        variety.copy(basePricePerKg = newPrice)
                    }
                    
                    // Save updated varieties
                    localStorageManager.saveMangoVarieties(updatedVarieties)
                    
                    // Add activity log
                    val activity = ActivityItem(
                        id = System.currentTimeMillis().toInt(),
                        message = "Mango variety prices updated by ${currentUser?.fullName ?: "Admin"}",
                        timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                        type = "mango_prices_updated"
                    )
                    localStorageManager.addActivity(activity)
                    
                    runOnUiThread {
                        showProgress(false)
                        Toast.makeText(this@AdminDashboardActivity, "Mango prices updated successfully!", Toast.LENGTH_SHORT).show()
                    }
                    
                } catch (e: Exception) {
                    runOnUiThread {
                        showProgress(false)
                        showError("Error updating prices: ${e.message}")
                    }
                }
            }
        } catch (e: Exception) {
            showProgress(false)
            showError("Error processing price updates: ${e.message}")
        }
    }
    
    private fun redirectToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    private fun testBookingFlow() {
        try {
            showProgress(true)
            Toast.makeText(this, "Testing admin panel...", Toast.LENGTH_SHORT).show()
            
            lifecycleScope.launch {
                try {
                    // Test admin functionality
                    val allBookings = localStorageManager.getAllBookings()
                    val pendingBookings = localStorageManager.getPendingBookings()
                    val confirmedBookings = localStorageManager.getBookingsByStatus(BookingStatus.CONFIRMED)
                    val rejectedBookings = localStorageManager.getBookingsByStatus(BookingStatus.REJECTED)
                    
                    Log.d("AdminDashboard", "=== ADMIN PANEL TEST ===")
                    Log.d("AdminDashboard", "Total Bookings: ${allBookings.size}")
                    Log.d("AdminDashboard", "Pending Bookings: ${pendingBookings.size}")
                    Log.d("AdminDashboard", "Confirmed Bookings: ${confirmedBookings.size}")
                    Log.d("AdminDashboard", "Rejected Bookings: ${rejectedBookings.size}")
                    
                    // Test booking approval if there are pending bookings
                    if (pendingBookings.isNotEmpty()) {
                        val testBooking = pendingBookings.first()
                        Log.d("AdminDashboard", "Testing approval for booking ID: ${testBooking.id}")
                        
                        val updatedBooking = testBooking.copy(
                            status = BookingStatus.CONFIRMED,
                            updatedAt = "2024-01-15 10:30:00"
                        )
                        
                        val result = localStorageManager.updateBooking(updatedBooking)
                        if (result.isSuccess) {
                            Log.d("AdminDashboard", "Test approval successful!")
                        } else {
                            Log.e("AdminDashboard", "Test approval failed: ${result.exceptionOrNull()?.message}")
                        }
                    }
                    
                    runOnUiThread {
                        showProgress(false)
                        Toast.makeText(this@AdminDashboardActivity, "Admin test completed! Check logs for details.", Toast.LENGTH_LONG).show()
                        loadDashboardData() // Refresh dashboard data
                    }
                } catch (e: Exception) {
                    Log.e("AdminDashboard", "Admin test failed", e)
                    runOnUiThread {
                        showProgress(false)
                        Toast.makeText(this@AdminDashboardActivity, "Admin test failed: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        } catch (e: Exception) {
            showProgress(false)
            Toast.makeText(this, "Error running admin test: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        viewPendingRequestsBtn.isEnabled = !show
    }
    
    override fun onResume() {
        super.onResume()
        // Refresh data when returning to dashboard
        loadDashboardData()
    }
}
