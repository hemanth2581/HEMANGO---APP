package com.example.hemangoo.ui.booking

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import com.example.hemangoo.data.api.ApiClient
import com.example.hemangoo.ui.dashboard.FarmerDashboardActivity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class BookingConfirmationActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var apiClient: ApiClient
    private lateinit var farmerNameText: TextView
    private lateinit var factoryNameText: TextView
    private lateinit var mangoVarietyText: TextView
    private lateinit var quantityText: TextView
    private lateinit var bookingDateText: TextView
    private lateinit var slotTimeText: TextView
    private lateinit var qualityDetailsText: TextView
    private lateinit var confirmButton: Button
    private lateinit var cancelButton: Button
    private lateinit var progressBar: ProgressBar
    
    private var mangoType: String = ""
    private var mangoVariety: String = ""
    private var quantity: Double = 0.0
    private var unit: String = ""
    private var factoryId: Int = 0
    private var factoryName: String = ""
    private var harvestDate: String = ""
    private var qualityReport: QualityReport? = null
    private var slotId: Int = 0
    private var slotDate: String = ""
    private var slotTime: String = ""
    private var currentUser: User? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookingdetails)
        
        localStorageManager = LocalStorageManager(this)
        apiClient = ApiClient(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        // Get data from previous activity
        mangoType = intent.getStringExtra("mango_type") ?: ""
        mangoVariety = intent.getStringExtra("mango_variety") ?: ""
        quantity = intent.getDoubleExtra("quantity", 0.0)
        unit = intent.getStringExtra("unit") ?: ""
        factoryId = intent.getIntExtra("factory_id", 0)
        factoryName = intent.getStringExtra("factory_name") ?: ""
        harvestDate = intent.getStringExtra("harvest_date") ?: ""
        qualityReport = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("quality_report", QualityReport::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("quality_report") as? QualityReport
        }
        slotId = intent.getIntExtra("slot_id", 0)
        slotDate = intent.getStringExtra("slot_date") ?: ""
        slotTime = intent.getStringExtra("slot_time") ?: ""
        
        // Validate required data
        if (mangoType.isEmpty() || quantity <= 0 || factoryId == 0 || slotId == 0) {
            android.util.Log.e("BookingConfirmation", "Missing required data: mangoType=$mangoType, quantity=$quantity, factoryId=$factoryId, slotId=$slotId")
            showError("Invalid booking data. Please start the booking process again.")
            finish()
            return
        }
        
        android.util.Log.d("BookingConfirmation", "Received data: $mangoType, $quantity $unit, factory=$factoryName, slot=$slotTime")
        
        initializeViews()
        setupClickListeners()
        populateBookingDetails()
    }
    
    private fun initializeViews() {
        // Update these to match actual layout IDs from activity_bookingdetails.xml
        farmerNameText = findViewById(R.id.tvFruitName)  // Mango variety/type
        factoryNameText = findViewById(R.id.tvFactoryName)
        mangoVarietyText = findViewById(R.id.tvFruitName) // Same as farmer name for now
        quantityText = findViewById(R.id.tvFruitWeight)
        bookingDateText = findViewById(R.id.tvDate)
        slotTimeText = findViewById(R.id.tvTime)
        qualityDetailsText = findViewById(R.id.tvBookingDate)
        confirmButton = findViewById(R.id.btnRebookSlot) // This is the "Approve" button
        cancelButton = findViewById(R.id.btnBack) // This is the back ImageButton
        progressBar = findViewById(R.id.progressBar)
        
        // Initialize UI state
        progressBar.visibility = View.GONE
        confirmButton.text = "Confirm Booking"
    }
    
    private fun setupClickListeners() {
        confirmButton.setOnClickListener {
            confirmBooking()
        }
        
        cancelButton.setOnClickListener {
            finish()
        }
    }
    
    private fun populateBookingDetails() {
        try {
            // Update booking ID if available
            val bookingIdText = findViewById<TextView>(R.id.tvBookingID)
            bookingIdText?.text = "Booking #BK${System.currentTimeMillis() % 10000}"
            
            // Update status chip
            val statusChip = findViewById<com.google.android.material.chip.Chip>(R.id.chipStatus)
            statusChip?.text = "Pending"
            statusChip?.chipBackgroundColor = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FFA000"))
            
            // Set mango details
            farmerNameText?.text = "$mangoType $mangoVariety"
            quantityText?.text = "$quantity $unit"
            
            // Set factory details
            factoryNameText?.text = factoryName
            
            // Set date and time
            bookingDateText?.text = slotDate
            slotTimeText?.text = slotTime
            
            // Set booking creation date
            qualityDetailsText?.text = "Booked on ${getCurrentDateTime()}"
            
            // Update quality details if available
            qualityReport?.let { report ->
                updateQualityDetailsInGrid(report)
            }
        } catch (e: Exception) {
            showError("Error populating booking details: ${e.message}")
        }
    }
    
    private fun updateQualityDetailsInGrid(report: QualityReport) {
        // The layout has hardcoded quality details, but we can update some key ones
        // This would require more complex layout manipulation, so for now just log the data
        android.util.Log.d("BookingConfirmation", "Quality Report: $report")
    }
    
    private fun confirmBooking() {
        // Validate required data before proceeding
        if (mangoType.isEmpty() || mangoVariety.isEmpty() || quantity <= 0 || factoryId == 0 || slotId == 0) {
            showError("Missing required booking information. Please go back and complete all steps.")
            return
        }
        
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                currentUser?.let { user ->
                    Toast.makeText(this@BookingConfirmationActivity, "Processing booking...", Toast.LENGTH_SHORT).show()
                    
                    // Initialize sample data if not already done
                    // Data is automatically initialized in LocalStorageManager constructor
                    
                    // Create the booking with proper data structure
                    val booking = Booking(
                        id = 0, // Will be set by createBooking
                        farmerId = user.id,
                        farmerName = user.fullName,
                        factoryId = factoryId,
                        factoryName = factoryName,
                        mangoType = mangoType,
                        mangoVariety = mangoVariety,
                        quantity = quantity,
                        unit = unit,
                        qualityReport = qualityReport ?: QualityReport(
                            ripenessLevel = "Not Specified",
                            colour = "Not Specified",
                            size = "Not Specified",
                            bruisingLevel = "Not Specified",
                            pestPresence = false,
                            harvestDate = harvestDate,
                            notes = null
                        ),
                        bookingDate = slotDate,
                        slotTime = slotTime,
                        status = BookingStatus.PENDING,
                        createdAt = getCurrentDateTimeForBooking(),
                        updatedAt = getCurrentDateTimeForBooking(),
                        images = emptyList()
                    )
                    
                    val bookingResult = apiClient.submitBooking(
                        userId = user.id,
                        factoryId = factoryId,
                        timeSlotId = slotId,
                        mangoType = mangoType,
                        mangoVariety = mangoVariety,
                        quantity = quantity,
                        unit = unit,
                        bookingDate = slotDate,
                        slotTime = slotTime,
                        qualityReport = qualityReport ?: QualityReport(
                            ripenessLevel = "Not Specified",
                            colour = "Not Specified",
                            size = "Not Specified",
                            bruisingLevel = "Not Specified",
                            pestPresence = false,
                            harvestDate = harvestDate,
                            notes = null
                        )
                    )
                    
                    bookingResult.fold(
                        onSuccess = { message ->
                            runOnUiThread {
                                showProgress(false)
                                
                                // Show success dialog or message
                                android.app.AlertDialog.Builder(this@BookingConfirmationActivity)
                                    .setTitle("Booking Confirmed!")
                                    .setMessage("Your booking has been created successfully.\n\nFactory: $factoryName\nSlot: $slotTime on $slotDate\n\n$message")
                                    .setPositiveButton("OK") { _, _ ->
                                        // Navigate back to dashboard
                                        val intent = Intent(this@BookingConfirmationActivity, FarmerDashboardActivity::class.java)
                                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                        startActivity(intent)
                                        finish()
                                    }
                                    .setCancelable(false)
                                    .show()
                            }
                        },
                        onFailure = { error ->
                            runOnUiThread {
                                showProgress(false)
                                Toast.makeText(this@BookingConfirmationActivity, "Error creating booking: ${error.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@BookingConfirmationActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun getCurrentDateTime(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date())
    }
    
    private fun getCurrentDateTimeForBooking(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date())
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        confirmButton.isEnabled = !show
        cancelButton.isEnabled = !show
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
