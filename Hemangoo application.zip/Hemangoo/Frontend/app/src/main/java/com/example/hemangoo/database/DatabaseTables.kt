package com.example.hemangoo.database

import com.example.hemangoo.database.LocalDatabaseSchema.Tables
import com.example.hemangoo.database.LocalDatabaseSchema.Columns

/**
 * DATABASE TABLE CREATION STATEMENTS
 * 
 * This file contains all SQL CREATE TABLE statements for the offline database.
 * It's separated from the schema for better organization and maintainability.
 */
object DatabaseTables {
    
    // SQL CREATE TABLE statements
    object CreateTables {
        
        const val CREATE_USERS_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.USERS} (
                ${Columns.Users.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.Users.FULL_NAME} TEXT NOT NULL,
                ${Columns.Users.EMAIL} TEXT UNIQUE NOT NULL,
                ${Columns.Users.PHONE} TEXT NOT NULL,
                ${Columns.Users.PASSWORD_HASH} TEXT NOT NULL,
                ${Columns.Users.ROLE} TEXT NOT NULL CHECK (${Columns.Users.ROLE} IN ('farmer', 'admin')),
                ${Columns.Users.LOCATION} TEXT,
                ${Columns.Users.IS_ACTIVE} INTEGER NOT NULL DEFAULT 1,
                ${Columns.Users.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ${Columns.Users.UPDATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """
        
        const val CREATE_FACTORIES_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.FACTORIES} (
                ${Columns.Factories.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.Factories.NAME} TEXT NOT NULL,
                ${Columns.Factories.LOCATION} TEXT NOT NULL,
                ${Columns.Factories.ADDRESS} TEXT,
                ${Columns.Factories.PHONE} TEXT,
                ${Columns.Factories.EMAIL} TEXT,
                ${Columns.Factories.CAPACITY_PER_DAY} INTEGER NOT NULL DEFAULT 1000,
                ${Columns.Factories.IS_ACTIVE} INTEGER NOT NULL DEFAULT 1,
                ${Columns.Factories.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ${Columns.Factories.UPDATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """
        
        const val CREATE_MANGO_VARIETIES_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.MANGO_VARIETIES} (
                ${Columns.MangoVarieties.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.MangoVarieties.NAME} TEXT NOT NULL,
                ${Columns.MangoVarieties.TYPE} TEXT NOT NULL,
                ${Columns.MangoVarieties.SEASON_START} TEXT,
                ${Columns.MangoVarieties.SEASON_END} TEXT,
                ${Columns.MangoVarieties.DESCRIPTION} TEXT,
                ${Columns.MangoVarieties.BASE_PRICE_PER_KG} REAL NOT NULL DEFAULT 0.0,
                ${Columns.MangoVarieties.IMAGE_URL} TEXT,
                ${Columns.MangoVarieties.IS_ACTIVE} INTEGER NOT NULL DEFAULT 1,
                ${Columns.MangoVarieties.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """
        
        val CREATE_TIME_SLOTS_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.TIME_SLOTS} (
                ${Columns.TimeSlots.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.TimeSlots.FACTORY_ID} INTEGER NOT NULL,
                ${Columns.TimeSlots.SLOT_DATE} TEXT NOT NULL,
                ${Columns.TimeSlots.START_TIME} TEXT NOT NULL,
                ${Columns.TimeSlots.END_TIME} TEXT NOT NULL,
                ${Columns.TimeSlots.MAX_CAPACITY_KG} INTEGER NOT NULL DEFAULT 1000,
                ${Columns.TimeSlots.CURRENT_BOOKINGS_KG} INTEGER NOT NULL DEFAULT 0,
                ${Columns.TimeSlots.PRICE_PER_KG} REAL NOT NULL DEFAULT 0.0,
                ${Columns.TimeSlots.IS_AVAILABLE} INTEGER NOT NULL DEFAULT 1,
                ${Columns.TimeSlots.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ${Columns.TimeSlots.UPDATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (${Columns.TimeSlots.FACTORY_ID}) REFERENCES ${Tables.FACTORIES}(${Columns.Factories.ID}) ON DELETE CASCADE,
                UNIQUE(${Columns.TimeSlots.FACTORY_ID}, ${Columns.TimeSlots.SLOT_DATE}, ${Columns.TimeSlots.START_TIME})
            )
        """
        
        const val CREATE_QUALITY_REPORTS_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.QUALITY_REPORTS} (
                ${Columns.QualityReports.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.QualityReports.USER_ID} INTEGER NOT NULL,
                ${Columns.QualityReports.MANGO_TYPE} TEXT NOT NULL,
                ${Columns.QualityReports.MANGO_VARIETY} TEXT NOT NULL,
                ${Columns.QualityReports.ESTIMATED_QUANTITY} REAL NOT NULL,
                ${Columns.QualityReports.UNIT} TEXT NOT NULL DEFAULT 'kg',
                ${Columns.QualityReports.HARVEST_DATE} TEXT NOT NULL,
                ${Columns.QualityReports.RIPENESS_LEVEL} TEXT NOT NULL CHECK (${Columns.QualityReports.RIPENESS_LEVEL} IN ('Unripe', 'Partially Ripe', 'Fully Ripe')),
                ${Columns.QualityReports.COLOUR} TEXT NOT NULL CHECK (${Columns.QualityReports.COLOUR} IN ('Greenish', 'Yellow', 'Golden', 'Mixed')),
                ${Columns.QualityReports.SIZE} TEXT NOT NULL CHECK (${Columns.QualityReports.SIZE} IN ('Small', 'Medium', 'Large')),
                ${Columns.QualityReports.BRUISING_LEVEL} TEXT NOT NULL CHECK (${Columns.QualityReports.BRUISING_LEVEL} IN ('None', 'Light', 'Moderate', 'Heavy')),
                ${Columns.QualityReports.PEST_PRESENCE} INTEGER NOT NULL DEFAULT 0,
                ${Columns.QualityReports.ADDITIONAL_NOTES} TEXT,
                ${Columns.QualityReports.IMAGES} TEXT,
                ${Columns.QualityReports.ADMIN_REVIEW_STATUS} TEXT NOT NULL DEFAULT 'pending' CHECK (${Columns.QualityReports.ADMIN_REVIEW_STATUS} IN ('pending', 'approved', 'rejected')),
                ${Columns.QualityReports.ADMIN_NOTES} TEXT,
                ${Columns.QualityReports.REVIEWED_BY} INTEGER,
                ${Columns.QualityReports.REVIEWED_AT} TEXT,
                ${Columns.QualityReports.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ${Columns.QualityReports.UPDATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (${Columns.QualityReports.USER_ID}) REFERENCES ${Tables.USERS}(${Columns.Users.ID}) ON DELETE CASCADE,
                FOREIGN KEY (${Columns.QualityReports.REVIEWED_BY}) REFERENCES ${Tables.USERS}(${Columns.Users.ID}) ON DELETE SET NULL
            )
        """
        
        val CREATE_BOOKINGS_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.BOOKINGS} (
                ${Columns.Bookings.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.Bookings.USER_ID} INTEGER NOT NULL,
                ${Columns.Bookings.FACTORY_ID} INTEGER NOT NULL,
                ${Columns.Bookings.TIME_SLOT_ID} INTEGER NOT NULL,
                ${Columns.Bookings.QUALITY_REPORT_ID} INTEGER,
                ${Columns.Bookings.MANGO_TYPE} TEXT NOT NULL,
                ${Columns.Bookings.MANGO_VARIETY} TEXT NOT NULL,
                ${Columns.Bookings.QUANTITY} REAL NOT NULL,
                ${Columns.Bookings.UNIT} TEXT NOT NULL DEFAULT 'kg',
                ${Columns.Bookings.BOOKING_DATE} TEXT NOT NULL,
                ${Columns.Bookings.SLOT_TIME} TEXT NOT NULL,
                ${Columns.Bookings.STATUS} TEXT NOT NULL DEFAULT 'pending' CHECK (${Columns.Bookings.STATUS} IN ('pending', 'confirmed', 'rejected', 'completed', 'cancelled')),
                ${Columns.Bookings.REVIEWED_BY} INTEGER,
                ${Columns.Bookings.REVIEWED_AT} TEXT,
                ${Columns.Bookings.ADMIN_NOTES} TEXT,
                ${Columns.Bookings.REJECTION_REASON} TEXT,
                ${Columns.Bookings.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ${Columns.Bookings.UPDATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (${Columns.Bookings.USER_ID}) REFERENCES ${Tables.USERS}(${Columns.Users.ID}) ON DELETE CASCADE,
                FOREIGN KEY (${Columns.Bookings.FACTORY_ID}) REFERENCES ${Tables.FACTORIES}(${Columns.Factories.ID}) ON DELETE CASCADE,
                FOREIGN KEY (${Columns.Bookings.TIME_SLOT_ID}) REFERENCES ${Tables.TIME_SLOTS}(${Columns.TimeSlots.ID}) ON DELETE CASCADE,
                FOREIGN KEY (${Columns.Bookings.QUALITY_REPORT_ID}) REFERENCES ${Tables.QUALITY_REPORTS}(${Columns.QualityReports.ID}) ON DELETE SET NULL,
                FOREIGN KEY (${Columns.Bookings.REVIEWED_BY}) REFERENCES ${Tables.USERS}(${Columns.Users.ID}) ON DELETE SET NULL
            )
        """
        
        const val CREATE_MARKET_DATA_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.MARKET_DATA} (
                ${Columns.MarketData.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.MarketData.MANGO_TYPE} TEXT NOT NULL,
                ${Columns.MarketData.MANGO_VARIETY} TEXT,
                ${Columns.MarketData.PRICE_PER_KG} REAL NOT NULL,
                ${Columns.MarketData.MARKET_LOCATION} TEXT,
                ${Columns.MarketData.PRICE_DATE} TEXT NOT NULL,
                ${Columns.MarketData.SOURCE} TEXT NOT NULL DEFAULT 'wholesale',
                ${Columns.MarketData.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """
        
        const val CREATE_ACTIVITIES_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.ACTIVITIES} (
                ${Columns.Activities.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.Activities.USER_ID} INTEGER NOT NULL,
                ${Columns.Activities.ACTIVITY_TYPE} TEXT NOT NULL,
                ${Columns.Activities.ACTIVITY_MESSAGE} TEXT NOT NULL,
                ${Columns.Activities.RELATED_BOOKING_ID} INTEGER,
                ${Columns.Activities.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (${Columns.Activities.USER_ID}) REFERENCES ${Tables.USERS}(${Columns.Users.ID}) ON DELETE CASCADE,
                FOREIGN KEY (${Columns.Activities.RELATED_BOOKING_ID}) REFERENCES ${Tables.BOOKINGS}(${Columns.Bookings.ID}) ON DELETE SET NULL
            )
        """
        
        const val CREATE_USER_SESSIONS_TABLE = """
            CREATE TABLE IF NOT EXISTS ${Tables.USER_SESSIONS} (
                ${Columns.UserSessions.ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${Columns.UserSessions.USER_ID} INTEGER NOT NULL,
                ${Columns.UserSessions.TOKEN} TEXT UNIQUE NOT NULL,
                ${Columns.UserSessions.DEVICE_INFO} TEXT,
                ${Columns.UserSessions.EXPIRES_AT} TEXT NOT NULL,
                ${Columns.UserSessions.CREATED_AT} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                ${Columns.UserSessions.LAST_ACTIVITY} TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (${Columns.UserSessions.USER_ID}) REFERENCES ${Tables.USERS}(${Columns.Users.ID}) ON DELETE CASCADE
            )
        """
    }
    
    // Indexes for performance
    object Indexes {
        const val CREATE_USERS_EMAIL_INDEX = "CREATE INDEX IF NOT EXISTS idx_users_email ON ${Tables.USERS}(${Columns.Users.EMAIL})"
        const val CREATE_USERS_ROLE_INDEX = "CREATE INDEX IF NOT EXISTS idx_users_role ON ${Tables.USERS}(${Columns.Users.ROLE})"
        const val CREATE_FACTORIES_LOCATION_INDEX = "CREATE INDEX IF NOT EXISTS idx_factories_location ON ${Tables.FACTORIES}(${Columns.Factories.LOCATION})"
        const val CREATE_TIME_SLOTS_FACTORY_DATE_INDEX = "CREATE INDEX IF NOT EXISTS idx_time_slots_factory_date ON ${Tables.TIME_SLOTS}(${Columns.TimeSlots.FACTORY_ID}, ${Columns.TimeSlots.SLOT_DATE})"
        const val CREATE_BOOKINGS_USER_INDEX = "CREATE INDEX IF NOT EXISTS idx_bookings_user ON ${Tables.BOOKINGS}(${Columns.Bookings.USER_ID})"
        const val CREATE_BOOKINGS_STATUS_INDEX = "CREATE INDEX IF NOT EXISTS idx_bookings_status ON ${Tables.BOOKINGS}(${Columns.Bookings.STATUS})"
        const val CREATE_ACTIVITIES_USER_INDEX = "CREATE INDEX IF NOT EXISTS idx_activities_user ON ${Tables.ACTIVITIES}(${Columns.Activities.USER_ID})"
        const val CREATE_USER_SESSIONS_TOKEN_INDEX = "CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON ${Tables.USER_SESSIONS}(${Columns.UserSessions.TOKEN})"
    }
    
    // All table creation statements
    val ALL_CREATE_STATEMENTS = listOf(
        CreateTables.CREATE_USERS_TABLE,
        CreateTables.CREATE_FACTORIES_TABLE,
        CreateTables.CREATE_MANGO_VARIETIES_TABLE,
        CreateTables.CREATE_TIME_SLOTS_TABLE,
        CreateTables.CREATE_QUALITY_REPORTS_TABLE,
        CreateTables.CREATE_BOOKINGS_TABLE,
        CreateTables.CREATE_MARKET_DATA_TABLE,
        CreateTables.CREATE_ACTIVITIES_TABLE,
        CreateTables.CREATE_USER_SESSIONS_TABLE
    )
    
    // All index creation statements
    val ALL_INDEX_STATEMENTS = listOf(
        Indexes.CREATE_USERS_EMAIL_INDEX,
        Indexes.CREATE_USERS_ROLE_INDEX,
        Indexes.CREATE_FACTORIES_LOCATION_INDEX,
        Indexes.CREATE_TIME_SLOTS_FACTORY_DATE_INDEX,
        Indexes.CREATE_BOOKINGS_USER_INDEX,
        Indexes.CREATE_BOOKINGS_STATUS_INDEX,
        Indexes.CREATE_ACTIVITIES_USER_INDEX,
        Indexes.CREATE_USER_SESSIONS_TOKEN_INDEX
    )
}
