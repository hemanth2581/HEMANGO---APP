package com.example.hemangoo.ui.booking

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import kotlinx.coroutines.launch

class BookingDetailsActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var farmerNameText: TextView
    private lateinit var factoryNameText: TextView
    private lateinit var mangoVarietyText: TextView
    private lateinit var quantityText: TextView
    private lateinit var bookingDateText: TextView
    private lateinit var slotTimeText: TextView
    private lateinit var statusText: TextView
    private lateinit var qualityDetailsText: TextView
    private lateinit var backButton: Button
    private lateinit var progressBar: ProgressBar
    
    private var bookingId: Int = 0
    private var currentUser: User? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bookingdetails)
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        bookingId = intent.getIntExtra("booking_id", 0)
        if (bookingId == 0) {
            finish()
            return
        }
        
        initializeViews()
        setupClickListeners()
        loadBookingDetails()
    }
    
    private fun initializeViews() {
        try {
            farmerNameText = findViewById(R.id.tvFruitName)
            factoryNameText = findViewById(R.id.tvFactoryName)
            quantityText = findViewById(R.id.tvFruitWeight)
            bookingDateText = findViewById(R.id.tvDate)
            slotTimeText = findViewById(R.id.tvTime)
            statusText = findViewById(R.id.chipStatus)
            qualityDetailsText = findViewById(R.id.tvBookingDate)
            backButton = findViewById(R.id.btnBack)
            progressBar = findViewById(R.id.progressBar)
        } catch (e: Exception) {
            // Handle missing views gracefully
            showError("Layout initialization error: ${e.message}")
        }
        
        progressBar.visibility = View.GONE
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }
    }
    
    private fun loadBookingDetails() {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                val allBookings = localStorageManager.getAllBookings()
                val booking = allBookings.find { it.id == bookingId }
                
                runOnUiThread {
                    if (booking != null) {
                        populateBookingDetails(booking)
                    } else {
                        showError("Booking not found")
                        finish()
                    }
                    showProgress(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    showError("Error loading booking details: ${e.message}")
                }
            }
        }
    }
    
    private fun populateBookingDetails(booking: Booking) {
        try {
            farmerNameText?.text = "Farmer: ${booking.farmerName}"
            factoryNameText?.text = booking.factoryName
            quantityText?.text = "${booking.quantity} ${booking.unit} of ${booking.mangoVariety}"
            bookingDateText?.text = booking.bookingDate
            slotTimeText?.text = booking.slotTime
            statusText?.text = "Status: ${booking.status.name}"
            
            val qualityDetails = buildString {
                appendLine("Quality Report:")
                appendLine("Ripeness: ${booking.qualityReport.ripenessLevel}")
                appendLine("Colour: ${booking.qualityReport.colour}")
                appendLine("Size: ${booking.qualityReport.size}")
                appendLine("Bruising: ${booking.qualityReport.bruisingLevel}")
                appendLine("Pest Presence: ${if (booking.qualityReport.pestPresence) "Yes" else "No"}")
                appendLine("Harvest Date: ${booking.qualityReport.harvestDate}")
                booking.qualityReport.notes?.let { notes ->
                    appendLine("Notes: $notes")
                }
            }
            qualityDetailsText?.text = qualityDetails
        } catch (e: Exception) {
            showError("Error populating booking details: ${e.message}")
        }
    }
    
    private fun showProgress(show: Boolean) {
        progressBar?.visibility = if (show) View.VISIBLE else View.GONE
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
