package com.example.hemangoo.data.api

import android.content.Context
import android.util.Log
import com.example.hemangoo.data.models.*
import com.example.hemangoo.LocalStorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ApiClient(private val context: Context) {
    
    companion object {
        private const val TAG = "ApiClient"
    }
    
    private val localStorageManager = LocalStorageManager(context)
    
    suspend fun getAvailableSlots(factoryId: Int, date: String): Result<List<TimeSlot>> {
        return withContext(Dispatchers.IO) {
            try {
                val factory = localStorageManager.getFactoryById(factoryId)
                if (factory != null) {
                    val slots = factory.availableSlots.filter { it.date == date }
                    Result.success(slots)
                } else {
                    Result.failure(Exception("Factory not found"))
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching available slots", e)
                Result.failure(e)
            }
        }
    }
    
    suspend fun bookSlot(
        userId: Int,
        factoryId: Int,
        slotId: Int,
        mangoType: String,
        mangoVariety: String,
        quantity: Double,
        unit: String,
        qualityReportId: Int? = null
    ): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val result = localStorageManager.bookSlot(factoryId, slotId)
                result.fold(
                    onSuccess = { 
                        // Create a booking record
                        val booking = Booking(
                            id = System.currentTimeMillis().toInt(),
                            farmerId = userId,
                            farmerName = "Test Farmer",
                            factoryId = factoryId,
                            factoryName = localStorageManager.getFactoryById(factoryId)?.name ?: "Unknown Factory",
                            mangoType = mangoType,
                            mangoVariety = mangoVariety,
                            quantity = quantity,
                            unit = unit,
                            qualityReport = QualityReport(
                                ripenessLevel = "Fully Ripe",
                                colour = "Golden",
                                size = "Medium",
                                bruisingLevel = "None",
                                pestPresence = false,
                                harvestDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
                                notes = "Booked via mobile app"
                            ),
                            bookingDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
                            slotTime = "9:00 AM - 10:00 AM",
                            status = BookingStatus.PENDING,
                            createdAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                            updatedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                        )
                        localStorageManager.saveBooking(booking)
                        Result.success("Slot booked successfully!")
                    },
                    onFailure = { error ->
                        Result.failure(error)
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error booking slot", e)
                Result.failure(e)
            }
        }
    }
    
    suspend fun getPendingBookings(): Result<List<Booking>> {
        return withContext(Dispatchers.IO) {
            try {
                val allBookings = localStorageManager.getAllBookings()
                val pendingBookings = allBookings.filter { it.status == BookingStatus.PENDING }
                Result.success(pendingBookings)
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching pending bookings", e)
                Result.failure(e)
            }
        }
    }
    
    suspend fun getFactories(): Result<List<Factory>> {
        return withContext(Dispatchers.IO) {
            try {
                val factories = localStorageManager.getAllFactories()
                Result.success(factories)
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching factories", e)
                Result.failure(e)
            }
        }
    }
    
    suspend fun getMangoVarieties(): Result<List<MangoVariety>> {
        return withContext(Dispatchers.IO) {
            try {
                val varieties = localStorageManager.getAllMangoVarieties()
                Result.success(varieties)
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching mango varieties", e)
                Result.failure(e)
            }
        }
    }
    
    suspend fun submitBooking(
        userId: Int,
        factoryId: Int,
        timeSlotId: Int,
        mangoType: String,
        mangoVariety: String,
        quantity: Double,
        unit: String,
        bookingDate: String,
        slotTime: String,
        qualityReport: QualityReport
    ): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                // Get actual user data
                val user = localStorageManager.getCurrentUser()
                val factory = localStorageManager.getFactoryById(factoryId)
                
                val booking = Booking(
                    id = System.currentTimeMillis().toInt(),
                    farmerId = userId,
                    farmerName = user?.fullName ?: "Unknown Farmer",
                    factoryId = factoryId,
                    factoryName = factory?.name ?: "Unknown Factory",
                    mangoType = mangoType,
                    mangoVariety = mangoVariety,
                    quantity = quantity,
                    unit = unit,
                    qualityReport = qualityReport,
                    bookingDate = bookingDate,
                    slotTime = slotTime,
                    status = BookingStatus.PENDING,
                    createdAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                    updatedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                )
                
                val result = localStorageManager.saveBooking(booking)
                result.fold(
                    onSuccess = { 
                        Result.success("Booking submitted successfully!") 
                    },
                    onFailure = { error ->
                        Result.failure(error)
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error submitting booking", e)
                Result.failure(e)
            }
        }
    }
    
    suspend fun getFarmerBookings(userId: Int): Result<List<Booking>> {
        return withContext(Dispatchers.IO) {
            try {
                val allBookings = localStorageManager.getAllBookings()
                val farmerBookings = allBookings.filter { it.farmerId == userId }
                Result.success(farmerBookings)
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching farmer bookings", e)
                Result.failure(e)
            }
        }
    }
    
    suspend fun updateBookingStatus(bookingId: Int, action: String, adminNotes: String = "", rejectionReason: String = ""): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                val allBookings = localStorageManager.getAllBookings()
                val bookingIndex = allBookings.indexOfFirst { it.id == bookingId }
                
                if (bookingIndex != -1) {
                    val booking = allBookings[bookingIndex]
                    val newStatus = when (action) {
                        "approve" -> BookingStatus.CONFIRMED
                        "reject" -> BookingStatus.REJECTED
                        else -> booking.status
                    }
                    
                    val updatedBooking = booking.copy(
                        status = newStatus,
                        updatedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                    )
                    
                    localStorageManager.updateBooking(updatedBooking)
                    Result.success("Booking $action successfully!")
                } else {
                    Result.failure(Exception("Booking not found"))
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating booking status", e)
                Result.failure(e)
            }
        }
    }
}
