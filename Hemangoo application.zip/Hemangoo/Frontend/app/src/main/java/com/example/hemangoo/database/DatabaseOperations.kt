package com.example.hemangoo.database

import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.example.hemangoo.data.models.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * DATABASE OPERATIONS
 * 
 * This file contains all the actual SQL operations for the offline database.
 * It's separated for better organization and maintainability.
 */
class DatabaseOperations {
    
    companion object {
        private const val TAG = "DatabaseOperations"
    }
    
    // ==================== QUERY METHODS ====================
    
    fun queryUsers(db: SQLiteDatabase): List<User> {
        val cursor = db.query(
            LocalDatabaseSchema.Tables.USERS,
            null, null, null, null, null, null
        )
        
        val users = mutableListOf<User>()
        cursor.use {
            while (it.moveToNext()) {
                users.add(User(
                    id = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Users.ID)),
                    fullName = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Users.FULL_NAME)),
                    email = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Users.EMAIL)),
                    phone = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Users.PHONE)),
                    role = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Users.ROLE))
                ))
            }
        }
        return users
    }
    
    fun queryFactories(db: SQLiteDatabase): List<Factory> {
        val cursor = db.query(
            LocalDatabaseSchema.Tables.FACTORIES,
            null, null, null, null, null, null
        )
        
        val factories = mutableListOf<Factory>()
        cursor.use {
            while (it.moveToNext()) {
                factories.add(Factory(
                    id = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.ID)),
                    name = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.NAME)),
                    location = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.LOCATION)),
                    address = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.ADDRESS)),
                    phone = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.PHONE)),
                    email = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.EMAIL)),
                    capacityPerDay = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.CAPACITY_PER_DAY)),
                    isActive = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Factories.IS_ACTIVE)) == 1
                ))
            }
        }
        return factories
    }
    
    fun queryMangoVarieties(db: SQLiteDatabase): List<MangoVariety> {
        val cursor = db.query(
            LocalDatabaseSchema.Tables.MANGO_VARIETIES,
            null, null, null, null, null, null
        )
        
        val varieties = mutableListOf<MangoVariety>()
        cursor.use {
            while (it.moveToNext()) {
                varieties.add(MangoVariety(
                    id = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.ID)),
                    name = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.NAME)),
                    type = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.TYPE)),
                    seasonStart = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.SEASON_START)),
                    seasonEnd = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.SEASON_END)),
                    description = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.DESCRIPTION)),
                    basePricePerKg = it.getDouble(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.BASE_PRICE_PER_KG)),
                    isActive = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.IS_ACTIVE)) == 1,
                    imageUrl = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MangoVarieties.IMAGE_URL))
                ))
            }
        }
        return varieties
    }
    
    fun queryTimeSlots(db: SQLiteDatabase): List<TimeSlot> {
        val cursor = db.query(
            LocalDatabaseSchema.Tables.TIME_SLOTS,
            null, null, null, null, null, null
        )
        
        val slots = mutableListOf<TimeSlot>()
        cursor.use {
            while (it.moveToNext()) {
                slots.add(TimeSlot(
                    id = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.ID)),
                    date = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.SLOT_DATE)),
                    time = "${it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.START_TIME))} - ${it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.END_TIME))}",
                    availableSpots = (it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.MAX_CAPACITY_KG)) - it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.CURRENT_BOOKINGS_KG))) / 100,
                    maxCapacity = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.MAX_CAPACITY_KG)) / 100,
                    factoryId = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.FACTORY_ID)),
                    availableCapacityKg = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.MAX_CAPACITY_KG)) - it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.CURRENT_BOOKINGS_KG)).toDouble(),
                    maxCapacityKg = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.MAX_CAPACITY_KG)).toDouble(),
                    pricePerKg = it.getDouble(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.TimeSlots.PRICE_PER_KG))
                ))
            }
        }
        return slots
    }
    
    fun queryBookings(db: SQLiteDatabase): List<Booking> {
        val cursor = db.rawQuery("""
            SELECT b.*, u.full_name as farmer_name, f.name as factory_name
            FROM ${LocalDatabaseSchema.Tables.BOOKINGS} b
            JOIN ${LocalDatabaseSchema.Tables.USERS} u ON b.${LocalDatabaseSchema.Columns.Bookings.USER_ID} = u.${LocalDatabaseSchema.Columns.Users.ID}
            JOIN ${LocalDatabaseSchema.Tables.FACTORIES} f ON b.${LocalDatabaseSchema.Columns.Bookings.FACTORY_ID} = f.${LocalDatabaseSchema.Columns.Factories.ID}
        """, null)
        
        val bookings = mutableListOf<Booking>()
        cursor.use {
            while (it.moveToNext()) {
                bookings.add(Booking(
                    id = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.ID)),
                    farmerId = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.USER_ID)),
                    farmerName = it.getString(it.getColumnIndexOrThrow("farmer_name")),
                    factoryId = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.FACTORY_ID)),
                    factoryName = it.getString(it.getColumnIndexOrThrow("factory_name")),
                    mangoType = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.MANGO_TYPE)),
                    mangoVariety = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.MANGO_VARIETY)),
                    quantity = it.getDouble(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.QUANTITY)),
                    unit = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.UNIT)),
                    qualityReport = QualityReport(
                        ripenessLevel = "Not Specified",
                        colour = "Not Specified", 
                        size = "Not Specified",
                        bruisingLevel = "Not Specified",
                        pestPresence = false,
                        harvestDate = "",
                        notes = null
                    ),
                    bookingDate = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.BOOKING_DATE)),
                    slotTime = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.SLOT_TIME)),
                    status = BookingStatus.valueOf(it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.STATUS)).uppercase()),
                    createdAt = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.CREATED_AT)),
                    updatedAt = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Bookings.UPDATED_AT))
                ))
            }
        }
        return bookings
    }
    
    fun queryMarketData(db: SQLiteDatabase): List<MarketData> {
        val cursor = db.query(
            LocalDatabaseSchema.Tables.MARKET_DATA,
            null, null, null, null, null, null
        )
        
        val marketData = mutableListOf<MarketData>()
        cursor.use {
            while (it.moveToNext()) {
                marketData.add(MarketData(
                    date = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MarketData.PRICE_DATE)),
                    pricePerKg = it.getDouble(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.MarketData.PRICE_PER_KG)),
                    averageBuyers = 25,
                    activeBuyers = 18,
                    marketTrend = "Stable",
                    totalVolume = 5000.0
                ))
            }
        }
        return marketData
    }
    
    fun queryActivities(db: SQLiteDatabase): List<ActivityItem> {
        val cursor = db.query(
            LocalDatabaseSchema.Tables.ACTIVITIES,
            null, null, null, null, null, "${LocalDatabaseSchema.Columns.Activities.CREATED_AT} DESC"
        )
        
        val activities = mutableListOf<ActivityItem>()
        cursor.use {
            while (it.moveToNext()) {
                activities.add(ActivityItem(
                    id = it.getInt(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Activities.ID)),
                    message = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Activities.ACTIVITY_MESSAGE)),
                    timestamp = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Activities.CREATED_AT)),
                    type = it.getString(it.getColumnIndexOrThrow(LocalDatabaseSchema.Columns.Activities.ACTIVITY_TYPE))
                ))
            }
        }
        return activities
    }
    
    // ==================== INSERT METHODS ====================
    
    fun insertUser(db: SQLiteDatabase, user: User): Int {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.Users.FULL_NAME, user.fullName)
            put(LocalDatabaseSchema.Columns.Users.EMAIL, user.email)
            put(LocalDatabaseSchema.Columns.Users.PHONE, user.phone)
            put(LocalDatabaseSchema.Columns.Users.PASSWORD_HASH, "hashed_password") // Simplified for offline
            put(LocalDatabaseSchema.Columns.Users.ROLE, user.role)
            put(LocalDatabaseSchema.Columns.Users.IS_ACTIVE, 1)
        }
        return db.insert(LocalDatabaseSchema.Tables.USERS, null, values).toInt()
    }
    
    fun insertFactory(db: SQLiteDatabase, factory: Factory): Int {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.Factories.NAME, factory.name)
            put(LocalDatabaseSchema.Columns.Factories.LOCATION, factory.location)
            put(LocalDatabaseSchema.Columns.Factories.ADDRESS, factory.address)
            put(LocalDatabaseSchema.Columns.Factories.PHONE, factory.phone)
            put(LocalDatabaseSchema.Columns.Factories.EMAIL, factory.email)
            put(LocalDatabaseSchema.Columns.Factories.CAPACITY_PER_DAY, factory.capacityPerDay)
            put(LocalDatabaseSchema.Columns.Factories.IS_ACTIVE, if (factory.isActive) 1 else 0)
        }
        return db.insert(LocalDatabaseSchema.Tables.FACTORIES, null, values).toInt()
    }
    
    fun insertMangoVariety(db: SQLiteDatabase, variety: MangoVariety): Int {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.MangoVarieties.NAME, variety.name)
            put(LocalDatabaseSchema.Columns.MangoVarieties.TYPE, variety.type)
            put(LocalDatabaseSchema.Columns.MangoVarieties.SEASON_START, variety.seasonStart)
            put(LocalDatabaseSchema.Columns.MangoVarieties.SEASON_END, variety.seasonEnd)
            put(LocalDatabaseSchema.Columns.MangoVarieties.DESCRIPTION, variety.description)
            put(LocalDatabaseSchema.Columns.MangoVarieties.BASE_PRICE_PER_KG, variety.basePricePerKg)
            put(LocalDatabaseSchema.Columns.MangoVarieties.IMAGE_URL, variety.imageUrl)
            put(LocalDatabaseSchema.Columns.MangoVarieties.IS_ACTIVE, if (variety.isActive) 1 else 0)
        }
        return db.insert(LocalDatabaseSchema.Tables.MANGO_VARIETIES, null, values).toInt()
    }
    
    fun insertTimeSlot(db: SQLiteDatabase, slot: TimeSlot): Int {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.TimeSlots.FACTORY_ID, slot.factoryId)
            put(LocalDatabaseSchema.Columns.TimeSlots.SLOT_DATE, slot.date)
            put(LocalDatabaseSchema.Columns.TimeSlots.START_TIME, slot.time.split(" - ")[0])
            put(LocalDatabaseSchema.Columns.TimeSlots.END_TIME, slot.time.split(" - ")[1])
            put(LocalDatabaseSchema.Columns.TimeSlots.MAX_CAPACITY_KG, slot.maxCapacityKg?.toInt() ?: 1000)
            put(LocalDatabaseSchema.Columns.TimeSlots.CURRENT_BOOKINGS_KG, 0)
            put(LocalDatabaseSchema.Columns.TimeSlots.PRICE_PER_KG, slot.pricePerKg ?: 0.0)
            put(LocalDatabaseSchema.Columns.TimeSlots.IS_AVAILABLE, 1)
        }
        return db.insert(LocalDatabaseSchema.Tables.TIME_SLOTS, null, values).toInt()
    }
    
    fun insertBooking(db: SQLiteDatabase, booking: Booking): Int {
        // First, insert the quality report
        val qualityReportId = insertQualityReport(db, booking.qualityReport, booking.farmerId, booking.mangoType, booking.mangoVariety, booking.quantity, booking.unit)
        
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.Bookings.USER_ID, booking.farmerId)
            put(LocalDatabaseSchema.Columns.Bookings.FACTORY_ID, booking.factoryId)
            put(LocalDatabaseSchema.Columns.Bookings.TIME_SLOT_ID, 1) // Simplified for now
            put(LocalDatabaseSchema.Columns.Bookings.QUALITY_REPORT_ID, qualityReportId)
            put(LocalDatabaseSchema.Columns.Bookings.MANGO_TYPE, booking.mangoType)
            put(LocalDatabaseSchema.Columns.Bookings.MANGO_VARIETY, booking.mangoVariety)
            put(LocalDatabaseSchema.Columns.Bookings.QUANTITY, booking.quantity)
            put(LocalDatabaseSchema.Columns.Bookings.UNIT, booking.unit)
            put(LocalDatabaseSchema.Columns.Bookings.BOOKING_DATE, booking.bookingDate)
            put(LocalDatabaseSchema.Columns.Bookings.SLOT_TIME, booking.slotTime)
            put(LocalDatabaseSchema.Columns.Bookings.STATUS, booking.status.name.lowercase())
            put(LocalDatabaseSchema.Columns.Bookings.CREATED_AT, booking.createdAt)
            put(LocalDatabaseSchema.Columns.Bookings.UPDATED_AT, booking.updatedAt)
        }
        return db.insert(LocalDatabaseSchema.Tables.BOOKINGS, null, values).toInt()
    }
    
    fun insertQualityReport(db: SQLiteDatabase, qualityReport: QualityReport, userId: Int, mangoType: String, mangoVariety: String, quantity: Double, unit: String): Int {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.QualityReports.USER_ID, userId)
            put(LocalDatabaseSchema.Columns.QualityReports.MANGO_TYPE, mangoType)
            put(LocalDatabaseSchema.Columns.QualityReports.MANGO_VARIETY, mangoVariety)
            put(LocalDatabaseSchema.Columns.QualityReports.ESTIMATED_QUANTITY, quantity)
            put(LocalDatabaseSchema.Columns.QualityReports.UNIT, unit)
            put(LocalDatabaseSchema.Columns.QualityReports.HARVEST_DATE, qualityReport.harvestDate)
            put(LocalDatabaseSchema.Columns.QualityReports.RIPENESS_LEVEL, qualityReport.ripenessLevel)
            put(LocalDatabaseSchema.Columns.QualityReports.COLOUR, qualityReport.colour)
            put(LocalDatabaseSchema.Columns.QualityReports.SIZE, qualityReport.size)
            put(LocalDatabaseSchema.Columns.QualityReports.BRUISING_LEVEL, qualityReport.bruisingLevel)
            put(LocalDatabaseSchema.Columns.QualityReports.PEST_PRESENCE, if (qualityReport.pestPresence) 1 else 0)
            put(LocalDatabaseSchema.Columns.QualityReports.ADDITIONAL_NOTES, qualityReport.notes)
            put(LocalDatabaseSchema.Columns.QualityReports.ADMIN_REVIEW_STATUS, "pending")
            put(LocalDatabaseSchema.Columns.QualityReports.CREATED_AT, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()))
            put(LocalDatabaseSchema.Columns.QualityReports.UPDATED_AT, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()))
        }
        return db.insert(LocalDatabaseSchema.Tables.QUALITY_REPORTS, null, values).toInt()
    }
    
    fun insertMarketData(db: SQLiteDatabase, data: MarketData): Int {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.MarketData.MANGO_TYPE, "Mango")
            put(LocalDatabaseSchema.Columns.MarketData.MANGO_VARIETY, "Alphonso")
            put(LocalDatabaseSchema.Columns.MarketData.PRICE_PER_KG, data.pricePerKg)
            put(LocalDatabaseSchema.Columns.MarketData.PRICE_DATE, data.date)
            put(LocalDatabaseSchema.Columns.MarketData.SOURCE, "wholesale")
        }
        return db.insert(LocalDatabaseSchema.Tables.MARKET_DATA, null, values).toInt()
    }
    
    fun insertActivity(db: SQLiteDatabase, activity: ActivityItem): Int {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.Activities.USER_ID, 1) // Default user
            put(LocalDatabaseSchema.Columns.Activities.ACTIVITY_TYPE, activity.type)
            put(LocalDatabaseSchema.Columns.Activities.ACTIVITY_MESSAGE, activity.message)
        }
        return db.insert(LocalDatabaseSchema.Tables.ACTIVITIES, null, values).toInt()
    }
    
    // ==================== UPDATE METHODS ====================
    
    fun updateUser(db: SQLiteDatabase, user: User) {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.Users.FULL_NAME, user.fullName)
            put(LocalDatabaseSchema.Columns.Users.EMAIL, user.email)
            put(LocalDatabaseSchema.Columns.Users.PHONE, user.phone)
            put(LocalDatabaseSchema.Columns.Users.ROLE, user.role)
        }
        db.update(LocalDatabaseSchema.Tables.USERS, values, "${LocalDatabaseSchema.Columns.Users.ID} = ?", arrayOf(user.id.toString()))
    }
    
    fun updateTimeSlot(db: SQLiteDatabase, slot: TimeSlot) {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.TimeSlots.CURRENT_BOOKINGS_KG, (slot.maxCapacityKg ?: 1000.0) - (slot.availableCapacityKg ?: 0.0))
        }
        db.update(LocalDatabaseSchema.Tables.TIME_SLOTS, values, "${LocalDatabaseSchema.Columns.TimeSlots.ID} = ?", arrayOf(slot.id.toString()))
    }
    
    fun updateBooking(db: SQLiteDatabase, booking: Booking) {
        val values = android.content.ContentValues().apply {
            put(LocalDatabaseSchema.Columns.Bookings.STATUS, booking.status.name.lowercase())
            put(LocalDatabaseSchema.Columns.Bookings.UPDATED_AT, SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
        }
        db.update(LocalDatabaseSchema.Tables.BOOKINGS, values, "${LocalDatabaseSchema.Columns.Bookings.ID} = ?", arrayOf(booking.id.toString()))
    }
    
    // ==================== SAMPLE DATA CREATION ====================
    
    fun createDefaultUsers(): List<User> = listOf(
        User(1, "Admin User", "admin@hemango.com", "+91-9876543210", "admin"),
        User(2, "Farmer User", "farmer@hemango.com", "+91-9876543211", "farmer")
    )
    
    fun createDefaultFactories(): List<Factory> = listOf(
        Factory(1, "Mango Processing Plant A", "Mumbai, Maharashtra", "123 Industrial Area, Mumbai", "+91-9876543210", "plantA@hemango.com", 1000, true),
        Factory(2, "Mango Processing Plant B", "Pune, Maharashtra", "456 Agricultural Zone, Pune", "+91-9876543211", "plantB@hemango.com", 800, true),
        Factory(3, "Mango Processing Plant C", "Nashik, Maharashtra", "789 Farm District, Nashik", "+91-9876543212", "plantC@hemango.com", 1200, true)
    )
    
    fun createDefaultMangoVarieties(): List<MangoVariety> = listOf(
        MangoVariety(1, "Alphonso", "Mango", "March", "June", "Premium quality mango with sweet taste", 150.0, true, "mango_alphonso.png"),
        MangoVariety(2, "Kesar", "Mango", "April", "July", "Saffron colored mango with rich flavor", 140.0, true, "mango_kesar.png"),
        MangoVariety(3, "Banganapalli", "Mango", "May", "August", "Large sized mango with mild sweetness", 130.0, true, "mango_banganapalli.png")
    )
    
    fun createDefaultTimeSlots(): List<TimeSlot> {
        val slots = mutableListOf<TimeSlot>()
        val calendar = Calendar.getInstance()
        
        // Generate slots for the next 7 days for each factory
        for (factoryId in 1..3) {
            for (i in 0..6) {
                calendar.time = Date()
                calendar.add(Calendar.DAY_OF_MONTH, i)
                val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)
                
                // Morning slots
                slots.add(TimeSlot(
                    id = factoryId * 1000 + i * 10 + 1,
                    date = date,
                    time = "9:00 AM - 10:00 AM",
                    availableSpots = 5,
                    maxCapacity = 5,
                    factoryId = factoryId,
                    availableCapacityKg = 500.0,
                    maxCapacityKg = 500.0,
                    pricePerKg = 150.0
                ))
                slots.add(TimeSlot(
                    id = factoryId * 1000 + i * 10 + 2,
                    date = date,
                    time = "10:00 AM - 11:00 AM",
                    availableSpots = 5,
                    maxCapacity = 5,
                    factoryId = factoryId,
                    availableCapacityKg = 500.0,
                    maxCapacityKg = 500.0,
                    pricePerKg = 150.0
                ))
                slots.add(TimeSlot(
                    id = factoryId * 1000 + i * 10 + 3,
                    date = date,
                    time = "11:00 AM - 12:00 PM",
                    availableSpots = 5,
                    maxCapacity = 5,
                    factoryId = factoryId,
                    availableCapacityKg = 500.0,
                    maxCapacityKg = 500.0,
                    pricePerKg = 150.0
                ))
                
                // Afternoon slots
                slots.add(TimeSlot(
                    id = factoryId * 1000 + i * 10 + 4,
                    date = date,
                    time = "2:00 PM - 3:00 PM",
                    availableSpots = 5,
                    maxCapacity = 5,
                    factoryId = factoryId,
                    availableCapacityKg = 500.0,
                    maxCapacityKg = 500.0,
                    pricePerKg = 150.0
                ))
                slots.add(TimeSlot(
                    id = factoryId * 1000 + i * 10 + 5,
                    date = date,
                    time = "3:00 PM - 4:00 PM",
                    availableSpots = 5,
                    maxCapacity = 5,
                    factoryId = factoryId,
                    availableCapacityKg = 500.0,
                    maxCapacityKg = 500.0,
                    pricePerKg = 150.0
                ))
                slots.add(TimeSlot(
                    id = factoryId * 1000 + i * 10 + 6,
                    date = date,
                    time = "4:00 PM - 5:00 PM",
                    availableSpots = 5,
                    maxCapacity = 5,
                    factoryId = factoryId,
                    availableCapacityKg = 500.0,
                    maxCapacityKg = 500.0,
                    pricePerKg = 150.0
                ))
            }
        }
        
        return slots
    }
    
    fun createDefaultMarketData(): List<MarketData> = listOf(
        MarketData(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()), 150.0, 25, 18, "Stable", 5000.0)
    )
    
    fun createWelcomeActivity(): ActivityItem = ActivityItem(
        1, 
        "Welcome to Hemango! Your offline mango booking platform.", 
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()), 
        "welcome"
    )
}
