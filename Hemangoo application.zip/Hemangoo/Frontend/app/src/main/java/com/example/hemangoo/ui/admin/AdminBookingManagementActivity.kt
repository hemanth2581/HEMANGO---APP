package com.example.hemangoo.ui.admin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import com.example.hemangoo.ui.dashboard.AdminDashboardActivity
import kotlinx.coroutines.launch
import android.util.Log

class AdminBookingManagementActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var toolbar: androidx.appcompat.widget.Toolbar
    private lateinit var titleText: TextView
    private lateinit var searchView: EditText
    private lateinit var btnAllRequests: Button
    private lateinit var btnPending: Button
    private lateinit var btnApproved: Button
    private lateinit var btnRejected: Button
    private lateinit var requestsListView: ListView
    private lateinit var progressBar: ProgressBar
    
    private var currentUser: User? = null
    private var allBookings: List<Booking> = emptyList()
    private var filteredBookings: List<Booking> = emptyList()
    private var currentFilter: String = "all" // "all", "pending", "approved", "rejected"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pendingbooking)
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        initializeViews()
        setupClickListeners()
        loadAllBookings()
    }
    
    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        titleText = findViewById(R.id.txtTitle)
        searchView = findViewById(R.id.searchView)
        btnAllRequests = findViewById(R.id.btnAllRequests)
        btnPending = findViewById(R.id.btnPending)
        requestsListView = findViewById(R.id.scrollBookings)
        
        // Set up toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Booking Management"
        
        // Update title text
        titleText.text = "Booking Management"
        
        toolbar.setNavigationOnClickListener {
            finish()
        }
        
        Log.d("AdminBookingManagement", "Views initialized successfully")
        
        // Initialize filter buttons
        updateFilterButtons()
    }
    
    private fun setupClickListeners() {
        // Filter buttons
        btnAllRequests.setOnClickListener {
            currentFilter = "all"
            updateFilterButtons()
            applyFilter()
        }
        
        btnPending.setOnClickListener {
            currentFilter = "pending"
            updateFilterButtons()
            applyFilter()
        }
        
        // Search functionality
        searchView.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                applySearchFilter(s.toString())
            }
        })
        
        // List item click listener
        requestsListView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val selectedBooking = filteredBookings[position]
            showRequestDetails(selectedBooking)
        }
    }
    
    private fun updateFilterButtons() {
        when (currentFilter) {
            "all" -> {
                btnAllRequests.setBackgroundResource(R.drawable.button_selected)
                btnAllRequests.setTextColor(getColor(android.R.color.white))
                btnPending.setBackgroundResource(R.drawable.button_unselected)
                btnPending.setTextColor(getColor(R.color.blue_button))
            }
            "pending" -> {
                btnPending.setBackgroundResource(R.drawable.button_selected)
                btnPending.setTextColor(getColor(android.R.color.white))
                btnAllRequests.setBackgroundResource(R.drawable.button_unselected)
                btnAllRequests.setTextColor(getColor(R.color.blue_button))
            }
        }
    }
    
    private fun loadAllBookings() {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                // Load all bookings from local storage
                allBookings = localStorageManager.getAllBookings()
                
                Log.d("AdminBookingManagement", "Loaded ${allBookings.size} total bookings")
                
                runOnUiThread {
                    applyFilter()
                    showProgress(false)
                }
            } catch (e: Exception) {
                Log.e("AdminBookingManagement", "Error loading bookings", e)
                runOnUiThread {
                    showProgress(false)
                    showError("Error loading bookings: ${e.message}")
                }
            }
        }
    }
    
    private fun applyFilter() {
        filteredBookings = when (currentFilter) {
            "all" -> allBookings
            "pending" -> allBookings.filter { it.status == BookingStatus.PENDING }
            "approved" -> allBookings.filter { it.status == BookingStatus.CONFIRMED }
            "rejected" -> allBookings.filter { it.status == BookingStatus.REJECTED }
            else -> allBookings
        }
        
        applySearchFilter(searchView.text.toString())
    }
    
    private fun applySearchFilter(query: String) {
        val searchQuery = query.lowercase().trim()
        
        val filtered = if (searchQuery.isEmpty()) {
            filteredBookings
        } else {
            filteredBookings.filter { booking ->
                booking.farmerName.lowercase().contains(searchQuery) ||
                booking.factoryName.lowercase().contains(searchQuery) ||
                booking.mangoVariety.lowercase().contains(searchQuery) ||
                booking.mangoType.lowercase().contains(searchQuery) ||
                booking.id.toString().contains(searchQuery)
            }
        }
        
        updateBookingsList(filtered)
    }
    
    private fun updateBookingsList(bookings: List<Booking>) {
        if (bookings.isEmpty()) {
            showEmptyState()
        } else {
            val adapter = AdminBookingAdapter(this, bookings) { booking, action ->
                handleBookingAction(booking, action)
            }
            requestsListView.adapter = adapter
            requestsListView.visibility = View.VISIBLE
        }
    }
    
    private fun showEmptyState() {
        val emptyText = when (currentFilter) {
            "all" -> "No bookings found"
            "pending" -> "No pending requests found"
            "approved" -> "No approved bookings found"
            "rejected" -> "No rejected bookings found"
            else -> "No bookings found"
        }
        
        val emptyAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listOf(emptyText))
        requestsListView.adapter = emptyAdapter
        requestsListView.visibility = View.VISIBLE
    }
    
    private fun showRequestDetails(booking: Booking) {
        val intent = Intent(this, RequestDetailsActivity::class.java)
        intent.putExtra("booking_id", booking.id)
        startActivity(intent)
    }
    
    private fun handleBookingAction(booking: Booking, action: String) {
        when (action) {
            "approve" -> approveBooking(booking)
            "reject" -> rejectBooking(booking)
        }
    }
    
    private fun approveBooking(booking: Booking) {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                // Update booking status directly in local storage
                val updatedBooking = booking.copy(
                    status = BookingStatus.CONFIRMED,
                    updatedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                )
                
                localStorageManager.updateBooking(updatedBooking)
                
                // Add activity log
                val activity = ActivityItem(
                    id = System.currentTimeMillis().toInt(),
                    message = "Booking #${booking.id} approved for ${booking.farmerName}",
                    timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                    type = "booking_approved"
                )
                localStorageManager.addActivity(activity)
                
                Log.d("AdminBookingManagement", "Booking ${booking.id} approved successfully")
                
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@AdminBookingManagementActivity, "Booking approved successfully!", Toast.LENGTH_SHORT).show()
                    // Clear cache to ensure fresh data
                    lifecycleScope.launch {
                        localStorageManager.clearCache()
                        runOnUiThread {
                            loadAllBookings() // Refresh the list
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("AdminBookingManagement", "Error approving booking", e)
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@AdminBookingManagementActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun rejectBooking(booking: Booking) {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                // Update booking status directly in local storage
                val updatedBooking = booking.copy(
                    status = BookingStatus.REJECTED,
                    updatedAt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
                )
                
                localStorageManager.updateBooking(updatedBooking)
                
                // Add activity log
                val activity = ActivityItem(
                    id = System.currentTimeMillis().toInt(),
                    message = "Booking #${booking.id} rejected for ${booking.farmerName}",
                    timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                    type = "booking_rejected"
                )
                localStorageManager.addActivity(activity)
                
                Log.d("AdminBookingManagement", "Booking ${booking.id} rejected successfully")
                
                        runOnUiThread {
                            showProgress(false)
                            Toast.makeText(this@AdminBookingManagementActivity, "Booking rejected!", Toast.LENGTH_SHORT).show()
                            // Clear cache to ensure fresh data
                            lifecycleScope.launch {
                                localStorageManager.clearCache()
                                runOnUiThread {
                                    loadAllBookings() // Refresh the list
                                }
                            }
                        }
            } catch (e: Exception) {
                Log.e("AdminBookingManagement", "Error rejecting booking", e)
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@AdminBookingManagementActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun showProgress(show: Boolean) {
        // Show/hide progress indicator
        if (show) {
            Toast.makeText(this, "Processing...", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    override fun onResume() {
        super.onResume()
        // Refresh bookings when returning to this activity
        loadAllBookings()
    }
}

class AdminBookingAdapter(
    private val context: android.content.Context,
    private val bookings: List<Booking>,
    private val onActionClick: (Booking, String) -> Unit
) : BaseAdapter() {
    
    override fun getCount(): Int = bookings.size
    
    override fun getItem(position: Int): Booking = bookings[position]
    
    override fun getItemId(position: Int): Long = bookings[position].id.toLong()
    
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: android.view.LayoutInflater.from(context)
            .inflate(R.layout.item_pending_request, parent, false)
        
        val booking = bookings[position]
        
        // Find views
        val farmerNameText = view.findViewById<TextView>(R.id.farmerNameText)
        val factoryNameText = view.findViewById<TextView>(R.id.factoryNameText)
        val mangoVarietyText = view.findViewById<TextView>(R.id.mangoVarietyText)
        val quantityText = view.findViewById<TextView>(R.id.quantityText)
        val bookingDateText = view.findViewById<TextView>(R.id.bookingDateText)
        val approveButton = view.findViewById<Button>(R.id.approveButton)
        val rejectButton = view.findViewById<Button>(R.id.rejectButton)
        
        // Set data
        farmerNameText.text = "Farmer: ${booking.farmerName}"
        factoryNameText.text = "Factory: ${booking.factoryName}"
        mangoVarietyText.text = "Mango: ${booking.mangoVariety}"
        quantityText.text = "Quantity: ${booking.quantity} ${booking.unit}"
        bookingDateText.text = "Date: ${booking.bookingDate} at ${booking.slotTime}"
        
        // Set button visibility and text based on status
        when (booking.status) {
            BookingStatus.PENDING -> {
                approveButton.visibility = View.VISIBLE
                rejectButton.visibility = View.VISIBLE
                approveButton.text = "Approve"
                rejectButton.text = "Reject"
                approveButton.isEnabled = true
                rejectButton.isEnabled = true
                approveButton.setBackgroundColor(context.getColor(android.R.color.holo_green_dark))
                rejectButton.setBackgroundColor(context.getColor(android.R.color.holo_red_dark))
            }
            BookingStatus.CONFIRMED -> {
                approveButton.visibility = View.VISIBLE
                rejectButton.visibility = View.GONE
                approveButton.text = "APPROVED"
                approveButton.isEnabled = false
                approveButton.setBackgroundColor(context.getColor(android.R.color.darker_gray))
            }
            BookingStatus.REJECTED -> {
                approveButton.visibility = View.GONE
                rejectButton.visibility = View.VISIBLE
                rejectButton.text = "REJECTED"
                rejectButton.isEnabled = false
                rejectButton.setBackgroundColor(context.getColor(android.R.color.darker_gray))
            }
        }
        
        // Set click listeners
        approveButton.setOnClickListener {
            if (booking.status == BookingStatus.PENDING) {
                onActionClick(booking, "approve")
            }
        }
        
        rejectButton.setOnClickListener {
            if (booking.status == BookingStatus.PENDING) {
                onActionClick(booking, "reject")
            }
        }
        
        return view
    }
}
