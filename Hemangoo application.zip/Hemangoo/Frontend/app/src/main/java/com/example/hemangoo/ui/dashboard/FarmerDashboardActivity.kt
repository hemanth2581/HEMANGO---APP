package com.example.hemangoo.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.ui.auth.LoginActivity
import com.example.hemangoo.data.models.*
import com.example.hemangoo.data.api.ApiClient
import com.example.hemangoo.ui.booking.SelectMangoActivity
import com.example.hemangoo.ui.booking.MyBookingsActivity
import kotlinx.coroutines.launch
import android.util.Log

class FarmerDashboardActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var apiClient: ApiClient
    private lateinit var welcomeText: TextView
    private lateinit var logoutButton: Button
    private lateinit var startBookingBtn: Button
    private lateinit var viewAllBookingsBtn: Button
    private lateinit var progressBar: ProgressBar
    
    // Stats TextViews
    private lateinit var totalBookingsText: TextView
    private lateinit var pendingBookingsText: TextView
    private lateinit var approvedBookingsText: TextView
    
    // Market data TextViews
    private lateinit var marketPriceText: TextView
    private lateinit var marketTrendText: TextView
    private lateinit var activeBuyersText: TextView
    
    // Recent activity
    private lateinit var recentActivityList: ListView
    
    private var currentUser: User? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_dashboard)
        
        localStorageManager = LocalStorageManager(this)
        apiClient = ApiClient(this)
        
        // Check if user is logged in
        currentUser = localStorageManager.getCurrentUser()
        if (currentUser == null) {
            redirectToLogin()
            return
        }
        
        initializeViews()
        setupClickListeners()
        loadDashboardData()
    }
    
    private fun initializeViews() {
        try {
            welcomeText = findViewById(R.id.welcomeText)
            logoutButton = findViewById(R.id.logoutBtn)
            startBookingBtn = findViewById(R.id.startBookingBtn)
            viewAllBookingsBtn = findViewById(R.id.viewAllBookingsBtn)
            progressBar = findViewById(R.id.progressBar)
            
            // Stats TextViews
            totalBookingsText = findViewById(R.id.totalBookingsText)
            pendingBookingsText = findViewById(R.id.pendingBookingsText)
            approvedBookingsText = findViewById(R.id.approvedBookingsText)
            
            // Market data TextViews
            marketPriceText = findViewById(R.id.marketPriceText)
            marketTrendText = findViewById(R.id.marketTrendText)
            activeBuyersText = findViewById(R.id.activeBuyersText)
            
            // Recent activity
            recentActivityList = findViewById(R.id.recentActivityList)
            
            // Hide progress bar initially
            progressBar?.visibility = View.GONE
            
            // Dashboard views initialized successfully
        } catch (e: Exception) {
            showError("Error initializing views: ${e.message}")
            e.printStackTrace()
        }
    }
    
    private fun setupClickListeners() {
        logoutButton.setOnClickListener {
            try {
                localStorageManager.logout()
                redirectToLogin()
            } catch (e: Exception) {
                showError("Logout error: ${e.message}")
            }
        }
        
        startBookingBtn.setOnClickListener {
            startBookingFlow()
        }
        
        viewAllBookingsBtn.setOnClickListener {
            viewAllBookings()
        }
        
        // Add test functionality to the start booking button (long press)
        startBookingBtn.setOnLongClickListener {
            testBookingFlow()
            true
        }
    }
    
    private fun loadDashboardData() {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                currentUser?.let { user ->
                    // Load bookings directly from local storage
                    val bookings = localStorageManager.getBookingsByFarmer(user.id)
                    
                    // Get market data
                    val marketDataList = localStorageManager.getMarketData()
                    val latestMarketData = marketDataList.maxByOrNull { it.date }
                    
                    // Get recent activities
                    val activities = localStorageManager.getAllActivities()
                    val recentActivities = activities.take(5)
                    
                    val stats = DashboardStats(
                        totalBookings = bookings.size,
                        pendingBookings = bookings.count { it.status == BookingStatus.PENDING },
                        confirmedBookings = bookings.count { it.status == BookingStatus.CONFIRMED },
                        rejectedBookings = bookings.count { it.status == BookingStatus.REJECTED },
                        todaysMarketPrice = latestMarketData?.pricePerKg ?: 120.0,
                        recentActivity = recentActivities
                    )
                    
                    runOnUiThread {
                        updateDashboardUI(stats, latestMarketData)
                        showProgress(false)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    Toast.makeText(this@FarmerDashboardActivity, "Error loading dashboard data: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun updateDashboardUI(stats: DashboardStats, marketData: MarketData?) {
        try {
            currentUser?.let { user ->
                welcomeText?.text = "Welcome, ${user.fullName}!"
            }
            
            // Update stats with null safety
            totalBookingsText?.text = stats.totalBookings.toString()
            pendingBookingsText?.text = stats.pendingBookings.toString()
            approvedBookingsText?.text = stats.confirmedBookings.toString()
            
            // Update market data with null safety
            marketData?.let { data ->
                marketPriceText?.text = "₹${data.pricePerKg}/kg"
                marketTrendText?.text = data.marketTrend
                activeBuyersText?.text = data.activeBuyers.toString()
            } ?: run {
                // Set default values when market data is null
                marketPriceText?.text = "₹0/kg"
                marketTrendText?.text = "N/A"
                activeBuyersText?.text = "0"
            }
            
            // Update recent activity
            updateRecentActivity(stats.recentActivity)
            
        } catch (e: Exception) {
            showError("Error updating dashboard UI: ${e.message}")
        }
    }
    
    private fun updateRecentActivity(activities: List<ActivityItem>) {
        try {
            if (activities.isNotEmpty()) {
                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, 
                    activities.map { it.message })
                recentActivityList?.adapter = adapter
            } else {
                val emptyAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, 
                    listOf("No recent activity"))
                recentActivityList?.adapter = emptyAdapter
            }
        } catch (e: Exception) {
            showError("Error updating recent activity: ${e.message}")
        }
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    private fun startBookingFlow() {
        try {
            val intent = Intent(this, SelectMangoActivity::class.java)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Error starting booking: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("FarmerDashboard", "Error starting booking", e)
        }
    }
    
    private fun viewAllBookings() {
        val intent = Intent(this, MyBookingsActivity::class.java)
        startActivity(intent)
    }
    
    private fun testBookingFlow() {
        try {
            showProgress(true)
            Toast.makeText(this, "Testing booking system...", Toast.LENGTH_SHORT).show()
            
            lifecycleScope.launch {
                try {
                    // Test basic functionality
                    val currentUser = localStorageManager.getCurrentUser()
                    val allBookings = localStorageManager.getAllBookings()
                    val pendingBookings = localStorageManager.getPendingBookings()
                    val factories = localStorageManager.getAllFactories()
                    val varieties = localStorageManager.getAllMangoVarieties()
                    
                    Log.d("FarmerDashboard", "=== BOOKING SYSTEM TEST ===")
                    Log.d("FarmerDashboard", "Current User: ${currentUser?.fullName}")
                    Log.d("FarmerDashboard", "Total Bookings: ${allBookings.size}")
                    Log.d("FarmerDashboard", "Pending Bookings: ${pendingBookings.size}")
                    Log.d("FarmerDashboard", "Available Factories: ${factories.size}")
                    Log.d("FarmerDashboard", "Mango Varieties: ${varieties.size}")
                    
                    // Test creating a sample booking
                    if (currentUser != null) {
                        val testBooking = Booking(
                            id = 0,
                            farmerId = currentUser.id,
                            farmerName = currentUser.fullName,
                            factoryId = 1,
                            factoryName = "Test Factory",
                            mangoType = "Mango",
                            mangoVariety = "Alphonso",
                            quantity = 50.0,
                            unit = "kg",
                            qualityReport = QualityReport(
                                ripenessLevel = "Fully Ripe",
                                colour = "Golden",
                                size = "Large",
                                bruisingLevel = "None",
                                pestPresence = false,
                                harvestDate = "2024-01-15",
                                notes = "Test booking"
                            ),
                            bookingDate = "2024-01-20",
                            slotTime = "9:00 AM - 10:00 AM",
                            status = BookingStatus.PENDING,
                            createdAt = "2024-01-15 10:00:00",
                            updatedAt = "2024-01-15 10:00:00",
                            images = emptyList()
                        )
                        
                        val result = localStorageManager.saveBooking(testBooking)
                        if (result.isSuccess) {
                            Log.d("FarmerDashboard", "Test booking created successfully!")
                        } else {
                            Log.e("FarmerDashboard", "Failed to create test booking: ${result.exceptionOrNull()?.message}")
                        }
                    }
                    
                    runOnUiThread {
                        showProgress(false)
                        Toast.makeText(this@FarmerDashboardActivity, "Test completed! Check logs for details.", Toast.LENGTH_LONG).show()
                        loadDashboardData() // Refresh dashboard data
                    }
                } catch (e: Exception) {
                    Log.e("FarmerDashboard", "Test failed", e)
                    runOnUiThread {
                        showProgress(false)
                        Toast.makeText(this@FarmerDashboardActivity, "Test failed: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        } catch (e: Exception) {
            showProgress(false)
            Toast.makeText(this, "Error running test: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun redirectToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        startBookingBtn.isEnabled = !show
        viewAllBookingsBtn.isEnabled = !show
    }
    
    override fun onResume() {
        super.onResume()
        // Refresh data when returning to dashboard
        loadDashboardData()
    }
}
