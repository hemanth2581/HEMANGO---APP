package com.example.hemangoo.ui.booking

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import kotlinx.coroutines.launch
import java.util.Calendar

class SelectFactoryActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var factoriesListView: ListView
    private lateinit var progressBar: ProgressBar
    private lateinit var backButton: Button
    
    private var mangoType: String = ""
    private var mangoVariety: String = ""
    private var minQuantity: Double = 0.0
    private var maxQuantity: Double = 0.0
    private var quantity: Double = 0.0
    private var unit: String = ""
    private var currentUser: User? = null
    private var factories: List<Factory> = emptyList()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_factory_simple)
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        // Get data from previous activity
        mangoType = intent.getStringExtra("mango_type") ?: ""
        mangoVariety = intent.getStringExtra("mango_variety") ?: ""
        minQuantity = intent.getDoubleExtra("min_quantity", 0.0)
        maxQuantity = intent.getDoubleExtra("max_quantity", 0.0)
        quantity = intent.getDoubleExtra("quantity", 0.0)
        unit = intent.getStringExtra("unit") ?: ""
        
        initializeViews()
        setupClickListeners()
        loadFactories()
    }
    
    private fun initializeViews() {
        factoriesListView = findViewById(R.id.factoriesListView)
        progressBar = findViewById(R.id.progressBar)
        backButton = findViewById(R.id.backButton)
        
        progressBar.visibility = View.GONE
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }
    }
    
    private fun loadFactories() {
        showProgress(true)
        
        lifecycleScope.launch {
            try {
                factories = localStorageManager.getAllFactories()
                
                runOnUiThread {
                    if (factories.isEmpty()) {
                        showEmptyState()
                    } else {
                        setupFactoriesList()
                    }
                    showProgress(false)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showProgress(false)
                    showError("Error loading factories: ${e.message}")
                }
            }
        }
    }
    
    private fun setupFactoriesList() {
        val adapter = FactoryListAdapter(this, factories) { factory ->
            // Handle book slot button click
            proceedToSlotSelection(factory)
        }
        factoriesListView.adapter = adapter
    }
    
    private fun proceedToSlotSelection(factory: Factory) {
        try {
            // Validate all required data before proceeding
            if (mangoType.isEmpty() || mangoVariety.isEmpty() || quantity <= 0) {
                android.util.Log.e("SelectFactory", "Invalid data - Type: $mangoType, Variety: $mangoVariety, Quantity: $quantity")
                showError("Invalid booking data. Please restart the booking process.")
                return
            }
            
            if (factory.id <= 0 || factory.name.isEmpty()) {
                android.util.Log.e("SelectFactory", "Invalid factory - ID: ${factory.id}, Name: ${factory.name}")
                showError("Invalid factory selection. Please try again.")
                return
            }
            
            android.util.Log.d("SelectFactory", "Proceeding with: $mangoType $mangoVariety, $quantity $unit, Factory: ${factory.name}")
            
            // According to PRD, after factory selection comes quality report submission
            proceedToQualityReport(factory)
            
        } catch (e: Exception) {
            android.util.Log.e("SelectFactory", "Error navigating to quality report", e)
            showError("Error proceeding to quality report: ${e.message}")
        }
    }
    
    private fun proceedToQualityReport(factory: Factory) {
        try {
            android.util.Log.d("SelectFactory", "Proceeding to quality report submission...")
            
            val intent = Intent(this, QualityReportActivity::class.java)
            intent.putExtra("mango_type", mangoType)
            intent.putExtra("mango_variety", mangoVariety)
            intent.putExtra("min_quantity", minQuantity)
            intent.putExtra("max_quantity", maxQuantity)
            intent.putExtra("quantity", quantity)
            intent.putExtra("unit", unit)
            intent.putExtra("factory_id", factory.id)
            intent.putExtra("factory_name", factory.name)
            intent.putExtra("factory_location", factory.location)
            
            startActivity(intent)
            
        } catch (e: Exception) {
            android.util.Log.e("SelectFactory", "Error proceeding to quality report", e)
            showError("Error proceeding: ${e.message}")
        }
    }
    
    private fun getCurrentDate(): String {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        return String.format("%04d-%02d-%02d", year, month, day)
    }
    
    private fun showProgress(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        factoriesListView.isEnabled = !show
    }
    
    private fun showEmptyState() {
        // Create a simple empty state message
        val emptyView = TextView(this).apply {
            text = "No factories available at the moment.\nPlease try again later."
            textSize = 16f
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            setPadding(32, 64, 32, 64)
            gravity = android.view.Gravity.CENTER
        }
        factoriesListView.emptyView = emptyView
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}

class FactoryListAdapter(
    private val context: android.content.Context,
    private val factories: List<Factory>,
    private val onBookSlotClick: (Factory) -> Unit
) : BaseAdapter() {
    
    override fun getCount(): Int = factories.size
    
    override fun getItem(position: Int): Any = factories[position]
    
    override fun getItemId(position: Int): Long = position.toLong()
    
    override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup?): View {
        val view = convertView ?: android.view.LayoutInflater.from(context)
            .inflate(R.layout.item_factory, parent, false)
        
        val factory = factories[position]
        
        val nameText = view.findViewById<TextView>(R.id.factoryNameText)
        val locationText = view.findViewById<TextView>(R.id.factoryLocationText)
        val capacityText = view.findViewById<TextView>(R.id.factoryCapacityText)
        val bookSlotButton = view.findViewById<Button>(R.id.bookSlotButton)
        
        nameText.text = factory.name
        locationText.text = factory.location
        capacityText.text = "Capacity: ${factory.capacityPerDay} tons"
        
        // Handle book slot button click
        bookSlotButton.setOnClickListener {
            onBookSlotClick(factory)
        }
        
        return view
    }
}
