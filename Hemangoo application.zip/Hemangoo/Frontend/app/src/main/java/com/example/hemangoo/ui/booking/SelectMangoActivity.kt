package com.example.hemangoo.ui.booking

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import kotlinx.coroutines.launch
import android.util.Log

class SelectMangoActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var mangoTypeSpinner: Spinner
    private lateinit var mangoVarietySpinner: Spinner
    private lateinit var minQuantityEditText: EditText
    private lateinit var maxQuantityEditText: EditText
    private lateinit var quantityEditText: EditText
    private lateinit var unitSpinner: Spinner
    private lateinit var seasonInfoText: TextView
    private lateinit var nextButton: Button
    private lateinit var progressBar: ProgressBar
    
    private var selectedMangoType: String = ""
    private var selectedVariety: MangoVariety? = null
    private var currentUser: User? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_mangoes)
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        initializeViews()
        setupSpinners()
        setupClickListeners()
    }
    
    private fun initializeViews() {
        mangoTypeSpinner = findViewById(R.id.mangoTypeSpinner)
        mangoVarietySpinner = findViewById(R.id.mangoVarietySpinner)
        minQuantityEditText = findViewById(R.id.minQuantityEditText)
        maxQuantityEditText = findViewById(R.id.maxQuantityEditText)
        quantityEditText = findViewById(R.id.quantityEditText)
        unitSpinner = findViewById(R.id.unitSpinner)
        seasonInfoText = findViewById(R.id.seasonInfoText)
        nextButton = findViewById(R.id.nextButton)
        progressBar = findViewById(R.id.progressBar)
        
        progressBar.visibility = View.GONE
    }
    
    private fun setupSpinners() {
        // Mango type spinner
        val mangoTypes = listOf("Mango", "Organic Mango", "Premium Mango")
        val typeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, mangoTypes)
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        mangoTypeSpinner.adapter = typeAdapter
        
        // Unit spinner
        val units = listOf("Kg", "Tons", "Quintal")
        val unitAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, units)
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        unitSpinner.adapter = unitAdapter
        
        // Mango type selection listener
        mangoTypeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedMangoType = mangoTypes[position]
                loadMangoVarieties(selectedMangoType)
            }
            
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        
        // Mango variety selection listener
        mangoVarietySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val varieties = localStorageManager.getMangoVarietiesByType(selectedMangoType)
                if (position < varieties.size) {
                    selectedVariety = varieties[position]
                    updateSeasonInfo()
                }
            }
            
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }
    
    private fun loadMangoVarieties(type: String) {
        lifecycleScope.launch {
            try {
                val varieties = localStorageManager.getMangoVarietiesByType(type)
                val varietyNames = varieties.map { it.name }
                
                runOnUiThread {
                    val varietyAdapter = ArrayAdapter(this@SelectMangoActivity, android.R.layout.simple_spinner_item, varietyNames)
                    varietyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    mangoVarietySpinner.adapter = varietyAdapter
                    
                    if (varieties.isNotEmpty()) {
                        selectedVariety = varieties[0]
                        updateSeasonInfo()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@SelectMangoActivity, "Error loading mango varieties: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun updateSeasonInfo() {
        selectedVariety?.let { variety ->
            val priceInfo = if (variety.basePricePerKg > 0) {
                "\nCurrent Price: ₹${variety.basePricePerKg}/kg"
            } else {
                "\nPrice: Contact admin for pricing"
            }
            
            seasonInfoText.text = "Season: ${variety.seasonStart} - ${variety.seasonEnd}\n${variety.description}$priceInfo"
            seasonInfoText.visibility = View.VISIBLE
        }
    }
    
    private fun setupClickListeners() {
        nextButton.setOnClickListener {
            if (validateInputs()) {
                proceedToFactorySelection()
            }
        }
    }
    
    private fun validateInputs(): Boolean {
        val minQuantity = minQuantityEditText.text.toString().trim()
        val maxQuantity = maxQuantityEditText.text.toString().trim()
        val quantity = quantityEditText.text.toString().trim()
        
        // Validate minimum quantity
        if (minQuantity.isEmpty()) {
            minQuantityEditText.error = "Minimum quantity is required"
            return false
        }
        
        val minQuantityValue = minQuantity.toDoubleOrNull()
        if (minQuantityValue == null || minQuantityValue <= 0) {
            minQuantityEditText.error = "Please enter a valid minimum quantity"
            return false
        }
        
        // Validate maximum quantity
        if (maxQuantity.isEmpty()) {
            maxQuantityEditText.error = "Maximum quantity is required"
            return false
        }
        
        val maxQuantityValue = maxQuantity.toDoubleOrNull()
        if (maxQuantityValue == null || maxQuantityValue <= 0) {
            maxQuantityEditText.error = "Please enter a valid maximum quantity"
            return false
        }
        
        // Check that min <= max
        if (minQuantityValue > maxQuantityValue) {
            maxQuantityEditText.error = "Maximum quantity must be greater than minimum quantity"
            return false
        }
        
        // Validate expected quantity
        if (quantity.isEmpty()) {
            quantityEditText.error = "Expected quantity is required"
            return false
        }
        
        val quantityValue = quantity.toDoubleOrNull()
        if (quantityValue == null || quantityValue <= 0) {
            quantityEditText.error = "Please enter a valid expected quantity"
            return false
        }
        
        // Check that expected quantity is within min-max range
        if (quantityValue < minQuantityValue || quantityValue > maxQuantityValue) {
            quantityEditText.error = "Expected quantity must be between $minQuantityValue and $maxQuantityValue"
            return false
        }
        
        if (selectedVariety == null) {
            Toast.makeText(this, "Please select a mango variety", Toast.LENGTH_SHORT).show()
            return false
        }
        
        return true
    }
    
    private fun proceedToFactorySelection() {
        val minQuantity = minQuantityEditText.text.toString().trim().toDouble()
        val maxQuantity = maxQuantityEditText.text.toString().trim().toDouble()
        val quantity = quantityEditText.text.toString().trim().toDouble()
        val unit = unitSpinner.selectedItem.toString()
        
        val intent = Intent(this, SelectFactoryActivity::class.java)
        intent.putExtra("mango_type", selectedMangoType)
        intent.putExtra("mango_variety", selectedVariety?.name ?: "")
        intent.putExtra("min_quantity", minQuantity)
        intent.putExtra("max_quantity", maxQuantity)
        intent.putExtra("quantity", quantity)
        intent.putExtra("unit", unit)
        startActivity(intent)
    }
}
