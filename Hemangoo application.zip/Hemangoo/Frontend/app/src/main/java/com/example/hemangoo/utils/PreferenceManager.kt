package com.example.hemangoo.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.hemangoo.data.models.User
import com.google.gson.Gson

class PreferenceManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("hemango_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_DATA = "user_data"
        private const val KEY_AUTH_TOKEN = "auth_token"
        private const val KEY_USER_ID = "user_id"
    }
    
    fun saveUser(user: User) {
        val userJson = gson.toJson(user)
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_USER_DATA, userJson)
            putString(KEY_AUTH_TOKEN, user.token)
            putInt(KEY_USER_ID, user.id)
            apply()
        }
    }
    
    fun getUser(): User? {
        val userJson = prefs.getString(KEY_USER_DATA, null)
        return if (userJson != null) {
            gson.fromJson(userJson, User::class.java)
        } else {
            null
        }
    }
    
    fun getUserId(): Int? {
        return if (prefs.contains(KEY_USER_ID)) {
            prefs.getInt(KEY_USER_ID, -1)
        } else {
            null
        }
    }
    
    fun getAuthToken(): String? {
        return prefs.getString(KEY_AUTH_TOKEN, null)
    }
    
    fun isLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false) && getUser() != null
    }
    
    fun logout() {
        prefs.edit().clear().apply()
    }
    
    fun updateUserToken(token: String) {
        prefs.edit().putString(KEY_AUTH_TOKEN, token).apply()
    }
}
