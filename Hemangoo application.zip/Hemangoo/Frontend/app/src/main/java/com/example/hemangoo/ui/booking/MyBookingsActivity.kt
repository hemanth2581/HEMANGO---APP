package com.example.hemangoo.ui.booking

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.data.models.*
import com.example.hemangoo.ui.dashboard.FarmerDashboardActivity
import kotlinx.coroutines.launch

class MyBookingsActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var backButton: ImageView
    private lateinit var myBookingsTitle: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var bookingScrollView: ScrollView
    private lateinit var bookingContainer: LinearLayout
    private lateinit var emptyStateText: TextView
    
    private var currentUser: User? = null
    private val allBookings = mutableListOf<Booking>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mybookings)
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser()
        
        if (currentUser == null) {
            finish()
            return
        }
        
        initializeViews()
        setupClickListeners()
        loadBookings()
    }
    
    private fun initializeViews() {
        try {
            backButton = findViewById(R.id.backButton)
            myBookingsTitle = findViewById(R.id.myBookingsTitle)
            bookingScrollView = findViewById(R.id.bookingScroll)
            emptyStateText = findViewById(R.id.emptyStateText)
            
            // Get the container inside ScrollView
            val scrollViewChild = bookingScrollView.getChildAt(0) as LinearLayout
            bookingContainer = scrollViewChild.findViewById(R.id.bookingsContainer)
            
            // Create progress bar programmatically since it doesn't exist in layout
            progressBar = ProgressBar(this).apply {
                visibility = View.GONE
            }
            
            Log.d("MyBookings", "Views initialized successfully")
        } catch (e: Exception) {
            Log.e("MyBookings", "Error initializing views", e)
            Toast.makeText(this, "Failed to initialize screen: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            Log.d("MyBookings", "Back button clicked")
            finish()
        }
    }
    
    
    private fun loadBookings() {
        showLoading(true)
        Log.d("MyBookings", "Loading bookings for user: ${currentUser?.id}")
        
        lifecycleScope.launch {
            try {
                currentUser?.let { user ->
                    val bookingsList = localStorageManager.getBookingsByFarmer(user.id)
                    
                    runOnUiThread {
                        showLoading(false)
                        
                        allBookings.clear()
                        allBookings.addAll(bookingsList)
                        displayBookings()
                        
                        Log.d("MyBookings", "Successfully loaded ${bookingsList.size} bookings")
                    }
                } ?: run {
                    runOnUiThread {
                        showLoading(false)
                        showError("User not found")
                        finish()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    showLoading(false)
                    Log.e("MyBookings", "Error loading bookings", e)
                    showError("Error loading bookings: ${e.message}")
                }
            }
        }
    }
    
    private fun showLoading(show: Boolean) {
        bookingScrollView.visibility = if (show) View.GONE else View.VISIBLE
        emptyStateText.visibility = View.GONE
        if (show) {
            myBookingsTitle.text = "Loading bookings..."
        }
    }
    
    private fun displayBookings() {
        if (allBookings.isEmpty()) {
            showEmptyState()
        } else {
            showBookingsContent()
        }
    }

    private fun showEmptyState() {
        myBookingsTitle.text = "My Bookings"
        bookingScrollView.visibility = View.GONE
        emptyStateText.visibility = View.VISIBLE
        emptyStateText.text = "No bookings found. Start by creating your first booking!"
    }
    
    private fun showBookingsContent() {
        myBookingsTitle.text = "My Bookings"
        bookingScrollView.visibility = View.VISIBLE
        emptyStateText.visibility = View.GONE
        updateBookingCards()
    }
    
    private fun updateBookingCards() {
        // Clear existing dynamic content
        bookingContainer.removeAllViews()
        
        Log.d("MyBookings", "Updating booking cards with ${allBookings.size} bookings")
        
        // Add each booking as a card
        for (booking in allBookings) {
            val bookingCard = createBookingCard(booking)
            bookingContainer.addView(bookingCard)
        }
    }
    
    private fun createBookingCard(booking: Booking): View {
        val cardView = androidx.cardview.widget.CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 20, 0, 12)
            }
            radius = 18f * resources.displayMetrics.density
            cardElevation = 0f
            setCardBackgroundColor(getColor(android.R.color.background_light))
        }
        
        val horizontalLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(
                (18 * resources.displayMetrics.density).toInt(),
                (18 * resources.displayMetrics.density).toInt(),
                (18 * resources.displayMetrics.density).toInt(),
                (18 * resources.displayMetrics.density).toInt()
            )
        }
        
        // Left content
        val leftLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            )
        }
        
        val factoryNameText = TextView(this).apply {
            text = booking.factoryName
            textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(getColor(android.R.color.black))
        }
        
        val bookingInfoText = TextView(this).apply {
            text = "${booking.quantity} ${booking.unit} of ${booking.mangoVariety}"
            textSize = 15f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(0, (3 * resources.displayMetrics.density).toInt(), 0, 0)
        }
        
        val dateTimeText = TextView(this).apply {
            val displayDate = booking.assignedDate ?: booking.bookingDate
            val displayTime = booking.assignedTime ?: booking.slotTime
            text = "$displayDate at $displayTime"
            textSize = 14f
            setTextColor(getColor(R.color.text_secondary))
            setPadding(0, (3 * resources.displayMetrics.density).toInt(), 0, 0)
        }
        
        leftLayout.addView(factoryNameText)
        leftLayout.addView(bookingInfoText)
        leftLayout.addView(dateTimeText)
        
        // Status chip
        val statusText = TextView(this).apply {
            text = booking.status.name.lowercase().replaceFirstChar { it.uppercase() }
            textSize = 15f
            setTypeface(null, android.graphics.Typeface.BOLD)
            
            val (textColor, backgroundColor) = when (booking.status) {
                BookingStatus.PENDING -> Pair(android.R.color.holo_orange_dark, R.color.pending_bg)
                BookingStatus.CONFIRMED -> Pair(android.R.color.holo_green_dark, R.color.approved_bg)
                BookingStatus.REJECTED -> Pair(android.R.color.holo_red_dark, R.color.rejected_bg)
            }
            
            setTextColor(getColor(textColor))
            setBackgroundResource(backgroundColor)
            
            setPadding(
                (16 * resources.displayMetrics.density).toInt(),
                (6 * resources.displayMetrics.density).toInt(),
                (16 * resources.displayMetrics.density).toInt(),
                (6 * resources.displayMetrics.density).toInt()
            )
            
            gravity = android.view.Gravity.CENTER
            minHeight = (28 * resources.displayMetrics.density).toInt()
            
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginStart = (8 * resources.displayMetrics.density).toInt()
            layoutParams = params
        }
        
        horizontalLayout.addView(leftLayout)
        horizontalLayout.addView(statusText)
        
        // Add rejection reason if rejected
        if (booking.status == BookingStatus.REJECTED && !booking.rejectionReason.isNullOrEmpty()) {
            val verticalLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(
                    (18 * resources.displayMetrics.density).toInt(),
                    (18 * resources.displayMetrics.density).toInt(),
                    (18 * resources.displayMetrics.density).toInt(),
                    (18 * resources.displayMetrics.density).toInt()
                )
            }
            
            val separator = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (1 * resources.displayMetrics.density).toInt()
                ).apply {
                    topMargin = (14 * resources.displayMetrics.density).toInt()
                }
                setBackgroundColor(getColor(android.R.color.darker_gray))
            }
            
            val rejectionLabel = TextView(this).apply {
                text = "Rejection Reason"
                textSize = 16f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(getColor(android.R.color.black))
                setPadding(0, (16 * resources.displayMetrics.density).toInt(), 0, 0)
            }
            
            val rejectionText = TextView(this).apply {
                text = booking.rejectionReason
                textSize = 15f
                setTextColor(getColor(R.color.text_secondary))
                setPadding(0, (4 * resources.displayMetrics.density).toInt(), 0, 0)
            }
            
            verticalLayout.addView(horizontalLayout)
            verticalLayout.addView(separator)
            verticalLayout.addView(rejectionLabel)
            verticalLayout.addView(rejectionText)
            
            cardView.addView(verticalLayout)
        } else {
            cardView.addView(horizontalLayout)
        }
        
        // Add click listener to open booking details
        cardView.setOnClickListener {
            val intent = Intent(this, com.example.hemangoo.ui.booking.BookingDetailsActivity::class.java)
            intent.putExtra("booking_id", booking.id)
            startActivity(intent)
        }
        
        return cardView
    }
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        emptyStateText.text = "Error loading bookings"
        bookingScrollView.visibility = View.GONE
    }
    
    
    
    override fun onResume() {
        super.onResume()
        // Refresh bookings when returning to this activity
        loadBookings()
    }
}

