package com.example.hemangoo.database

/**
 * LOCAL DATABASE SCHEMA
 * 
 * This file defines the complete database schema for the offline Hemango app.
 * It includes all tables, relationships, and constraints needed for full functionality.
 */
object LocalDatabaseSchema {
    
    const val DATABASE_VERSION = 1
    const val DATABASE_NAME = "hemango_offline.db"
    
    object Tables {
        const val USERS = "users"
        const val FACTORIES = "factories"
        const val MANGO_VARIETIES = "mango_varieties"
        const val TIME_SLOTS = "time_slots"
        const val QUALITY_REPORTS = "quality_reports"
        const val BOOKINGS = "bookings"
        const val MARKET_DATA = "market_data"
        const val ACTIVITIES = "activities"
        const val USER_SESSIONS = "user_sessions"
    }
    
    object Columns {
        // Users table
        object Users {
            const val ID = "id"
            const val FULL_NAME = "full_name"
            const val EMAIL = "email"
            const val PHONE = "phone"
            const val PASSWORD_HASH = "password_hash"
            const val ROLE = "role"
            const val LOCATION = "location"
            const val IS_ACTIVE = "is_active"
            const val CREATED_AT = "created_at"
            const val UPDATED_AT = "updated_at"
        }
        
        // Factories table
        object Factories {
            const val ID = "id"
            const val NAME = "name"
            const val LOCATION = "location"
            const val ADDRESS = "address"
            const val PHONE = "phone"
            const val EMAIL = "email"
            const val CAPACITY_PER_DAY = "capacity_per_day"
            const val IS_ACTIVE = "is_active"
            const val CREATED_AT = "created_at"
            const val UPDATED_AT = "updated_at"
        }
        
        // Mango varieties table
        object MangoVarieties {
            const val ID = "id"
            const val NAME = "name"
            const val TYPE = "type"
            const val SEASON_START = "season_start"
            const val SEASON_END = "season_end"
            const val DESCRIPTION = "description"
            const val BASE_PRICE_PER_KG = "base_price_per_kg"
            const val IMAGE_URL = "image_url"
            const val IS_ACTIVE = "is_active"
            const val CREATED_AT = "created_at"
        }
        
        // Time slots table
        object TimeSlots {
            const val ID = "id"
            const val FACTORY_ID = "factory_id"
            const val SLOT_DATE = "slot_date"
            const val START_TIME = "start_time"
            const val END_TIME = "end_time"
            const val TIME_SLOT = "time_slot" // e.g., "9:00 AM - 10:00 AM"
            const val MAX_CAPACITY_KG = "max_capacity_kg"
            const val CURRENT_BOOKINGS_KG = "current_bookings_kg"
            const val AVAILABLE_CAPACITY_KG = "available_capacity_kg"
            const val PRICE_PER_KG = "price_per_kg"
            const val IS_AVAILABLE = "is_available"
            const val CREATED_AT = "created_at"
            const val UPDATED_AT = "updated_at"
        }
        
        // Quality reports table
        object QualityReports {
            const val ID = "id"
            const val USER_ID = "user_id"
            const val MANGO_TYPE = "mango_type"
            const val MANGO_VARIETY = "mango_variety"
            const val ESTIMATED_QUANTITY = "estimated_quantity"
            const val UNIT = "unit"
            const val HARVEST_DATE = "harvest_date"
            const val RIPENESS_LEVEL = "ripeness_level"
            const val COLOUR = "colour"
            const val SIZE = "size"
            const val BRUISING_LEVEL = "bruising_level"
            const val PEST_PRESENCE = "pest_presence"
            const val ADDITIONAL_NOTES = "additional_notes"
            const val IMAGES = "images"
            const val ADMIN_REVIEW_STATUS = "admin_review_status"
            const val ADMIN_NOTES = "admin_notes"
            const val REVIEWED_BY = "reviewed_by"
            const val REVIEWED_AT = "reviewed_at"
            const val CREATED_AT = "created_at"
            const val UPDATED_AT = "updated_at"
        }
        
        // Bookings table
        object Bookings {
            const val ID = "id"
            const val USER_ID = "user_id"
            const val FACTORY_ID = "factory_id"
            const val TIME_SLOT_ID = "time_slot_id"
            const val QUALITY_REPORT_ID = "quality_report_id"
            const val MANGO_TYPE = "mango_type"
            const val MANGO_VARIETY = "mango_variety"
            const val QUANTITY = "quantity"
            const val UNIT = "unit"
            const val BOOKING_DATE = "booking_date"
            const val SLOT_TIME = "slot_time"
            const val PREFERRED_DATES = "preferred_dates" // JSON array of preferred dates
            const val PREFERRED_TIMES = "preferred_times" // JSON array of preferred time slots
            const val ASSIGNED_DATE = "assigned_date" // Admin assigned date
            const val ASSIGNED_TIME = "assigned_time" // Admin assigned time
            const val STATUS = "status"
            const val REVIEWED_BY = "reviewed_by"
            const val REVIEWED_AT = "reviewed_at"
            const val ADMIN_NOTES = "admin_notes"
            const val REJECTION_REASON = "rejection_reason"
            const val CREATED_AT = "created_at"
            const val UPDATED_AT = "updated_at"
        }
        
        // Market data table
        object MarketData {
            const val ID = "id"
            const val MANGO_TYPE = "mango_type"
            const val MANGO_VARIETY = "mango_variety"
            const val PRICE_PER_KG = "price_per_kg"
            const val MARKET_LOCATION = "market_location"
            const val PRICE_DATE = "price_date"
            const val SOURCE = "source"
            const val CREATED_AT = "created_at"
        }
        
        // Activities table
        object Activities {
            const val ID = "id"
            const val USER_ID = "user_id"
            const val ACTIVITY_TYPE = "activity_type"
            const val ACTIVITY_MESSAGE = "activity_message"
            const val RELATED_BOOKING_ID = "related_booking_id"
            const val CREATED_AT = "created_at"
        }
        
        // User sessions table
        object UserSessions {
            const val ID = "id"
            const val USER_ID = "user_id"
            const val TOKEN = "token"
            const val DEVICE_INFO = "device_info"
            const val EXPIRES_AT = "expires_at"
            const val CREATED_AT = "created_at"
            const val LAST_ACTIVITY = "last_activity"
        }
    }
    
    object Retention {
        const val MAX_ACTIVITIES_COUNT = 100
        const val MAX_SESSIONS_COUNT = 10
        const val MAX_MARKET_DATA_DAYS = 30
    }
    
    object Backup {
        const val BACKUP_FILENAME_PREFIX = "hemango_backup_"
        const val BACKUP_FILE_EXTENSION = ".json"
    }
}