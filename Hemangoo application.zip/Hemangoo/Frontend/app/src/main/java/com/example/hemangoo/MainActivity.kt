package com.example.hemangoo

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.hemangoo.ui.auth.LoginActivity
import com.example.hemangoo.ui.dashboard.FarmerDashboardActivity
import com.example.hemangoo.ui.dashboard.AdminDashboardActivity
import com.example.hemangoo.LocalStorageManager

class MainActivity : AppCompatActivity() {

    private lateinit var localStorageManager: LocalStorageManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        
        localStorageManager = LocalStorageManager(this)
        
        // Initialize sample data
        // Data is automatically initialized in LocalStorageManager constructor
        
        val rootView = findViewById<android.view.View>(R.id.mainLayout)
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Show splash screen for 2 seconds then navigate
        Handler(Looper.getMainLooper()).postDelayed({
            navigateToNextScreen()
        }, 2000)
    }
    
    private fun navigateToNextScreen() {
        val intent = if (localStorageManager.isLoggedIn()) {
            val user = localStorageManager.getCurrentUser()
            when (user?.role) {
                "farmer" -> Intent(this, FarmerDashboardActivity::class.java)
                "admin" -> Intent(this, AdminDashboardActivity::class.java)
                else -> Intent(this, LoginActivity::class.java)
            }
        } else {
            Intent(this, LoginActivity::class.java)
        }
        
        startActivity(intent)
        finish()
    }
}