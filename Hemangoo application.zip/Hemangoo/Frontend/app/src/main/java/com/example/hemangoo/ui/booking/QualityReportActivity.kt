package com.example.hemangoo.ui.booking

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hemangoo.R
import com.example.hemangoo.LocalStorageManager
import com.example.hemangoo.ImageUploadAdapter
import com.example.hemangoo.data.models.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Quality Report Activity - PRD Section FR-2.5
 * Allows farmers to submit detailed quality parameters and images of their mangoes
 */
class QualityReportActivity : AppCompatActivity() {
    
    private lateinit var localStorageManager: LocalStorageManager
    private lateinit var currentUser: User
    
    // UI Elements
    private lateinit var backButton: Button
    private lateinit var farmerNameText: TextView
    private lateinit var farmerLocationText: TextView
    private lateinit var mangoVarietySpinner: Spinner
    private lateinit var harvestDateEditText: EditText
    private lateinit var estimatedQuantityEditText: EditText
    private lateinit var estimatedQuantityUnitText: TextView
    
    // Quality Parameters
    private lateinit var ripenessSpinner: Spinner
    private lateinit var colorSpinner: Spinner
    private lateinit var sizeSpinner: Spinner
    private lateinit var bruisingSpinner: Spinner
    private lateinit var pestPresenceRadioGroup: RadioGroup
    private lateinit var pestYesRadio: RadioButton
    private lateinit var pestNoRadio: RadioButton
    private lateinit var notesEditText: EditText
    
    // Image Upload
    private lateinit var addImageButton: Button
    private lateinit var imagesRecyclerView: RecyclerView
    private lateinit var imageUploadAdapter: ImageUploadAdapter
    
    // Navigation
    private lateinit var submitButton: Button
    private lateinit var progressBar: ProgressBar
    
    // Data from previous activities
    private var mangoType: String = ""
    private var mangoVariety: String = ""
    private var minQuantity: Double = 0.0
    private var maxQuantity: Double = 0.0
    private var quantity: Double = 0.0
    private var unit: String = ""
    private var factoryId: Int = 0
    private var factoryName: String = ""
    private var factoryLocation: String = ""
    
    // Quality report data
    private val selectedImages = mutableListOf<Uri>()
    private var qualityReport: QualityReport? = null
    
    // Image picker launcher for gallery selection
    private val galleryLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            handleImageSelection(it)
        }
    }
    
    // Multiple image picker launcher
    private val multipleImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        handleMultipleImageSelection(uris)
    }
    
    // Permission launcher for storage access
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        handlePermissionResult(permissions)
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quality_report)
        
        localStorageManager = LocalStorageManager(this)
        currentUser = localStorageManager.getCurrentUser() ?: run {
            Log.e("QualityReport", "No current user found")
            finish()
            return
        }
        
        Log.d("QualityReport", "Quality report starting for user: ${currentUser.fullName}")
        
        getIntentData()
        initializeViews()
        setupClickListeners()
        populateFormData()
    }
    
    private fun getIntentData() {
        mangoType = intent.getStringExtra("mango_type") ?: ""
        mangoVariety = intent.getStringExtra("mango_variety") ?: ""
        minQuantity = intent.getDoubleExtra("min_quantity", 0.0)
        maxQuantity = intent.getDoubleExtra("max_quantity", 0.0)
        quantity = intent.getDoubleExtra("quantity", 0.0)
        unit = intent.getStringExtra("unit") ?: ""
        factoryId = intent.getIntExtra("factory_id", 0)
        factoryName = intent.getStringExtra("factory_name") ?: ""
        factoryLocation = intent.getStringExtra("factory_location") ?: ""
        
        Log.d("QualityReport", "Received data: $mangoType $mangoVariety, $quantity $unit")
        Log.d("QualityReport", "Factory: $factoryName (ID: $factoryId)")
        
        // Validate received data
        if (mangoType.isEmpty() || factoryId <= 0) {
            Log.e("QualityReport", "Invalid data received")
            showError("Invalid booking data. Please restart the process.")
            finish()
        }
    }
    
    private fun initializeViews() {
        try {
            // Header
            backButton = findViewById(R.id.backButton)
            
            // Pre-populated information
            farmerNameText = findViewById(R.id.farmerNameText)
            farmerLocationText = findViewById(R.id.farmerLocationText)
            
            // Form fields
            mangoVarietySpinner = findViewById(R.id.mangoVarietySpinner)
            harvestDateEditText = findViewById(R.id.harvestDateEditText)
            estimatedQuantityEditText = findViewById(R.id.estimatedQuantityEditText)
            estimatedQuantityUnitText = findViewById(R.id.estimatedQuantityUnitText)
            
            // Quality parameters
            ripenessSpinner = findViewById(R.id.ripenessSpinner)
            colorSpinner = findViewById(R.id.colorSpinner)
            sizeSpinner = findViewById(R.id.sizeSpinner)
            bruisingSpinner = findViewById(R.id.bruisingSpinner)
            pestPresenceRadioGroup = findViewById(R.id.pestPresenceRadioGroup)
            pestYesRadio = findViewById(R.id.pestYesRadio)
            pestNoRadio = findViewById(R.id.pestNoRadio)
            notesEditText = findViewById(R.id.notesEditText)
            
            // Image upload
            addImageButton = findViewById(R.id.addImageButton)
            imagesRecyclerView = findViewById(R.id.imagesRecyclerView)
            
            // Navigation
            submitButton = findViewById(R.id.submitButton)
            progressBar = findViewById(R.id.progressBar)
            
            setupSpinners()
            setupImageRecyclerView()
            progressBar.visibility = View.GONE
            
            Log.d("QualityReport", "Views initialized successfully")
            
        } catch (e: Exception) {
            Log.e("QualityReport", "Error initializing views", e)
            showError("Failed to initialize screen: ${e.message}")
        }
    }
    
    private fun setupSpinners() {
        // Mango varieties (based on type)
        val varieties = when (mangoType) {
            "Alphonso" -> listOf("Select Variety", "Premium", "Grade A", "Regular")
            "Dasheri" -> listOf("Select Variety", "Premium", "Regular")
            "Langra" -> listOf("Select Variety", "Premium", "Regular")
            else -> listOf("Select Variety", "Premium", "Regular")
        }
        setupSpinner(mangoVarietySpinner, varieties)
        
        // Quality parameter spinners
        setupSpinner(ripenessSpinner, listOf("Select Ripeness", "Unripe", "Partially Ripe", "Fully Ripe"))
        setupSpinner(colorSpinner, listOf("Select Color", "Greenish", "Yellow", "Golden", "Mixed"))
        setupSpinner(sizeSpinner, listOf("Select Size", "Small", "Medium", "Large"))
        setupSpinner(bruisingSpinner, listOf("Select Bruising Level", "None", "Light", "Moderate", "Heavy"))
    }
    
    private fun setupSpinner(spinner: Spinner, items: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }
    
    private fun setupImageRecyclerView() {
        imageUploadAdapter = ImageUploadAdapter(selectedImages) { position ->
            // Remove image at position
            imageUploadAdapter.removeImage(position)
            Log.d("QualityReport", "Image removed: ${selectedImages.size} total images")
        }
        imagesRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        imagesRecyclerView.adapter = imageUploadAdapter
    }
    
    private fun setupClickListeners() {
        backButton.setOnClickListener {
            Log.d("QualityReport", "Back button clicked")
            finish()
        }
        
        addImageButton.setOnClickListener {
            Log.d("QualityReport", "Add image button clicked")
            checkPermissionAndPickImage()
        }
        
        submitButton.setOnClickListener {
            Log.d("QualityReport", "Submit button clicked")
            validateAndSubmit()
        }
        
        // Date picker for harvest date
        harvestDateEditText.setOnClickListener {
            showDatePicker()
        }
    }
    
    private fun populateFormData() {
        try {
            // Pre-populate farmer information
            farmerNameText.text = currentUser.fullName
            farmerLocationText.text = "Location not specified"
            
            // Set estimated quantity from previous selection
            estimatedQuantityEditText.setText(quantity.toString())
            estimatedQuantityUnitText.text = unit
            
            // Select the mango variety from previous selection
            val varietyPosition = (mangoVarietySpinner.adapter as? ArrayAdapter<String>)
                ?.getPosition(mangoVariety) ?: 0
            if (varietyPosition > 0) {
                mangoVarietySpinner.setSelection(varietyPosition)
            }
            
            // Set default harvest date to today
            val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            harvestDateEditText.setText(currentDate)
            
            // Default pest presence to "No"
            pestNoRadio.isChecked = true
            
            Log.d("QualityReport", "Form data populated successfully")
            
        } catch (e: Exception) {
            Log.e("QualityReport", "Error populating form data", e)
        }
    }
    
    private fun checkPermissionAndPickImage() {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                // Android 13+ uses READ_MEDIA_IMAGES
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) 
                    == PackageManager.PERMISSION_GRANTED) {
                    showImagePickerOptions()
                } else {
                    requestStoragePermission()
                }
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                // Android 6+ uses READ_EXTERNAL_STORAGE
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) 
                    == PackageManager.PERMISSION_GRANTED) {
                    showImagePickerOptions()
                } else {
                    requestStoragePermission()
                }
            }
            else -> {
                // Below Android 6, permissions are granted at install time
                showImagePickerOptions()
            }
        }
    }
    
    private fun requestStoragePermission() {
        val permissions = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU -> {
                arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            }
            else -> {
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        
        // Check if we should show permission rationale
        val shouldShowRationale = permissions.any { permission ->
            ActivityCompat.shouldShowRequestPermissionRationale(this, permission)
        }
        
        if (shouldShowRationale) {
            showPermissionRationale(permissions)
        } else {
            permissionLauncher.launch(permissions)
        }
    }
    
    private fun showPermissionRationale(permissions: Array<String>) {
        AlertDialog.Builder(this)
            .setTitle("Storage Permission Required")
            .setMessage("This app needs access to your device storage to upload images of your mangoes. This helps us assess the quality of your produce.")
            .setPositiveButton("Grant Permission") { _, _ ->
                permissionLauncher.launch(permissions)
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                showError("Storage permission is required to upload images")
            }
            .show()
    }
    
    private fun showImagePickerOptions() {
        val options = arrayOf(
            "Select Single Image", 
            "Select Multiple Images (up to ${6 - selectedImages.size})"
        )
        
        AlertDialog.Builder(this)
            .setTitle("Choose Images")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> pickSingleImage()
                    1 -> pickMultipleImages()
                }
            }
            .show()
    }
    
    private fun pickSingleImage() {
        try {
            galleryLauncher.launch("image/*")
            Log.d("QualityReport", "Opening gallery for single image selection")
        } catch (e: Exception) {
            Log.e("QualityReport", "Error opening gallery", e)
            showError("Failed to open gallery: ${e.message}")
        }
    }
    
    private fun pickMultipleImages() {
        try {
            multipleImageLauncher.launch("image/*")
            Log.d("QualityReport", "Opening gallery for multiple image selection")
        } catch (e: Exception) {
            Log.e("QualityReport", "Error opening gallery", e)
            showError("Failed to open gallery: ${e.message}")
        }
    }
    
    private fun handleImageSelection(uri: Uri) {
        if (imageUploadAdapter.canAddMoreImages()) {
            imageUploadAdapter.addImage(uri)
            Log.d("QualityReport", "Image added: ${selectedImages.size} total images")
        } else {
            showError("Maximum 6 images allowed")
        }
    }
    
    private fun handleMultipleImageSelection(uris: List<Uri>) {
        val availableSlots = 6 - selectedImages.size
        val imagesToAdd = uris.take(availableSlots)
        
        imagesToAdd.forEach { uri ->
            imageUploadAdapter.addImage(uri)
        }
        
        Log.d("QualityReport", "${imagesToAdd.size} images added: ${selectedImages.size} total images")
        
        if (uris.size > availableSlots) {
            showError("Only ${imagesToAdd.size} images were added. Maximum 6 images allowed.")
        } else if (imagesToAdd.isNotEmpty()) {
            Toast.makeText(this, "${imagesToAdd.size} images added successfully", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun handlePermissionResult(permissions: Map<String, Boolean>) {
        val granted = permissions.values.any { it }
        
        if (granted) {
            Log.d("QualityReport", "Storage permission granted")
            showImagePickerOptions()
        } else {
            Log.w("QualityReport", "Storage permission denied")
            
            // Check if user selected "Don't ask again"
            val permissionArray = permissions.keys.toTypedArray()
            val shouldShowRationale = permissionArray.any { permission ->
                ActivityCompat.shouldShowRequestPermissionRationale(this, permission)
            }
            
            if (!shouldShowRationale) {
                // User selected "Don't ask again", show dialog to go to settings
                showPermissionDeniedDialog()
            } else {
                showError("Storage permission is required to upload images")
            }
        }
    }
    
    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permission Required")
            .setMessage("Storage permission has been permanently denied. Please enable it in app settings to upload images.")
            .setPositiveButton("Go to Settings") { _, _ ->
                openAppSettings()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
    
    private fun openAppSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", packageName, null)
            intent.data = uri
            startActivity(intent)
        } catch (e: Exception) {
            Log.e("QualityReport", "Error opening app settings", e)
            showError("Unable to open app settings")
        }
    }
    
    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val datePickerDialog = android.app.DatePickerDialog(
            this,
            { _, year, month, day ->
                val selectedDate = String.format("%04d-%02d-%02d", year, month + 1, day)
                harvestDateEditText.setText(selectedDate)
                Log.d("QualityReport", "Harvest date selected: $selectedDate")
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        
        // Set max date to today (can't harvest in the future)
        datePickerDialog.datePicker.maxDate = System.currentTimeMillis()
        datePickerDialog.show()
    }
    
    private fun validateAndSubmit() {
        try {
            // Validate mango variety
            if (mangoVarietySpinner.selectedItemPosition == 0) {
                showError("Please select a mango variety")
                return
            }
            
            // Validate harvest date
            val harvestDate = harvestDateEditText.text.toString().trim()
            if (harvestDate.isEmpty()) {
                showError("Please select harvest date")
                return
            }
            
            // Validate estimated quantity
            val quantityText = estimatedQuantityEditText.text.toString().trim()
            if (quantityText.isEmpty()) {
                showError("Please enter estimated quantity")
                return
            }
            
            val estimatedQuantity = try {
                quantityText.toDouble()
            } catch (e: NumberFormatException) {
                showError("Please enter a valid quantity")
                return
            }
            
            if (estimatedQuantity <= 0) {
                showError("Quantity must be greater than 0")
                return
            }
            
            // Validate quality parameters
            if (ripenessSpinner.selectedItemPosition == 0) {
                showError("Please select ripeness level")
                return
            }
            
            if (colorSpinner.selectedItemPosition == 0) {
                showError("Please select color")
                return
            }
            
            if (sizeSpinner.selectedItemPosition == 0) {
                showError("Please select size")
                return
            }
            
            if (bruisingSpinner.selectedItemPosition == 0) {
                showError("Please select bruising level")
                return
            }
            
            // Validate pest presence
            if (pestPresenceRadioGroup.checkedRadioButtonId == -1) {
                showError("Please specify pest presence")
                return
            }
            
            // Require at least one image
            if (selectedImages.isEmpty()) {
                showError("Please add at least one image of your mangoes")
                return
            }
            
            Log.d("QualityReport", "Validation passed, creating quality report")
            createQualityReport(harvestDate, estimatedQuantity)
            
        } catch (e: Exception) {
            Log.e("QualityReport", "Error during validation", e)
            showError("Error validating form: ${e.message}")
        }
    }
    
    private fun createQualityReport(harvestDate: String, estimatedQuantity: Double) {
        try {
            val selectedVariety = mangoVarietySpinner.selectedItem.toString()
            val ripeness = ripenessSpinner.selectedItem.toString()
            val color = colorSpinner.selectedItem.toString()
            val size = sizeSpinner.selectedItem.toString()
            val bruising = bruisingSpinner.selectedItem.toString()
            val pestPresence = pestYesRadio.isChecked
            val notes = notesEditText.text.toString().trim()
            
            qualityReport = QualityReport(
                ripenessLevel = ripeness,
                colour = color,
                size = size,
                bruisingLevel = bruising,
                pestPresence = pestPresence,
                harvestDate = harvestDate,
                notes = if (notes.isNotEmpty()) notes else null
            )
            
            Log.d("QualityReport", "Quality report created: $qualityReport")
            
            // Update quantity if different from original
            val finalQuantity = if (estimatedQuantity != quantity) estimatedQuantity else quantity
            
            proceedToSlotSelection(selectedVariety, finalQuantity)
            
        } catch (e: Exception) {
            Log.e("QualityReport", "Error creating quality report", e)
            showError("Error creating quality report: ${e.message}")
        }
    }
    
    private fun proceedToSlotSelection(selectedVariety: String, finalQuantity: Double) {
        try {
            Log.d("QualityReport", "Proceeding to slot selection...")
            
            val intent = Intent(this, SelectSlotActivity::class.java)
            intent.putExtra("mango_type", mangoType)
            intent.putExtra("mango_variety", selectedVariety)
            intent.putExtra("min_quantity", minQuantity)
            intent.putExtra("max_quantity", maxQuantity)
            intent.putExtra("quantity", finalQuantity)
            intent.putExtra("unit", unit)
            intent.putExtra("factory_id", factoryId)
            intent.putExtra("factory_name", factoryName)
            intent.putExtra("harvest_date", harvestDateEditText.text.toString())
            intent.putExtra("quality_report", qualityReport)
            
            startActivity(intent)
            
        } catch (e: Exception) {
            Log.e("QualityReport", "Error proceeding to slot selection", e)
            showError("Error proceeding: ${e.message}")
        }
    }
    
    // Note: onRequestPermissionsResult is now handled by permissionLauncher
    
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        Log.e("QualityReport", "Error: $message")
    }
    
    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
    }
}
