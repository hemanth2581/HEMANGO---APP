package com.example.hemangoo.data.models

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("user_id")
    val id: Int,
    @SerializedName("full_name")
    val fullName: String,
    val email: String,
    val phone: String,
    val role: String,
    val token: String? = null
)

data class LoginRequest(
    val email: String,
    val password: String,
    val role: String
)

data class RegisterRequest(
    @SerializedName("full_name")
    val fullName: String,
    val email: String,
    val phone: String,
    val password: String,
    val role: String
)

data class ApiResponse<T>(
    val status: String,
    val message: String,
    val data: T? = null
)

data class LoginResponse(
    val status: String,
    val message: String,
    val data: User? = null
)

data class RegisterResponse(
    val status: String,
    val message: String,
    val data: User? = null
)
