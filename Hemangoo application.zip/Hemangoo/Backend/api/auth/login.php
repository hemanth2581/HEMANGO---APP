<?php
/**
 * User Login API
 * Secure login with JWT token generation
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/database.php';
require_once '../../config/security.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }
    
    // Extract and sanitize input
    $email = Security::sanitizeInput($input['email'] ?? '');
    $password = $input['password'] ?? '';
    $role = Security::sanitizeInput($input['role'] ?? '');
    
    // Validation
    if (empty($email) || empty($password) || empty($role)) {
        throw new Exception('All fields are required');
    }
    
    if (!Security::validateEmail($email)) {
        throw new Exception('Invalid email format');
    }
    
    if (!in_array($role, ['farmer', 'admin'])) {
        throw new Exception('Invalid role selected');
    }
    
    // Get user from database
    $db = new Database();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("
        SELECT id, full_name, email, phone, password_hash, role, is_active 
        FROM users 
        WHERE email = ? AND role = ? AND is_active = 1
    ");
    $stmt->execute([$email, $role]);
    
    if ($stmt->rowCount() === 0) {
        throw new Exception('Invalid credentials');
    }
    
    $user = $stmt->fetch();
    
    // Verify password
    if (!Security::verifyPassword($password, $user['password_hash'])) {
        throw new Exception('Invalid credentials');
    }
    
    // Generate JWT token
    $token = Security::generateJWT($user['id'], $user['email'], $user['role']);
    
    // Store session
    $stmt = $conn->prepare("
        INSERT INTO user_sessions (user_id, token_hash, expires_at) 
        VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))
    ");
    $stmt->execute([$user['id'], hash('sha256', $token)]);
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Login successful',
        'data' => [
            'id' => $user['id'],
            'fullName' => $user['full_name'],
            'email' => $user['email'],
            'phone' => $user['phone'],
            'role' => $user['role'],
            'token' => $token
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
