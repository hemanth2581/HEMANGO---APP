<?php
/**
 * User Registration API
 * Secure registration with proper validation
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/database.php';
require_once '../../config/security.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }
    
    // Extract and sanitize input
    $full_name = Security::sanitizeInput($input['fullName'] ?? $input['full_name'] ?? '');
    $email = Security::sanitizeInput($input['email'] ?? '');
    $phone = Security::sanitizeInput($input['phone'] ?? '');
    $password = $input['password'] ?? '';
    $role = Security::sanitizeInput($input['role'] ?? 'farmer');
    
    // Validation
    if (empty($full_name) || empty($email) || empty($phone) || empty($password)) {
        throw new Exception('All fields are required');
    }
    
    if (!Security::validateEmail($email)) {
        throw new Exception('Invalid email format');
    }
    
    if (!Security::validatePhone($phone)) {
        throw new Exception('Invalid phone number format');
    }
    
    if (strlen($password) < 8) {
        throw new Exception('Password must be at least 8 characters long');
    }
    
    if (!in_array($role, ['farmer', 'admin'])) {
        throw new Exception('Invalid role selected');
    }
    
    // Check if email already exists
    $db = new Database();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        throw new Exception('Email already exists');
    }
    
    // Check if phone already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
    $stmt->execute([$phone]);
    
    if ($stmt->rowCount() > 0) {
        throw new Exception('Phone number already exists');
    }
    
    // Hash password
    $password_hash = Security::hashPassword($password);
    
    // Insert user
    $stmt = $conn->prepare("
        INSERT INTO users (full_name, email, phone, password_hash, role) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    if ($stmt->execute([$full_name, $email, $phone, $password_hash, $role])) {
        $user_id = $conn->lastInsertId();
        
        // Generate JWT token
        $token = Security::generateJWT($user_id, $email, $role);
        
        // Store session
        $stmt = $conn->prepare("
            INSERT INTO user_sessions (user_id, token_hash, expires_at) 
            VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))
        ");
        $stmt->execute([$user_id, hash('sha256', $token)]);
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Registration successful',
            'data' => [
                'id' => $user_id,
                'fullName' => $full_name,
                'email' => $email,
                'phone' => $phone,
                'role' => $role,
                'token' => $token
            ]
        ]);
    } else {
        throw new Exception('Registration failed');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
