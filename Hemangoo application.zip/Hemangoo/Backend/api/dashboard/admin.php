<?php
/**
 * Admin Dashboard API
 * Get admin-specific dashboard data
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../../config/database.php';
require_once '../../config/security.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit();
}

try {
    // Validate JWT token
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        throw new Exception('Authorization token required');
    }
    
    $token = $matches[1];
    $payload = Security::validateJWT($token);
    
    if (!$payload || $payload['role'] !== 'admin') {
        throw new Exception('Invalid or expired token');
    }
    
    // Get dashboard data
    $db = new Database();
    $conn = $db->getConnection();
    
    // Get booking statistics
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_bookings,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_requests,
            SUM(CASE WHEN status = 'approved' AND DATE(updated_at) = CURDATE() THEN 1 ELSE 0 END) as approved_today,
            SUM(CASE WHEN status = 'rejected' AND DATE(updated_at) = CURDATE() THEN 1 ELSE 0 END) as rejected_today
        FROM bookings
    ");
    $stmt->execute();
    $stats = $stmt->fetch();
    
    // Get recent bookings
    $stmt = $conn->prepare("
        SELECT b.*, f.name as factory_name, mv.name as mango_variety_name, u.full_name as farmer_name
        FROM bookings b
        JOIN factories f ON b.factory_id = f.id
        JOIN mango_varieties mv ON b.mango_variety_id = mv.id
        JOIN users u ON b.user_id = u.id
        ORDER BY b.created_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recent_bookings = $stmt->fetchAll();
    
    echo json_encode([
        'status' => 'success',
        'data' => [
            'total_bookings' => (int)$stats['total_bookings'],
            'pending_requests' => (int)$stats['pending_requests'],
            'approved_today' => (int)$stats['approved_today'],
            'rejected_today' => (int)$stats['rejected_today'],
            'recent_bookings' => $recent_bookings
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
