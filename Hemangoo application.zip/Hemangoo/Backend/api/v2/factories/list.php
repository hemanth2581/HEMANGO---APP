<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        include_once '../../db.php';
        
        // Get all active factories
        $stmt = $conn->prepare("
            SELECT 
                id,
                name,
                location,
                address,
                phone,
                email,
                capacity_per_day,
                is_active,
                created_at
            FROM factories 
            WHERE is_active = 1
            ORDER BY name
        ");
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $factories = [];
        while ($row = $result->fetch_assoc()) {
            $factories[] = [
                'id' => $row['id'],
                'name' => $row['name'],
                'location' => $row['location'],
                'address' => $row['address'],
                'phone' => $row['phone'],
                'email' => $row['email'],
                'capacity_per_day' => $row['capacity_per_day'],
                'is_active' => (bool)$row['is_active'],
                'created_at' => $row['created_at']
            ];
        }
        
        echo json_encode([
            'status' => 'success',
            'factories' => $factories,
            'total' => count($factories)
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
?>
