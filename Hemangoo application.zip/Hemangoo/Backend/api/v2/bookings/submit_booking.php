<?php
/**
 * Booking Submission API Endpoint - v2
 * Handles complete booking flow with quality report integration
 * Matches PRD requirements for booking creation
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../config/database.php';
require_once '../../config/security.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

try {
    // Authenticate user
    $user = authenticateRequest();
    if (!$user || $user['role'] !== 'farmer') {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
        exit;
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $requiredFields = [
        'mango_type', 'mango_variety', 'quantity', 'unit', 
        'factory_id', 'time_slot_id', 'booking_date', 'slot_time',
        'quality_report'
    ];
    
    foreach ($requiredFields as $field) {
        if (!isset($input[$field])) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => "Missing required field: $field"
            ]);
            exit;
        }
    }
    
    // Validate quality report fields
    $qualityReport = $input['quality_report'];
    $qualityRequiredFields = [
        'harvest_date', 'ripeness_level', 'color', 'size', 
        'bruising_level', 'pest_presence'
    ];
    
    foreach ($qualityRequiredFields as $field) {
        if (!isset($qualityReport[$field])) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => "Missing quality report field: $field"
            ]);
            exit;
        }
    }
    
    $pdo = getDatabaseConnection();
    $pdo->beginTransaction();
    
    try {
        // 1. Verify factory and time slot exist and are available
        $slotStmt = $pdo->prepare("
            SELECT fts.*, f.name as factory_name, f.location as factory_location
            FROM factory_time_slots fts
            JOIN factories f ON fts.factory_id = f.id
            WHERE fts.id = ? AND fts.factory_id = ? AND fts.is_available = TRUE
            AND fts.slot_date = ? AND fts.start_time = ?
        ");
        $slotStmt->execute([
            $input['time_slot_id'], 
            $input['factory_id'], 
            $input['booking_date'], 
            $input['slot_time']
        ]);
        $timeSlot = $slotStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$timeSlot) {
            throw new Exception('Selected time slot is not available');
        }
        
        // Check if slot has enough capacity
        $requestedQuantity = floatval($input['quantity']);
        if (($timeSlot['current_bookings_tons'] + $requestedQuantity) > $timeSlot['max_capacity_tons']) {
            throw new Exception('Insufficient capacity for requested quantity');
        }
        
        // 2. Create quality report first
        $qualityStmt = $pdo->prepare("
            INSERT INTO quality_reports (
                user_id, mango_type, mango_variety, estimated_quantity, unit,
                harvest_date, ripeness_level, color, size, bruising_level,
                pest_presence, additional_notes, images
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $qualityStmt->execute([
            $user['id'],
            $input['mango_type'],
            $input['mango_variety'],
            $requestedQuantity,
            $input['unit'],
            $qualityReport['harvest_date'],
            $qualityReport['ripeness_level'],
            $qualityReport['color'],
            $qualityReport['size'],
            $qualityReport['bruising_level'],
            $qualityReport['pest_presence'] ? 1 : 0,
            $qualityReport['notes'] ?? null,
            isset($qualityReport['images']) ? json_encode($qualityReport['images']) : null
        ]);
        
        $qualityReportId = $pdo->lastInsertId();
        
        // 3. Create booking
        $bookingStmt = $pdo->prepare("
            INSERT INTO bookings (
                user_id, factory_id, time_slot_id, quality_report_id,
                mango_type, mango_variety, quantity, unit,
                booking_date, slot_time, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");
        
        $bookingStmt->execute([
            $user['id'],
            $input['factory_id'],
            $input['time_slot_id'],
            $qualityReportId,
            $input['mango_type'],
            $input['mango_variety'],
            $requestedQuantity,
            $input['unit'],
            $input['booking_date'],
            $input['slot_time']
        ]);
        
        $bookingId = $pdo->lastInsertId();
        
        // 4. Update time slot capacity
        $updateSlotStmt = $pdo->prepare("
            UPDATE factory_time_slots 
            SET current_bookings_tons = current_bookings_tons + ?
            WHERE id = ?
        ");
        $updateSlotStmt->execute([$requestedQuantity, $input['time_slot_id']]);
        
        // 5. Log user activity
        $activityStmt = $pdo->prepare("
            INSERT INTO user_activities (
                user_id, activity_type, activity_message, related_booking_id
            ) VALUES (?, 'booking_created', ?, ?)
        ");
        $activityMessage = "Created booking for {$requestedQuantity} {$input['unit']} of {$input['mango_type']} at {$timeSlot['factory_name']}";
        $activityStmt->execute([$user['id'], $activityMessage, $bookingId]);
        
        $pdo->commit();
        
        // Return booking details
        $responseData = [
            'booking_id' => $bookingId,
            'quality_report_id' => $qualityReportId,
            'status' => 'pending',
            'booking_details' => [
                'mango_type' => $input['mango_type'],
                'mango_variety' => $input['mango_variety'],
                'quantity' => $requestedQuantity,
                'unit' => $input['unit'],
                'factory_name' => $timeSlot['factory_name'],
                'factory_location' => $timeSlot['factory_location'],
                'booking_date' => $input['booking_date'],
                'slot_time' => $input['slot_time']
            ],
            'estimated_response_time' => '24-48 hours'
        ];
        
        http_response_code(201);
        echo json_encode([
            'status' => 'success',
            'message' => 'Booking submitted successfully',
            'data' => $responseData
        ]);
        
    } catch (Exception $e) {
        $pdo->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    error_log("Booking Submission API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>