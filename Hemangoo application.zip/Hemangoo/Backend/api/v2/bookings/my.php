<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        include_once '../../db.php';
        
        $user_id = $_GET['user_id'] ?? null;
        
        if (!$user_id) {
            throw new Exception('User ID is required');
        }
        
        // Get all bookings for the user with related information
        $stmt = $conn->prepare("
            SELECT 
                b.id as booking_id,
                b.user_id,
                u.full_name as farmer_name,
                u.email as farmer_email,
                u.mobile as farmer_mobile,
                f.name as factory_name,
                f.location as factory_location,
                b.mango_type,
                b.mango_variety,
                b.quantity,
                b.unit,
                b.booking_date,
                b.slot_time,
                b.status,
                b.created_at,
                b.updated_at,
                b.admin_notes,
                b.rejection_reason,
                COALESCE(qr.ripeness_level, 'Not Specified') as ripeness_level,
                COALESCE(qr.colour, 'Not Specified') as colour,
                COALESCE(qr.size, 'Not Specified') as size,
                COALESCE(qr.bruising_level, 'Not Specified') as bruising_level,
                COALESCE(qr.pest_presence, 0) as pest_presence,
                qr.additional_notes,
                qr.images
            FROM bookings b
            JOIN users u ON b.user_id = u.id
            JOIN factories f ON b.factory_id = f.id
            LEFT JOIN quality_reports qr ON b.quality_report_id = qr.id
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
        ");
        
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $bookings = [];
        while ($row = $result->fetch_assoc()) {
            $bookings[] = [
                'id' => $row['booking_id'],
                'farmer_id' => $row['user_id'],
                'farmer_name' => $row['farmer_name'],
                'farmer_email' => $row['farmer_email'],
                'farmer_mobile' => $row['farmer_mobile'],
                'factory_name' => $row['factory_name'],
                'factory_location' => $row['factory_location'],
                'mango_type' => $row['mango_type'],
                'mango_variety' => $row['mango_variety'],
                'quantity' => $row['quantity'],
                'unit' => $row['unit'],
                'booking_date' => $row['booking_date'],
                'slot_time' => $row['slot_time'],
                'status' => $row['status'],
                'created_at' => $row['created_at'],
                'updated_at' => $row['updated_at'],
                'admin_notes' => $row['admin_notes'],
                'rejection_reason' => $row['rejection_reason'],
                'quality_report' => [
                    'ripeness_level' => $row['ripeness_level'],
                    'colour' => $row['colour'],
                    'size' => $row['size'],
                    'bruising_level' => $row['bruising_level'],
                    'pest_presence' => (bool)$row['pest_presence'],
                    'additional_notes' => $row['additional_notes'],
                    'images' => $row['images'] ? json_decode($row['images'], true) : []
                ]
            ];
        }
        
        echo json_encode([
            'status' => 'success',
            'bookings' => $bookings,
            'total' => count($bookings)
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
?>