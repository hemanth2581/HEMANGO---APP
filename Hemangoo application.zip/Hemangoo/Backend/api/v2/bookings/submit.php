<?php
/**
 * Booking Submission API Endpoint - v2
 * Handles complete booking flow with quality report integration
 * Matches PRD requirements for booking creation
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../config/database.php';
require_once '../../config/security.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

try {
    // Authenticate user
    $user = authenticateRequest();
    if (!$user || $user['role'] !== 'farmer') {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
        exit;
    }
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    $requiredFields = [
        'mango_type', 'mango_variety', 'quantity', 'unit', 
        'factory_id', 'time_slot_id', 'booking_date', 'slot_time',
        'quality_report'
    ];
    
    foreach ($requiredFields as $field) {
        if (!isset($input[$field])) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => "Missing required field: $field"
            ]);
            exit;
        }
    }
    
    // Validate quality report fields
    $qualityReport = $input['quality_report'];
    $qualityRequiredFields = [
        'harvest_date', 'ripeness_level', 'color', 'size', 
        'bruising_level', 'pest_presence'
    ];
    
    foreach ($qualityRequiredFields as $field) {
        if (!isset($qualityReport[$field])) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => "Missing quality report field: $field"
            ]);
            exit;
        }
    }
    
    $pdo = getDatabaseConnection();
    $pdo->beginTransaction();
    
    try {
        // 1. Verify factory and time slot exist and are available
        $slotStmt = $pdo->prepare("
            SELECT fts.*, f.name as factory_name, f.location as factory_location
            FROM factory_time_slots fts
            JOIN factories f ON fts.factory_id = f.id
            WHERE fts.id = ? AND fts.factory_id = ? AND fts.is_available = TRUE
            AND fts.slot_date = ? AND fts.start_time = ?
        ");
        $slotStmt->execute([
            $input['time_slot_id'], 
            $input['factory_id'], 
            $input['booking_date'], 
            $input['slot_time']
        ]);
        $timeSlot = $slotStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$timeSlot) {
            throw new Exception('Selected time slot is not available');
        }
        
        // Check if slot has enough capacity
        $requestedQuantity = floatval($input['quantity']);\n        if (($timeSlot['current_bookings_tons'] + $requestedQuantity) > $timeSlot['max_capacity_tons']) {\n            throw new Exception('Insufficient capacity for requested quantity');\n        }\n        \n        // 2. Create quality report first\n        $qualityStmt = $pdo->prepare(\"\n            INSERT INTO quality_reports (\n                user_id, mango_type, mango_variety, estimated_quantity, unit,\n                harvest_date, ripeness_level, color, size, bruising_level,\n                pest_presence, additional_notes, images\n            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)\n        \");\n        \n        $qualityStmt->execute([\n            $user['id'],\n            $input['mango_type'],\n            $input['mango_variety'],\n            $requestedQuantity,\n            $input['unit'],\n            $qualityReport['harvest_date'],\n            $qualityReport['ripeness_level'],\n            $qualityReport['color'],\n            $qualityReport['size'],\n            $qualityReport['bruising_level'],\n            $qualityReport['pest_presence'] ? 1 : 0,\n            $qualityReport['notes'] ?? null,\n            isset($qualityReport['images']) ? json_encode($qualityReport['images']) : null\n        ]);\n        \n        $qualityReportId = $pdo->lastInsertId();\n        \n        // 3. Create booking\n        $bookingStmt = $pdo->prepare(\"\n            INSERT INTO bookings (\n                user_id, factory_id, time_slot_id, quality_report_id,\n                mango_type, mango_variety, quantity, unit,\n                booking_date, slot_time, status\n            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')\n        \");\n        \n        $bookingStmt->execute([\n            $user['id'],\n            $input['factory_id'],\n            $input['time_slot_id'],\n            $qualityReportId,\n            $input['mango_type'],\n            $input['mango_variety'],\n            $requestedQuantity,\n            $input['unit'],\n            $input['booking_date'],\n            $input['slot_time']\n        ]);\n        \n        $bookingId = $pdo->lastInsertId();\n        \n        // 4. Update time slot capacity\n        $updateSlotStmt = $pdo->prepare(\"\n            UPDATE factory_time_slots \n            SET current_bookings_tons = current_bookings_tons + ?\n            WHERE id = ?\n        \");\n        $updateSlotStmt->execute([$requestedQuantity, $input['time_slot_id']]);\n        \n        // 5. Log user activity\n        $activityStmt = $pdo->prepare(\"\n            INSERT INTO user_activities (\n                user_id, activity_type, activity_message, related_booking_id\n            ) VALUES (?, 'booking_created', ?, ?)\n        \");\n        $activityMessage = \"Created booking for {$requestedQuantity} {$input['unit']} of {$input['mango_type']} at {$timeSlot['factory_name']}\";\n        $activityStmt->execute([$user['id'], $activityMessage, $bookingId]);\n        \n        // 6. Create notification for admins\n        $adminStmt = $pdo->prepare(\"SELECT id FROM users WHERE role = 'admin' AND is_active = TRUE\");\n        $adminStmt->execute();\n        $admins = $adminStmt->fetchAll(PDO::FETCH_ASSOC);\n        \n        $notificationStmt = $pdo->prepare(\"\n            INSERT INTO notifications (\n                user_id, title, message, type, related_booking_id\n            ) VALUES (?, ?, ?, 'booking', ?)\n        \");\n        \n        foreach ($admins as $admin) {\n            $notificationMessage = \"New booking request from {$user['full_name']} for {$timeSlot['factory_name']}\";\n            $notificationStmt->execute([\n                $admin['id'],\n                'New Booking Request',\n                $notificationMessage,\n                $bookingId\n            ]);\n        }\n        \n        $pdo->commit();\n        \n        // Return booking details\n        $responseData = [\n            'booking_id' => $bookingId,\n            'quality_report_id' => $qualityReportId,\n            'status' => 'pending',\n            'booking_details' => [\n                'mango_type' => $input['mango_type'],\n                'mango_variety' => $input['mango_variety'],\n                'quantity' => $requestedQuantity,\n                'unit' => $input['unit'],\n                'factory_name' => $timeSlot['factory_name'],\n                'factory_location' => $timeSlot['factory_location'],\n                'booking_date' => $input['booking_date'],\n                'slot_time' => $input['slot_time']\n            ],\n            'estimated_response_time' => '24-48 hours'\n        ];\n        \n        http_response_code(201);\n        echo json_encode([\n            'status' => 'success',\n            'message' => 'Booking submitted successfully',\n            'data' => $responseData\n        ]);\n        \n    } catch (Exception $e) {\n        $pdo->rollback();\n        throw $e;\n    }\n    \n} catch (Exception $e) {\n    error_log(\"Booking Submission API Error: \" . $e->getMessage());\n    http_response_code(500);\n    echo json_encode([\n        'status' => 'error',\n        'message' => $e->getMessage()\n    ]);\n}\n?>"}, {"search_start_line_number": 48}]