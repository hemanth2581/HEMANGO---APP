<?php
/**
 * Farmer Dashboard API Endpoint - v2
 * Provides complete dashboard data as per PRD requirements
 * Includes market prices, booking stats, recent activities, and market updates
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once '../../config/database.php';
require_once '../../config/security.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

try {
    // Authenticate user
    $user = authenticateRequest();
    if (!$user || $user['role'] !== 'farmer') {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
        exit;
    }
    
    $pdo = getDatabaseConnection();
    $userId = $user['id'];
    
    // 1. Get current market prices for dashboard
    $stmt = $pdo->prepare("
        SELECT mango_type, mango_variety, price_per_kg, market_location, price_date
        FROM market_prices 
        WHERE price_date = CURDATE() 
        ORDER BY mango_type, price_per_kg DESC
        LIMIT 10
    ");
    $stmt->execute();
    $marketPrices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate average price for main display
    $avgPriceStmt = $pdo->prepare("
        SELECT AVG(price_per_kg) as avg_price
        FROM market_prices 
        WHERE price_date = CURDATE() AND mango_type = 'Alphonso'
    ");
    $avgPriceStmt->execute();
    $avgPrice = $avgPriceStmt->fetch(PDO::FETCH_ASSOC);
    
    // 2. Get booking statistics
    $bookingStatsStmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_bookings,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_bookings,
            SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_bookings,
            SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_bookings,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_bookings,
            SUM(CASE WHEN status IN ('confirmed', 'completed') THEN quantity ELSE 0 END) as total_quantity_processed
        FROM bookings 
        WHERE user_id = ?
    ");
    $bookingStatsStmt->execute([$userId]);
    $bookingStats = $bookingStatsStmt->fetch(PDO::FETCH_ASSOC);
    
    // 3. Get recent activities (last 10)
    $activitiesStmt = $pdo->prepare("
        SELECT activity_type, activity_message, created_at
        FROM user_activities 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $activitiesStmt->execute([$userId]);
    $recentActivities = $activitiesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 4. Get latest market updates
    $marketUpdatesStmt = $pdo->prepare("
        SELECT title, content, category, priority, created_at
        FROM market_updates 
        WHERE target_audience IN ('farmers', 'all') AND is_active = TRUE
        ORDER BY priority DESC, created_at DESC 
        LIMIT 5
    ");
    $marketUpdatesStmt->execute();
    $marketUpdates = $marketUpdatesStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 5. Get recent bookings for quick view
    $recentBookingsStmt = $pdo->prepare("
        SELECT b.id, b.mango_type, b.mango_variety, b.quantity, b.unit, 
               b.booking_date, b.slot_time, b.status, f.name as factory_name
        FROM bookings b
        JOIN factories f ON b.factory_id = f.id
        WHERE b.user_id = ?
        ORDER BY b.created_at DESC
        LIMIT 5
    ");
    $recentBookingsStmt->execute([$userId]);
    $recentBookings = $recentBookingsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 6. Get notifications count
    $notificationsStmt = $pdo->prepare("
        SELECT COUNT(*) as unread_notifications
        FROM notifications 
        WHERE user_id = ? AND is_read = FALSE
    ");
    $notificationsStmt->execute([$userId]);
    $notificationCount = $notificationsStmt->fetch(PDO::FETCH_ASSOC);
    
    // Prepare dashboard data
    $dashboardData = [
        'user_info' => [
            'name' => $user['full_name'],
            'location' => $user['location'],
            'email' => $user['email'],
            'phone' => $user['phone']
        ],
        'market_data' => [
            'current_average_price' => number_format($avgPrice['avg_price'] ?? 0, 2),
            'price_currency' => 'INR',
            'price_unit' => 'per kg',
            'last_updated' => date('Y-m-d'),
            'detailed_prices' => $marketPrices
        ],
        'booking_stats' => [
            'total_bookings' => intval($bookingStats['total_bookings']),
            'pending_bookings' => intval($bookingStats['pending_bookings']),
            'confirmed_bookings' => intval($bookingStats['confirmed_bookings']),
            'rejected_bookings' => intval($bookingStats['rejected_bookings']),
            'completed_bookings' => intval($bookingStats['completed_bookings']),
            'total_quantity_processed' => number_format($bookingStats['total_quantity_processed'], 2)
        ],
        'recent_activities' => array_map(function($activity) {
            return [
                'type' => $activity['activity_type'],
                'message' => $activity['activity_message'],
                'time' => date('M d, Y H:i', strtotime($activity['created_at'])),
                'timestamp' => $activity['created_at']
            ];
        }, $recentActivities),
        'market_updates' => array_map(function($update) {
            return [
                'title' => $update['title'],
                'content' => $update['content'],
                'category' => $update['category'],
                'priority' => $update['priority'],
                'date' => date('M d, Y', strtotime($update['created_at']))
            ];
        }, $marketUpdates),
        'recent_bookings' => array_map(function($booking) {
            return [
                'id' => $booking['id'],
                'mango_type' => $booking['mango_type'],
                'variety' => $booking['mango_variety'],
                'quantity' => $booking['quantity'] . ' ' . $booking['unit'],
                'factory' => $booking['factory_name'],
                'date' => $booking['booking_date'],
                'time' => $booking['slot_time'],
                'status' => $booking['status']
            ];
        }, $recentBookings),
        'notifications' => [
            'unread_count' => intval($notificationCount['unread_notifications'])
        ],
        'quick_actions' => [
            'can_create_booking' => true,
            'can_view_bookings' => true,
            'can_submit_quality_report' => true
        ]
    ];
    
    http_response_code(200);
    echo json_encode([
        'status' => 'success',
        'message' => 'Dashboard data retrieved successfully',
        'data' => $dashboardData
    ]);
    
} catch (Exception $e) {
    error_log("Farmer Dashboard API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Internal server error'
    ]);
}
?>