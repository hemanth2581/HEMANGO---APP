<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        include_once '../../db.php';
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            throw new Exception('Invalid JSON input');
        }
        
        $user_id = $input['user_id'] ?? null;
        $factory_id = $input['factory_id'] ?? null;
        $slot_id = $input['slot_id'] ?? null;
        $mango_type = $input['mango_type'] ?? null;
        $mango_variety = $input['mango_variety'] ?? null;
        $quantity = $input['quantity'] ?? null;
        $unit = $input['unit'] ?? 'kg';
        $quality_report_id = $input['quality_report_id'] ?? null;
        
        // Validation
        if (!$user_id || !$factory_id || !$slot_id || !$mango_type || !$mango_variety || !$quantity) {
            throw new Exception('Missing required fields: user_id, factory_id, slot_id, mango_type, mango_variety, quantity');
        }
        
        // Validate quantity is positive
        if ($quantity <= 0) {
            throw new Exception('Quantity must be greater than 0');
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Check if slot is still available
            $slotStmt = $conn->prepare("
                SELECT id, max_capacity_kg, current_bookings_kg, slot_date, start_time, end_time, factory_id
                FROM factory_time_slots 
                WHERE id = ? AND factory_id = ? AND is_available = 1
                FOR UPDATE
            ");
            $slotStmt->bind_param("ii", $slot_id, $factory_id);
            $slotStmt->execute();
            $slotResult = $slotStmt->get_result();
            
            if ($slotResult->num_rows === 0) {
                throw new Exception('Slot not found or not available');
            }
            
            $slot = $slotResult->fetch_assoc();
            $available_capacity = $slot['max_capacity_kg'] - $slot['current_bookings_kg'];
            
            if ($available_capacity < $quantity) {
                throw new Exception('Insufficient capacity in selected slot. Available: ' . $available_capacity . 'kg, Requested: ' . $quantity . 'kg');
            }
            
            // Update slot capacity
            $updateSlotStmt = $conn->prepare("
                UPDATE factory_time_slots 
                SET current_bookings_kg = current_bookings_kg + ? 
                WHERE id = ?
            ");
            $updateSlotStmt->bind_param("di", $quantity, $slot_id);
            if (!$updateSlotStmt->execute()) {
                throw new Exception('Failed to update slot capacity');
            }
            
            // Create booking
            $bookingStmt = $conn->prepare("
                INSERT INTO bookings (
                    user_id, factory_id, time_slot_id, quality_report_id,
                    mango_type, mango_variety, quantity, unit,
                    booking_date, slot_time, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
            ");
            
            $slot_time = $slot['start_time'] . ' - ' . $slot['end_time'];
            $bookingStmt->bind_param(
                "iiissssds", 
                $user_id, $factory_id, $slot_id, $quality_report_id,
                $mango_type, $mango_variety, $quantity, $unit,
                $slot['slot_date'], $slot_time
            );
            
            if (!$bookingStmt->execute()) {
                throw new Exception('Failed to create booking: ' . $conn->error);
            }
            
            $booking_id = $conn->insert_id;
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => 'Slot booked successfully',
                'booking_id' => $booking_id,
                'slot_info' => [
                    'date' => $slot['slot_date'],
                    'time' => $slot_time,
                    'available_capacity' => $available_capacity - $quantity,
                    'factory_id' => $factory_id
                ]
            ]);
            
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
?>
