<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        include_once '../../db.php';
        
        $factory_id = $_GET['factory_id'] ?? null;
        $date = $_GET['date'] ?? date('Y-m-d');
        
        if (!$factory_id) {
            throw new Exception('Factory ID is required');
        }
        
        // Get available time slots for the specified factory and date
        $stmt = $conn->prepare("
            SELECT 
                fts.id,
                fts.factory_id,
                fts.slot_date,
                fts.start_time,
                fts.end_time,
                fts.max_capacity_kg,
                fts.current_bookings_kg,
                (fts.max_capacity_kg - fts.current_bookings_kg) as available_capacity_kg,
                fts.price_per_kg,
                fts.is_available,
                f.name as factory_name,
                f.location as factory_location
            FROM factory_time_slots fts
            JOIN factories f ON fts.factory_id = f.id
            WHERE fts.factory_id = ? 
            AND fts.slot_date = ? 
            AND fts.is_available = 1
            AND (fts.max_capacity_kg - fts.current_bookings_kg) > 0
            ORDER BY fts.start_time
        ");
        
        $stmt->bind_param("is", $factory_id, $date);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $slots = [];
        while ($row = $result->fetch_assoc()) {
            $slots[] = [
                'id' => $row['id'],
                'factory_id' => $row['factory_id'],
                'factory_name' => $row['factory_name'],
                'factory_location' => $row['factory_location'],
                'date' => $row['slot_date'],
                'time' => $row['start_time'] . ' - ' . $row['end_time'],
                'start_time' => $row['start_time'],
                'end_time' => $row['end_time'],
                'available_spots' => max(0, floor($row['available_capacity_kg'] / 100)), // Assuming 100kg per spot
                'max_capacity' => floor($row['max_capacity_kg'] / 100),
                'available_capacity_kg' => $row['available_capacity_kg'],
                'max_capacity_kg' => $row['max_capacity_kg'],
                'price_per_kg' => $row['price_per_kg'],
                'is_available' => (bool)$row['is_available']
            ];
        }
        
        echo json_encode([
            'status' => 'success',
            'slots' => $slots,
            'factory_id' => $factory_id,
            'date' => $date
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
?>
