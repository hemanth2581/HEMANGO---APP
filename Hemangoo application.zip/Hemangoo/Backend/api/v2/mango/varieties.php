<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        include_once '../../db.php';
        
        // Get all active mango varieties
        $stmt = $conn->prepare("
            SELECT 
                id,
                name,
                type,
                season_start,
                season_end,
                description,
                base_price_per_kg,
                is_active,
                created_at
            FROM mango_varieties 
            WHERE is_active = 1
            ORDER BY name
        ");
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $varieties = [];
        while ($row = $result->fetch_assoc()) {
            $varieties[] = [
                'id' => $row['id'],
                'name' => $row['name'],
                'type' => $row['type'],
                'season_start' => $row['season_start'],
                'season_end' => $row['season_end'],
                'description' => $row['description'],
                'base_price_per_kg' => $row['base_price_per_kg'],
                'is_active' => (bool)$row['is_active'],
                'created_at' => $row['created_at']
            ];
        }
        
        echo json_encode([
            'status' => 'success',
            'varieties' => $varieties,
            'total' => count($varieties)
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
?>
