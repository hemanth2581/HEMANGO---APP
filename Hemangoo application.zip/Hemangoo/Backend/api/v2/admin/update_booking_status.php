<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        include_once '../../db.php';
        
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            throw new Exception('Invalid JSON input');
        }
        
        $booking_id = $input['booking_id'] ?? null;
        $action = $input['action'] ?? null; // 'approve' or 'reject'
        $admin_notes = $input['admin_notes'] ?? '';
        $rejection_reason = $input['rejection_reason'] ?? '';
        $admin_id = $input['admin_id'] ?? 1; // Default admin ID
        
        // Validation
        if (!$booking_id || !$action) {
            throw new Exception('Missing required fields');
        }
        
        if (!in_array($action, ['approve', 'reject'])) {
            throw new Exception('Invalid action. Must be approve or reject');
        }
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Check if booking exists and is pending
            $checkStmt = $conn->prepare("
                SELECT id, status, time_slot_id, quantity 
                FROM bookings 
                WHERE id = ? AND status = 'pending'
                FOR UPDATE
            ");
            $checkStmt->bind_param("i", $booking_id);
            $checkStmt->execute();
            $result = $checkStmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception('Booking not found or already processed');
            }
            
            $booking = $result->fetch_assoc();
            
            // Update booking status
            $new_status = $action === 'approve' ? 'confirmed' : 'rejected';
            $updateStmt = $conn->prepare("
                UPDATE bookings 
                SET status = ?, 
                    reviewed_by = ?, 
                    reviewed_at = NOW(),
                    admin_notes = ?,
                    rejection_reason = ?
                WHERE id = ?
            ");
            $updateStmt->bind_param("sissi", $new_status, $admin_id, $admin_notes, $rejection_reason, $booking_id);
            $updateStmt->execute();
            
            // If rejected, free up the slot capacity
            if ($action === 'reject') {
                $freeSlotStmt = $conn->prepare("
                    UPDATE factory_time_slots 
                    SET current_bookings_kg = current_bookings_kg - ? 
                    WHERE id = ?
                ");
                $freeSlotStmt->bind_param("di", $booking['quantity'], $booking['time_slot_id']);
                if (!$freeSlotStmt->execute()) {
                    throw new Exception('Failed to free up slot capacity');
                }
            }
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => "Booking {$action}d successfully",
                'booking_id' => $booking_id,
                'new_status' => $new_status
            ]);
            
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
        
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode([
        'status' => 'error',
        'message' => 'Method not allowed'
    ]);
}
?>
