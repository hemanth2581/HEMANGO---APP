<?php
/**
 * Login API Endpoint - v2
 * Handles user authentication for farmers and admins
 * Matches PRD requirements for secure authentication
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../../config/database.php';
require_once '../../config/security.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($input['email']) || !isset($input['password']) || !isset($input['role'])) {
        http_response_code(400);
        echo json_encode([
            'status' => 'error',
            'message' => 'Missing required fields: email, password, role'
        ]);
        exit;
    }
    
    $email = filter_var($input['email'], FILTER_VALIDATE_EMAIL);
    $password = $input['password'];
    $role = $input['role'];
    
    // Validate inputs
    if (!$email) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid email format']);
        exit;
    }
    
    if (!in_array($role, ['farmer', 'admin'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid role. Must be farmer or admin']);
        exit;
    }
    
    // Connect to database
    $pdo = getDatabaseConnection();
    
    // Check user credentials
    $stmt = $pdo->prepare("
        SELECT id, full_name, email, phone, password_hash, role, location, is_active 
        FROM users 
        WHERE email = ? AND role = ? AND is_active = TRUE
    ");
    $stmt->execute([$email, $role]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
        exit;
    }
    
    // Verify password
    if (!password_verify($password, $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
        exit;
    }
    
    // Generate session token
    $token = generateSecureToken();
    $expires_at = date('Y-m-d H:i:s', strtotime('+30 days'));
    
    // Store session
    $stmt = $pdo->prepare("
        INSERT INTO user_sessions (user_id, token, device_info, expires_at) 
        VALUES (?, ?, ?, ?)
    ");
    $device_info = json_encode([
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
        'login_time' => date('Y-m-d H:i:s')
    ]);
    $stmt->execute([$user['id'], $token, $device_info, $expires_at]);
    
    // Clean expired sessions
    $pdo->prepare("DELETE FROM user_sessions WHERE expires_at < NOW()")->execute();
    
    // Log user activity
    $stmt = $pdo->prepare("
        INSERT INTO user_activities (user_id, activity_type, activity_message) 
        VALUES (?, 'login', ?)
    ");
    $stmt->execute([$user['id'], "User logged in from " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown')]);
    
    // Prepare response
    unset($user['password_hash']); // Remove sensitive data
    $user['token'] = $token;
    
    http_response_code(200);
    echo json_encode([
        'status' => 'success',
        'message' => 'Login successful',
        'data' => $user
    ]);
    
} catch (Exception $e) {
    error_log("Login API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Internal server error'
    ]);
}
?>