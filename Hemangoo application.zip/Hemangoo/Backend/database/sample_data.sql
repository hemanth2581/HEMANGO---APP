-- Sample data for testing the admin panel
USE hemangoo_db;

-- Insert sample users
INSERT INTO users (full_name, email, phone, password_hash, role, location, is_active) VALUES
('Admin User', 'admin@hemango.com', '+1234567890', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Mumbai', TRUE),
('Farmer John', 'farmer@hemango.com', '+1234567891', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer', 'Pune', TRUE),
('Farmer Rajesh', 'rajesh@hemango.com', '+1234567892', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer', 'Nashik', TRUE),
('Farmer Amit', 'amit@hemango.com', '+1234567893', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer', 'Aurangabad', TRUE);

-- Insert sample factories
INSERT INTO factories (name, location, address, contact_phone, contact_email, capacity_tons_per_day, operating_hours, is_active) VALUES
('Mango Processing Plant A', 'Mumbai', '123 Industrial Area, Mumbai', '+91-9876543210', 'plantA@hemango.com', 10.0, '9:00 AM - 6:00 PM', TRUE),
('Mango Processing Plant B', 'Pune', '456 Agricultural Zone, Pune', '+91-9876543211', 'plantB@hemango.com', 8.0, '8:00 AM - 5:00 PM', TRUE),
('Mango Processing Plant C', 'Nashik', '789 Farm District, Nashik', '+91-9876543212', 'plantC@hemango.com', 12.0, '7:00 AM - 7:00 PM', TRUE);

-- Insert sample mango varieties
INSERT INTO mango_varieties (type, variety, season_start, season_end, description, min_price_per_kg, max_price_per_kg, is_active) VALUES
('Alphonso', 'Premium', '2024-03-01', '2024-06-30', 'Premium quality Alphonso mango', 120.00, 200.00, TRUE),
('Alphonso', 'Grade A', '2024-03-01', '2024-06-30', 'Grade A Alphonso mango', 100.00, 150.00, TRUE),
('Kesar', 'Premium', '2024-04-01', '2024-07-31', 'Premium quality Kesar mango', 110.00, 180.00, TRUE),
('Dasheri', 'Grade A', '2024-05-01', '2024-08-31', 'Grade A Dasheri mango', 90.00, 140.00, TRUE);

-- Insert sample time slots
INSERT INTO factory_time_slots (factory_id, date, start_time, end_time, max_capacity_kg, current_bookings_kg, is_available) VALUES
(1, '2024-12-20', '09:00:00', '10:00:00', 1000.0, 0.0, TRUE),
(1, '2024-12-20', '10:00:00', '11:00:00', 1000.0, 0.0, TRUE),
(1, '2024-12-20', '11:00:00', '12:00:00', 1000.0, 0.0, TRUE),
(1, '2024-12-21', '09:00:00', '10:00:00', 1000.0, 0.0, TRUE),
(1, '2024-12-21', '10:00:00', '11:00:00', 1000.0, 0.0, TRUE),
(2, '2024-12-20', '09:00:00', '10:00:00', 800.0, 0.0, TRUE),
(2, '2024-12-20', '10:00:00', '11:00:00', 800.0, 0.0, TRUE),
(3, '2024-12-20', '09:00:00', '10:00:00', 1200.0, 0.0, TRUE);

-- Insert sample quality reports
INSERT INTO quality_reports (farmer_id, ripeness_level, colour, size, bruising_level, pest_presence, harvest_date, additional_notes, images, created_at) VALUES
(2, 'Fully Ripe', 'Golden', 'Large', 'None', FALSE, '2024-12-18', 'Excellent quality mangoes', '[]', NOW()),
(3, 'Partially Ripe', 'Yellow', 'Medium', 'Light', FALSE, '2024-12-17', 'Good quality with minor bruising', '[]', NOW()),
(4, 'Fully Ripe', 'Golden', 'Large', 'None', FALSE, '2024-12-19', 'Premium quality harvest', '[]', NOW());

-- Insert sample bookings
INSERT INTO bookings (user_id, factory_id, time_slot_id, mango_type, mango_variety, quantity, unit, booking_date, slot_time, status, quality_report_id, created_at) VALUES
(2, 1, 1, 'Alphonso', 'Premium', 500.0, 'kg', '2024-12-20', '9:00 AM - 10:00 AM', 'pending', 1, NOW()),
(3, 2, 6, 'Kesar', 'Premium', 300.0, 'kg', '2024-12-20', '9:00 AM - 10:00 AM', 'pending', 2, NOW()),
(4, 1, 2, 'Alphonso', 'Grade A', 750.0, 'kg', '2024-12-20', '10:00 AM - 11:00 AM', 'pending', 3, NOW()),
(2, 3, 8, 'Dasheri', 'Grade A', 400.0, 'kg', '2024-12-20', '9:00 AM - 10:00 AM', 'confirmed', 1, NOW()),
(3, 1, 3, 'Kesar', 'Premium', 200.0, 'kg', '2024-12-20', '11:00 AM - 12:00 PM', 'rejected', 2, NOW());

-- Update time slot capacity for confirmed bookings
UPDATE factory_time_slots SET current_bookings_kg = 400.0 WHERE id = 8;

