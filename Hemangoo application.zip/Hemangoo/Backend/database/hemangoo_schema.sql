-- Hemangoo Database Schema
-- Supports complete PRD requirements including booking flow, quality reports, market data, and user management
-- Created: September 2025

CREATE DATABASE IF NOT EXISTS hemangoo_db;
USE hemangoo_db;

-- Users table (farmers and admins)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('farmer', 'admin') NOT NULL,
    location VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE
);

-- Factories/Processing Plants table
CREATE TABLE factories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    address TEXT,
    contact_phone VARCHAR(20),
    contact_email VARCHAR(100),
    capacity_tons_per_day DECIMAL(10,2),
    operating_hours VARCHAR(50),
    facilities TEXT, -- JSON string of available facilities
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Mango varieties master data
CREATE TABLE mango_varieties (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type VARCHAR(50) NOT NULL, -- Alphonso, Dasheri, Langra
    variety VARCHAR(50) NOT NULL, -- Premium, Grade A, Regular
    season_start DATE,
    season_end DATE,
    description TEXT,
    min_price_per_kg DECIMAL(8,2),
    max_price_per_kg DECIMAL(8,2),
    is_active BOOLEAN DEFAULT TRUE
);

-- Time slots for factories
CREATE TABLE factory_time_slots (
    id INT PRIMARY KEY AUTO_INCREMENT,
    factory_id INT NOT NULL,
    slot_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    max_capacity_tons DECIMAL(8,2) NOT NULL,
    current_bookings_tons DECIMAL(8,2) DEFAULT 0,
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (factory_id) REFERENCES factories(id) ON DELETE CASCADE,
    UNIQUE KEY unique_slot (factory_id, slot_date, start_time)
);

-- Quality reports table
CREATE TABLE quality_reports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    mango_type VARCHAR(50) NOT NULL,
    mango_variety VARCHAR(50) NOT NULL,
    estimated_quantity DECIMAL(8,2) NOT NULL,
    unit VARCHAR(10) DEFAULT 'kg',
    harvest_date DATE NOT NULL,
    ripeness_level ENUM('Unripe', 'Partially Ripe', 'Fully Ripe') NOT NULL,
    color ENUM('Greenish', 'Yellow', 'Golden', 'Mixed') NOT NULL,
    size ENUM('Small', 'Medium', 'Large') NOT NULL,
    bruising_level ENUM('None', 'Light', 'Moderate', 'Heavy') NOT NULL,
    pest_presence BOOLEAN NOT NULL,
    additional_notes TEXT,
    images JSON, -- Array of image URLs/paths
    admin_review_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    admin_notes TEXT,
    reviewed_by INT,
    reviewed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Main bookings table
CREATE TABLE bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    factory_id INT NOT NULL,
    time_slot_id INT NOT NULL,
    quality_report_id INT,
    
    -- Mango details
    mango_type VARCHAR(50) NOT NULL,
    mango_variety VARCHAR(50) NOT NULL,
    quantity DECIMAL(8,2) NOT NULL,
    unit VARCHAR(10) DEFAULT 'kg',
    
    -- Booking details
    booking_date DATE NOT NULL,
    slot_time TIME NOT NULL,
    status ENUM('pending', 'confirmed', 'rejected', 'completed', 'cancelled') DEFAULT 'pending',
    
    -- Admin review
    reviewed_by INT,
    reviewed_at TIMESTAMP NULL,
    admin_notes TEXT,
    rejection_reason TEXT,
    alternative_slots JSON, -- Array of alternative slot suggestions
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (factory_id) REFERENCES factories(id) ON DELETE CASCADE,
    FOREIGN KEY (time_slot_id) REFERENCES factory_time_slots(id) ON DELETE CASCADE,
    FOREIGN KEY (quality_report_id) REFERENCES quality_reports(id) ON DELETE SET NULL,
    FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Market price data
CREATE TABLE market_prices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    mango_type VARCHAR(50) NOT NULL,
    mango_variety VARCHAR(50),
    price_per_kg DECIMAL(8,2) NOT NULL,
    market_location VARCHAR(100),
    price_date DATE NOT NULL,
    source VARCHAR(50), -- wholesale, retail, factory
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Recent activities for farmer dashboard
CREATE TABLE user_activities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    activity_type ENUM('booking_created', 'booking_confirmed', 'booking_rejected', 'quality_report_submitted', 'quality_report_reviewed') NOT NULL,
    activity_message TEXT NOT NULL,
    related_booking_id INT,
    related_quality_report_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (related_booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (related_quality_report_id) REFERENCES quality_reports(id) ON DELETE CASCADE
);

-- Market updates/news
CREATE TABLE market_updates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    category ENUM('price', 'weather', 'demand', 'government', 'general') DEFAULT 'general',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    target_audience ENUM('farmers', 'admins', 'all') DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- System notifications
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('booking', 'quality', 'market', 'system') DEFAULT 'system',
    is_read BOOLEAN DEFAULT FALSE,
    related_booking_id INT,
    related_quality_report_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (related_booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (related_quality_report_id) REFERENCES quality_reports(id) ON DELETE CASCADE
);

-- Session management for mobile app
CREATE TABLE user_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(255) NOT NULL UNIQUE,
    device_info TEXT,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample data

-- Sample mango varieties
INSERT INTO mango_varieties (type, variety, season_start, season_end, description, min_price_per_kg, max_price_per_kg) VALUES
('Alphonso', 'Premium', '2024-04-01', '2024-06-30', 'Premium quality Alphonso mangoes', 150.00, 200.00),
('Alphonso', 'Grade A', '2024-04-01', '2024-06-30', 'Grade A Alphonso mangoes', 100.00, 149.99),
('Alphonso', 'Regular', '2024-04-01', '2024-06-30', 'Regular Alphonso mangoes', 80.00, 99.99),
('Dasheri', 'Premium', '2024-05-15', '2024-07-15', 'Premium quality Dasheri mangoes', 120.00, 150.00),
('Dasheri', 'Regular', '2024-05-15', '2024-07-15', 'Regular Dasheri mangoes', 70.00, 119.99),
('Langra', 'Premium', '2024-06-01', '2024-08-31', 'Premium quality Langra mangoes', 100.00, 130.00),
('Langra', 'Regular', '2024-06-01', '2024-08-31', 'Regular Langra mangoes', 60.00, 99.99);

-- Sample factories
INSERT INTO factories (name, location, address, contact_phone, contact_email, capacity_tons_per_day, operating_hours) VALUES
('Green Valley Processing Plant', 'Mumbai', '123 Industrial Area, Mumbai - 400001', '+91-9876543210', 'contact@greenvalley.com', 50.00, '8:00 AM - 6:00 PM'),
('Fresh Farm Industries', 'Pune', '456 Export Zone, Pune - 411001', '+91-9876543211', 'info@freshfarm.com', 75.00, '7:00 AM - 7:00 PM'),
('Organic Foods Co.', 'Nashik', '789 Agro Park, Nashik - 422001', '+91-9876543212', 'support@organicfoods.co.in', 30.00, '9:00 AM - 5:00 PM'),
('Premium Fruit Processing', 'Ratnagiri', '321 Coastal Road, Ratnagiri - 415612', '+91-9876543213', 'orders@premiumfruit.com', 60.00, '8:00 AM - 6:00 PM');

-- Sample current market prices
INSERT INTO market_prices (mango_type, mango_variety, price_per_kg, market_location, price_date, source) VALUES
('Alphonso', 'Premium', 175.00, 'Mumbai', CURDATE(), 'wholesale'),
('Alphonso', 'Grade A', 125.00, 'Mumbai', CURDATE(), 'wholesale'),
('Alphonso', 'Regular', 90.00, 'Mumbai', CURDATE(), 'wholesale'),
('Dasheri', 'Premium', 135.00, 'Delhi', CURDATE(), 'wholesale'),
('Dasheri', 'Regular', 95.00, 'Delhi', CURDATE(), 'wholesale'),
('Langra', 'Premium', 115.00, 'Delhi', CURDATE(), 'wholesale'),
('Langra', 'Regular', 80.00, 'Delhi', CURDATE(), 'wholesale');

-- Sample market updates
INSERT INTO market_updates (title, content, category, priority, target_audience, created_by) VALUES
('Mango Prices Rise Due to High Demand', 'The price of premium Alphonso mangoes has increased by 15% this week due to increased export demand from international markets.', 'price', 'high', 'farmers', NULL),
('Weather Alert: Heavy Rains Expected', 'Meteorological department has issued heavy rain warning for Maharashtra region. Farmers are advised to take necessary precautions.', 'weather', 'high', 'farmers', NULL),
('New Export Opportunities Available', 'Government has opened new export channels to European markets. Contact your nearest agricultural officer for more details.', 'government', 'medium', 'farmers', NULL);

-- Create indexes for better performance
CREATE INDEX idx_bookings_user_id ON bookings(user_id);
CREATE INDEX idx_bookings_factory_id ON bookings(factory_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_date ON bookings(booking_date);
CREATE INDEX idx_quality_reports_user_id ON quality_reports(user_id);
CREATE INDEX idx_time_slots_factory_date ON factory_time_slots(factory_id, slot_date);
CREATE INDEX idx_market_prices_date ON market_prices(price_date);
CREATE INDEX idx_user_activities_user_id ON user_activities(user_id);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);

-- Add some sample time slots for factories (next 30 days)
DELIMITER //
CREATE PROCEDURE GenerateTimeSlots()
BEGIN
    DECLARE factory_id INT DEFAULT 1;
    DECLARE slot_date DATE DEFAULT CURDATE();
    DECLARE end_date DATE DEFAULT DATE_ADD(CURDATE(), INTERVAL 30 DAY);
    
    WHILE factory_id <= 4 DO
        SET slot_date = CURDATE();
        WHILE slot_date <= end_date DO
            -- Morning slot 9:00-12:00
            INSERT INTO factory_time_slots (factory_id, slot_date, start_time, end_time, max_capacity_tons)
            VALUES (factory_id, slot_date, '09:00:00', '12:00:00', 15.00);
            
            -- Afternoon slot 14:00-17:00
            INSERT INTO factory_time_slots (factory_id, slot_date, start_time, end_time, max_capacity_tons)
            VALUES (factory_id, slot_date, '14:00:00', '17:00:00', 15.00);
            
            SET slot_date = DATE_ADD(slot_date, INTERVAL 1 DAY);
        END WHILE;
        SET factory_id = factory_id + 1;
    END WHILE;
END //
DELIMITER ;

CALL GenerateTimeSlots();
DROP PROCEDURE GenerateTimeSlots;

-- Create admin user (password: admin123 - should be hashed in production)
INSERT INTO users (full_name, email, phone, password_hash, role, location, email_verified) VALUES
('System Administrator', 'admin@hemangoo.com', '+91-9999999999', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Mumbai', TRUE);

-- Create sample farmer user (password: farmer123 - should be hashed in production)
INSERT INTO users (full_name, email, phone, password_hash, role, location, email_verified) VALUES
('Rajesh Sharma', 'farmer@example.com', '+91-9876543214', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'farmer', 'Ratnagiri', TRUE);