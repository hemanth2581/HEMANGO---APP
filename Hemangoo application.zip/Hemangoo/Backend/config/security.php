<?php
/**
 * Security Configuration
 * JWT token management and security utilities
 */

class Security {
    private static $jwt_secret = 'hemango_app_secret_key_2024_secure';
    private static $jwt_algorithm = 'HS256';
    private static $token_expiry = 86400; // 24 hours
    
    public static function generateJWT($user_id, $email, $role) {
        $header = json_encode(['typ' => 'JWT', 'alg' => self::$jwt_algorithm]);
        $payload = json_encode([
            'user_id' => $user_id,
            'email' => $email,
            'role' => $role,
            'iat' => time(),
            'exp' => time() + self::$token_expiry
        ]);
        
        $header_encoded = self::base64UrlEncode($header);
        $payload_encoded = self::base64UrlEncode($payload);
        
        $signature = hash_hmac('sha256', $header_encoded . "." . $payload_encoded, self::$jwt_secret, true);
        $signature_encoded = self::base64UrlEncode($signature);
        
        return $header_encoded . "." . $payload_encoded . "." . $signature_encoded;
    }
    
    public static function validateJWT($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return false;
        }
        
        list($header_encoded, $payload_encoded, $signature_encoded) = $parts;
        
        $signature = hash_hmac('sha256', $header_encoded . "." . $payload_encoded, self::$jwt_secret, true);
        $signature_check = self::base64UrlEncode($signature);
        
        if (!hash_equals($signature_check, $signature_encoded)) {
            return false;
        }
        
        $payload = json_decode(self::base64UrlDecode($payload_encoded), true);
        
        if ($payload['exp'] < time()) {
            return false;
        }
        
        return $payload;
    }
    
    public static function hashPassword($password) {
        return password_hash($password, PASSWORD_ARGON2ID, [
            'memory_cost' => 65536,
            'time_cost' => 4,
            'threads' => 3
        ]);
    }
    
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }
    
    public static function sanitizeInput($input) {
        return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
    }
    
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    public static function validatePhone($phone) {
        return preg_match('/^[+]?[0-9]{10,15}$/', $phone);
    }
    
    private static function base64UrlEncode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    private static function base64UrlDecode($data) {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }
}
?>
