<?php
/**
 * Security Configuration
 * Provides authentication and security functions
 */

/**
 * Generate secure random token
 * @param int $length Token length
 * @return string Secure token
 */
function generateSecureToken($length = 64) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Hash password securely
 * @param string $password Plain text password
 * @return string Hashed password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_ARGON2ID);
}

/**
 * Verify password
 * @param string $password Plain text password
 * @param string $hash Stored hash
 * @return bool Verification result
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Authenticate API request using token
 * @return array|null User data or null if authentication fails
 */
function authenticateRequest() {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? null;
    
    if (!$authHeader) {
        return null;
    }
    
    // Extract token from "Bearer {token}" format
    if (preg_match('/Bearer\s+(.+)/', $authHeader, $matches)) {
        $token = $matches[1];
    } else {
        return null;
    }
    
    try {
        $pdo = getDatabaseConnection();
        
        // Find active session with user data
        $stmt = $pdo->prepare("
            SELECT u.id, u.full_name, u.email, u.phone, u.role, u.location, u.is_active
            FROM user_sessions s
            JOIN users u ON s.user_id = u.id
            WHERE s.token = ? AND s.expires_at > NOW() AND u.is_active = TRUE
        ");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Update last activity
            $updateStmt = $pdo->prepare("UPDATE user_sessions SET last_activity = NOW() WHERE token = ?");
            $updateStmt->execute([$token]);
            
            return $user;
        }
        
        return null;
        
    } catch (Exception $e) {
        error_log("Authentication error: " . $e->getMessage());
        return null;
    }
}

/**
 * Validate input data
 * @param array $data Input data
 * @param array $rules Validation rules
 * @return array Validation errors
 */
function validateInput($data, $rules) {
    $errors = [];
    
    foreach ($rules as $field => $rule) {
        $value = $data[$field] ?? null;
        
        // Required check
        if (isset($rule['required']) && $rule['required'] && empty($value)) {
            $errors[$field][] = "Field is required";
            continue;
        }
        
        // Skip further validation if field is empty and not required
        if (empty($value)) {
            continue;
        }
        
        // Type validation
        if (isset($rule['type'])) {
            switch ($rule['type']) {
                case 'email':
                    if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                        $errors[$field][] = "Invalid email format";
                    }
                    break;
                case 'numeric':
                    if (!is_numeric($value)) {
                        $errors[$field][] = "Must be numeric";
                    }
                    break;
                case 'phone':
                    if (!preg_match('/^\+?[1-9]\d{1,14}$/', $value)) {
                        $errors[$field][] = "Invalid phone number format";
                    }
                    break;
            }
        }
        
        // Length validation
        if (isset($rule['min_length']) && strlen($value) < $rule['min_length']) {
            $errors[$field][] = "Minimum length is {$rule['min_length']}";
        }
        
        if (isset($rule['max_length']) && strlen($value) > $rule['max_length']) {
            $errors[$field][] = "Maximum length is {$rule['max_length']}";
        }
        
        // Options validation (enum-like)
        if (isset($rule['options']) && !in_array($value, $rule['options'])) {
            $errors[$field][] = "Invalid option selected";
        }
    }
    
    return $errors;
}

/**
 * Sanitize input data
 * @param mixed $data Input data
 * @return mixed Sanitized data
 */
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    
    if (is_string($data)) {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
    
    return $data;
}

/**
 * Rate limiting check
 * @param string $identifier IP address or user ID
 * @param string $action Action being performed
 * @param int $maxAttempts Maximum attempts allowed
 * @param int $windowMinutes Time window in minutes
 * @return bool Whether action is allowed
 */
function isRateLimited($identifier, $action, $maxAttempts = 10, $windowMinutes = 15) {
    try {
        $pdo = getDatabaseConnection();
        
        // Clean old attempts
        $pdo->prepare("
            DELETE FROM rate_limits 
            WHERE created_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)
        ")->execute([$windowMinutes]);
        
        // Count current attempts
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as attempts 
            FROM rate_limits 
            WHERE identifier = ? AND action = ? 
            AND created_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)
        ");
        $stmt->execute([$identifier, $action, $windowMinutes]);
        $attempts = $stmt->fetch()['attempts'];
        
        if ($attempts >= $maxAttempts) {
            return true;
        }
        
        // Log this attempt
        $pdo->prepare("
            INSERT INTO rate_limits (identifier, action, created_at) 
            VALUES (?, ?, NOW())
        ")->execute([$identifier, $action]);
        
        return false;
        
    } catch (Exception $e) {
        // If rate limiting fails, allow the action
        error_log("Rate limiting error: " . $e->getMessage());
        return false;
    }
}

/**
 * Log security event
 * @param string $event Event type
 * @param string $message Event message
 * @param array $context Additional context
 */
function logSecurityEvent($event, $message, $context = []) {
    $logData = [
        'timestamp' => date('Y-m-d H:i:s'),
        'event' => $event,
        'message' => $message,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'context' => $context
    ];
    
    error_log("SECURITY: " . json_encode($logData));
    
    // Optionally store in database for analysis
    try {
        $pdo = getDatabaseConnection();
        $stmt = $pdo->prepare("
            INSERT INTO security_logs (event_type, message, ip_address, user_agent, context, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $event,
            $message,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            json_encode($context)
        ]);
    } catch (Exception $e) {
        // Ignore database logging errors
    }
}
?>