# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Application Overview

Hemangoo is an **offline-only** mango booking mobile application built for Android using Kotlin. The app facilitates slot booking between mango farmers and processing plants without requiring internet connectivity.

### Key Architecture Principles

**CRITICAL**: This application works **COMPLETELY OFFLINE** using local storage only. No HTTP requests, no online services, no network dependencies.

### User Roles

1. **Farmers**: Book time slots at processing plants, submit mango quality details
2. **Admins**: Review and approve/reject farmer booking requests

### Core Application Flow

1. **User Registration/Login**: Offline authentication using local storage
2. **Farmer Booking Process**:
   - Select factory and mango variety details
   - Choose available time slots
   - Submit quality report information
   - Book slot (stored locally with PENDING status)
3. **Admin Review Process**:
   - View pending booking requests
   - Approve or reject bookings
   - Update booking status in local storage

## Project Structure

```
Hemangoo/
├── Backend/                    # PHP backend (for reference only - not used in offline app)
├── Frontend/                   # Android Kotlin application
│   └── app/src/main/java/com/example/hemangoo/
│       ├── data/
│       │   ├── api/           # API client (unused in offline mode)
│       │   └── models/        # Data models (Booking, User, Factory, etc.)
│       ├── database/          # Local storage management
│       │   ├── LocalDatabaseManager.kt    # Core offline database operations
│       │   ├── LocalDatabaseSchema.kt     # Database schema definitions
│       │   └── DatabaseOperations.kt      # Additional database utilities
│       ├── ui/
│       │   ├── auth/          # Login/Signup screens
│       │   ├── booking/       # Booking flow screens
│       │   ├── admin/         # Admin management screens
│       │   └── dashboard/     # User dashboards
│       ├── LocalStorageManager.kt         # Main storage interface
│       └── MainActivity.kt
└── Database/                   # SQL files (for reference only)
```

## Development Commands

### Build and Run

```bash
# Navigate to Frontend directory
cd Frontend

# Clean and build (Debug)
./gradlew clean assembleDebug

# Install on connected device/emulator
./gradlew installDebug

# Build release APK
./gradlew assembleRelease

# Run tests
./gradlew test
./gradlew connectedAndroidTest
```

### Android Development

```bash
# Check for lint issues
./gradlew lintDebug

# Generate test coverage report
./gradlew createDebugCoverageReport

# View dependency tree
./gradlew dependencies
```

## Key Components

### 1. Local Storage Architecture

- **LocalStorageManager.kt**: Main interface for all storage operations
- **LocalDatabaseManager.kt**: Core database implementation using SharedPreferences + JSON
- **LocalDatabaseSchema.kt**: Database schema and structure definitions

### 2. Data Models

Primary models in `data/models/`:
- `User.kt`: User authentication and profile data
- `Booking.kt`: Booking records with quality reports
- `Factory.kt`: Processing plant information
- `TimeSlot.kt`: Available booking time slots
- `MangoVariety.kt`: Mango type and variety data

### 3. Critical Offline Components

- All data persisted in Android SharedPreferences as JSON
- No network calls or HTTP dependencies
- Thread-safe operations using Kotlin coroutines and mutex locks
- Automatic sample data initialization for testing

## Recent Critical Fixes

### Issue 1: Booking Storage Failure
**Problem**: Slot bookings weren't being saved to local storage due to mutex deadlock issues in `LocalDatabaseManager`.

**Solution**: 
- Added internal methods (`getUsersInternal()`, `getBookingsInternal()`, etc.) that bypass mutex locks
- Fixed `createBooking()` to use internal methods when already holding locks
- Improved error handling and transaction management

### Issue 2: User Registration Failure  
**Problem**: New user signup was hanging due to the same mutex deadlock issue.

**Solution**:
- Fixed `registerUser()` and `createUser()` methods to use internal data access
- Eliminated circular mutex lock acquisition
- Added proper error handling for user creation flow

## Development Guidelines

### Working with Local Storage

```kotlin
// Always use LocalStorageManager as the main interface
val localStorage = LocalStorageManager(context)

// Booking operations
val booking = Booking(...)
val result = localStorage.saveBooking(booking) // Uses suspend function

// User operations
val user = localStorage.getCurrentUser()
val loginResult = localStorage.loginUser(email, password, role)
```

### Database Operations

- All database operations are asynchronous using Kotlin coroutines
- Use `lifecycleScope.launch` in Activities for database calls
- Always handle `Result<T>` return types properly
- Never make blocking calls on the main thread

### Testing Offline Functionality

1. **Disable network** on device/emulator
2. **Clear app data** to test initialization
3. **Test complete user flows** without network
4. **Verify data persistence** across app restarts

## Common Issues and Solutions

### Mutex Deadlock
- **Symptom**: App hangs during user registration or booking creation
- **Solution**: Use internal methods when already holding mutex locks
- **Prevention**: Avoid calling public methods from within mutex.withLock blocks

### Data Not Persisting
- **Check**: Ensure all save operations use `prefs.edit().apply()`
- **Check**: Verify JSON serialization/deserialization
- **Check**: Look for exceptions in logs during database operations

### Sample Data Missing
- **Solution**: Clear app data to trigger sample data re-initialization
- **Check**: Verify `initializeSampleData()` runs successfully in `LocalDatabaseManager`

## Testing Strategy

### Manual Testing Checklist
1. ✅ User registration (both farmer and admin roles)
2. ✅ User login with correct credentials
3. ✅ Complete booking flow (factory → mango details → slot selection → booking confirmation)
4. ✅ Admin approval/rejection of bookings
5. ✅ Data persistence across app restarts
6. ✅ Error handling for invalid inputs

### Key Test Scenarios
- **Offline Registration**: Create new users without network
- **Booking Creation**: Complete slot booking and verify storage
- **Admin Workflow**: Review and update booking statuses
- **Data Recovery**: Restart app and verify all data persists

## Important Notes for Future Development

1. **MAINTAIN OFFLINE-ONLY ARCHITECTURE**: Never add network dependencies
2. **Thread Safety**: Always use proper coroutine scopes and mutex locks
3. **Data Integrity**: Validate all inputs before storage operations
4. **Error Handling**: Provide meaningful error messages for offline scenarios
5. **Sample Data**: Ensure new installations have working test data

## Build Configuration

- **Target SDK**: 35
- **Min SDK**: 24
- **Kotlin Version**: Compatible with Android Gradle Plugin
- **Dependencies**: Minimal - only essential Android libraries + Gson for JSON handling

The application is designed to work completely independently without any server infrastructure or network connectivity.